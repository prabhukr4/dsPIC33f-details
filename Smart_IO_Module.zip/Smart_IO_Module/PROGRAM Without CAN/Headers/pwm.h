
//  PWM definitions
#define PRI_time_in_us vt_number        // desired time in micro seconds
#define SEC_time_in_us 2500             // desired time in micro seconds
#define PRI_duty_cycle PRI_phase/2      // PRI_phase/2 = 50%duty cycle
#define SEC_duty_cycle SEC_phase/2      // SEC_phase/2 = 50%duty cycle
#define PWM_prescalar 6                 //Divide-by-64, maximum PWM timing resolution

/************************************************************************************************/
//Function Name			: config_pwm
//Purpose               : To configure PWM
//Description			: configure PWM registers to get the desired pulse output
//PWM formula           : phase2, s-phase2 = Ref-clk*desired PWM period / 7.37MHZ*1.04nS*pre-scalar

/************************************************************************************************/
void config_pwm() {
    unsigned long int SEC_phase = 0;
    PWMCON2bits.ITB = 1; // PHASEx/SPHASEx provides the PWM time period value
    PWMCON2bits.MDCS = 0; // PDC2 and SDC2 provides duty cycle value
    PWMCON2bits.DTC = 0b10; //Dead-time function is disabled

    IOCON2bits.PENH = 1; /* PWM Output pin control assigned to PWM generator */
    IOCON2bits.PENL = 1; /* PWM Output pin control assigned to PWM generator */
    IOCON2bits.POLH = 0; /* PWM O/P active high */
    IOCON2bits.POLL = 0; /* PWM O/P active high */
    IOCON2bits.PMOD = 0b11; // PWM I/O pin pair is in the True Independent Output mode

    PTCON2bits.PCLKDIV = PWM_prescalar; //pre-scalar
    PRI_phase = ((PRI_time_in_us * 100000) / (104 * pow(2, PWM_prescalar))); //((desired time) / (1.04nS * pre_scalar))	if 10us period = 1602
    PHASE2 = PRI_phase; // Primary phase shift value 
    SEC_phase = ((SEC_time_in_us * 100000) / (104 * pow(2, PWM_prescalar))); //((desired time) / (1.04nS * pre_scalar))
    SPHASE2 = SEC_phase; // Secondary phase shift value
    PDC2 = PRI_duty_cycle; // Independent Primary Duty Cycle is 50% of the period
    SDC2 = SEC_duty_cycle; // Independent Secondary Duty Cycle is 50% of the period

    PTCONbits.PTEN = 1; /* Enable High-Speed PWM module */
}