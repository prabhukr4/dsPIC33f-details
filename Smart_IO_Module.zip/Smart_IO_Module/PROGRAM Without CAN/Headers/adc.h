/************************************************************
//Function Name			: ADC_init
//Purpose				: ADC initialization
//Description			: To initialize ADC registers to read the voltage
************************************************************/

void ADC_init(void)
{
	ADCONbits.ADON = 1; 		// turn ADC ON
    ADCONbits.SLOWCLK = 1; 		// ADC is clocked by the auxiliary PLL (ACLK)
    ADCONbits.FORM = 0; 		// Integer output
    ADCONbits.ADCS = 0b110; 	// Conversion Clock Divider.. minimum TAD is 35.8 nS as per electrical characteristics.
}
/************************************************************************************************/
//Function Name			: collect_adc_pair0
//Purpose               : To get ADC samples
// input                : none
// output               : It will return the measured DC voltage of AN0 and AN1 by getting desired samples.

/************************************************************************************************/

void Collect_adc_pair0()
{
	int sample;
    uint32_t adc_buffer1 = 0, adc_buffer2 = 0;
	
	ADCPC0bits.TRGSRC0 = 0b00001; 	//Individual software trigger is selected
	ADCPC0bits.SWTRG0 = 1; 			//Starts conversion of AN0 and AN1 
	__delay32(100); 				//conversion time
	//while (ADSTATbits.P0RDY == 0); //Conversion Data for Pair 0 Ready 
	//ADSTATbits.P0RDY = 0;
	ADCPC0bits.PEND0 = 0; 			//Conversion is complete
	adc_buffer1 += ADCBUF0; 		//getting values from buffer
	adc_buffer2 += ADCBUF1; 		//getting values from buffer
}

/************************************************************************************************/
//Function Name			: collect_adc_pair1
//Purpose               : To get ADC samples
// input                : none
// output               : It will return the measured DC voltage of AN2 and AN3 by getting desired samples.

/************************************************************************************************/
void collect_adc_pair1(unsigned int *adc_channel_2, unsigned int *adc_channel_3) 
{
    int sample;
    uint32_t adc_buffer1 = 0, adc_buffer2 = 0;
	
	ADCPC0bits.TRGSRC1 = 0b00001; 		//Individual software trigger is selected
	ADCPC0bits.SWTRG1 = 1; 				//Starts conversion of AN3 and AN2 
	__delay32(100); 					//conversion time
	//while (ADSTATbits.P1RDY == 0); 	//Conversion Data for Pair 1 Ready 
	//ADSTATbits.P0RDY = 0;
	ADCPC0bits.PEND1 = 0; 				//Conversion is complete
	adc_buffer1 += ADCBUF2; 			//getting values from buffer
	adc_buffer2 += ADCBUF3; 			//getting values from buffer
}

















