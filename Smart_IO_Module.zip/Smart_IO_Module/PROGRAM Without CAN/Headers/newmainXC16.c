/*************************************************************************************************
 *  PURPOSE      : AC Load bank (To monitor GPU)                                                  *
 *  DEVELOPED BY : VIGNESH M                                                                      *
 *  STARTED ON   : 14-06-2017                                                                     *
 *  VERSION      : V1.1                                                                             *
 *  Language     : C Programming                                                                  *
 *  Controller   : dsPIC33FJ32GS406(16 Bit)                                                       *
 *                                                                                                *
 **************************************************************************************************/

/********************************************************************************
 * HARDWARE *         * PORT ALLOCATION  *                                      *
 ********************************************************************************/
//--------------------------------------------------------------------------------------------------//
//							Pin Description															//
//--------------------------------------------------------------------------------------------------//
//	Pin Number		    Pin Details					Pin Description									//
//--------------------------------------------------------------------------------------------------//
//		1				PE5						Digital output 1 relay								//
//		2				PE6						Digital output 2 relay								//
//		3				PE7						Digital output 3 relay								//
//		4				PG6						-                                               	//
//		5				PG7                 	-                                               	//
//		6				PG8                     -                                               	//
//		7				MCLR					Reset												//
//		8				PG9						not used											//
//		9				VSS						Ground												//
//		10				VDD						Supply                                              //
//		11				PB5						Analog Input 1 voltage R							//
//		12				PB4						Analog Input 2 voltage Y							//
//		13				PB3						Analog Input 3 voltage B			    			//
//		14				PB2						Analog Input 4 current R                            //
//		15				PB1						Analog Input 5 current Y							//
//		16				PB0						Analog Input 6 current B							//
//		17				PB6						Analog Input 7										//
//		18				PB7						Analog Input 8										//
//		19				AVDD					Analog reference supply								//
//		20				AVSS					Analog reference ground								//
//		21				PB8						Analog Input 9                                      //
//		22				PB9						Analog Input 10										//
//		23				PB10					-                                                   //
//		24				PB11					-                                               	//
//		25				VSS						ground                                          	//
//		26				VDD						supply                                              //
//		27				PB12					-                                               	//
//		28				PB13					-                                           		//
//		29				PB14					-                                                   //
//		30				PB15					SYS status LED										//
//		31				U2RX					LCM RX UART											//
//		32				U2TX					LCM TX UART                                         //
//		33				U1TX					Lab-view TX UART                                 	//
//		34				U1RX					Lab-view RX UART                                    //
//		35				PF6             		PR sense(digital input )                            //
//		36				PG3						Digital input                          				//
//		37				PG2						bypass/interlock    								//
//		38				VDD						supply												//
//		39				OSC1					XTAL1                               				//
//		40				OSC2					XTAL2                                           	//
//		41				VSS						Ground                                      		//
//		42				PD8						Input capture 1										//
//		43				PD9						Input capture 2                                 	//
//		44				PD10                	Input capture 3/Digital pin							//
//		45				PD11                    Input capture 4/Digital pin							//
//		46				PD0						-                                                   //
//		47				PC13					Digital Input										//
//		48				PC14					Digital Input                                   	//
//		49				PD1						output compare 1									//
//		50				PD2						output compare 2									//
//		51				PD3						output compare 3									//
//		52				PD4                 	TRIAC 3_DRI PWM  									//
//		53				PD5                     TRIAC 2_DRI PWM                                 	//
//		54				PD6                     TRIAC 1_DRI PWM										//
//		55				PD7						Digital output										//
//		56				VCAP					ground                                              //
//		57				VDD						Supply                                              //
//		58				PF0						Digital input sense									//
//		59				PF1						Digital input sense									//
//		60				PE0						Digital output 4 relay								//
//		61				PE1						Digital output 5 relay								//
//		62				PE2						Digital output 6 relay                              //
//		63				PE3						Digital output 7 relay								//
//		64				PE4						Digital output 8 relay                         		//
//--------------------------------------------------------------------------------------------------//

/*******************************************************************************/
/*                                                                             */
/*                              Include Files                                  */
/*                                                                             */
/*******************************************************************************/

#include<p33fJ32GS406.h>    //to include processor header
#include<libpic30.h>    //to include delay header and c30 UART header
#include<stdio.h>   //to include standard i/o function header
#include<stdint.h>  //to include standard integer types per ISO/IEC 9899:1999
#include<math.h>    //to include mathematical operations
#include<stdbool.h> //to include boolean operation
#include "CRC_CALC.H"   //to include CRC calculation

//#define vt100   //to set virtual terminal as output window
#define labview //to set labview terminal as output window
#define LCM //to set LCM terminal as output window
// DSPIC33FJ32GS406 Configuration Bit Settings
// 'C' source line configuration statements
#include<xc.h>  //common header for PIC24/dsPIC33

// FBS
#pragma config BWRP = WRPROTECT_OFF     // Boot Segment Write Protect (Boot Segment may be written)
#pragma config BSS = NO_FLASH           // Boot Segment Program Flash Code Protection (No Boot program Flash segment)

// FGS
#pragma config GWRP = OFF               // General Code Segment Write Protect (General Segment may be written)
#pragma config GSS = HIGH               // General Segment Code Protection (High Security Code Protection Enabled)

// FOSCSEL
#pragma config FNOSC = PRIPLL           // Oscillator Source Selection (Primary Oscillator (XT, HS, EC) with PLL)
#pragma config IESO = OFF               // Internal External Switch Over Mode (Start up device with user-selected oscillator source)

// FOSC
#pragma config POSCMD = HS              // Primary Oscillator Source (HS Crystal Oscillator Mode)
#pragma config OSCIOFNC = ON            // OSC2 Pin Function (OSC2 is general purpose digital I/O pin)
#pragma config FCKSM = CSDCMD           // Clock Switching Mode bits (Both Clock switching and Fail-safe Clock Monitor are disabled)

// FWDT
#pragma config WDTPOST = PS4096         // Watchdog Timer Postscaler (1:4,096)
#pragma config WDTPRE = PR32            // WDT Prescaler (1:32)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Watchdog Timer in Non-Window mode)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog timer enabled/disabled by user software)

// FPOR
#pragma config FPWRT = PWR128           // POR Timer Value (128ms)
#pragma config ALTSS1 = OFF             // Enable Alternate SS1 pin bit (SS1 is selected as the I/O pin for SPI1)
#pragma config ALTQIO = OFF             // Enable Alternate QEI1 pin bit (QEA1, QEB1, INDX1 are selected as inputs to QEI1)

// FICD
#pragma config ICS = PGD1               // Comm Channel Select (Communicate on PGC1/EMUC1 and PGD1/EMUD1)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG is disabled)


uint8_t getq_serial1(void); //to get serial1 received data 
uint8_t getq_serial2(void); //to get serial2 received data
void system_init();
void Serial_init(); //UART initialization
void Serial1_write_byte(uint8_t byte); //write UART1 byte
void Serial1_write_string(char *str); //write UART1 string
void Serial1_write_number(uint16_t num); //write UART1 number
void Serial2_write_byte(uint8_t byte); //write UART2 byte
void Serial2_write_string(char *str); //write UART2 string
void Serial2_write_number(uint16_t num); //write UART2 number
unsigned int crc(volatile unsigned char *puchMsg , unsigned short usDataLen);
void collect_adc_pair0(unsigned int *adc_channel_0, unsigned int *adc_channel_1); //To get ADC pair0 samples
void collect_adc_pair1(unsigned int *adc_channel_2, unsigned int *adc_channel_3); //To get ADC pair1 samples
void collect_adc_pair2(unsigned int *adc_channel_4, unsigned int *adc_channel_5); //To get ADC pair2 samples
void convert_adc_data();
void collect_adc_pair7(unsigned int *AN14, unsigned int *AN15); //To get ADC pair7 samples
void ADC_init(); //ADC initialization
void Timer2_init(); //Tmer 2 initialization 
void Timer3_init(); //Tmer 3 initialization
void capture_init(); //capture initialization
void collect_input_capture(unsigned long *frequency);
void config_pwm(); //configuring PWM
void write_checksum(unsigned int add); //to write checksum
void Lab_screen_data(unsigned int send);
void LCM_write(uint8_t count, uint16_t address, uint16_t *lcmdata);
void LCM_receive_process();// to receive data from LCM
void relay_drive_process(); //to drive the relay
void LCM_display_process(); //to display the data in LCM
void labview_receive_process(); //to receive from lab view
void labview_relay_drive(); //to drive the relay by input from lab view
void labview_write_process();   //to write the data to lab view terminal
void VT100_display_process();   //to display in VT terminal
void VT100_receive_process();   //to receive from VT terminal
void clear_screen();    //to clear all the display screens

//  PLL definitions
#define MUL 25  //multiplier for PLL
#define POST 2  //postscalar for PLL
#define PRE 2   //prescalar for PLL

// ADC definitions
#define adcpair0_samp_count 500     //adc pair0 sample count
#define adcpair1_samp_count 500     //adc pair1 sample count
#define adcpair2_samp_count 500     //adc pair2 sample count
#define adcpair5_samp_count 100
#define voltage_resolution 6393  //voltage resolution for 2.5v (1023/160 = 6.39375) for 3.3v (1023/211.2 = 4.84375)
#define current_resolution 2557  //current resolution for 2.5v (1023/400 = 2.5575) for 3.3v (1023/528 = 1.9375 ) 
#define DC_ref 409.20       //reference step value = (2.5v = 409.20) (3.3v = 310.00)
#define ADC_MAX 1023

//  Relay sequence definitions
#define relay_drive_port PORTE  //relay driving port
#define r1_debug 0x2    //r1 led in debug screen
#define r2_debug 0x6    //r2 led in debug screen
#define r3_debug 0xe    //r3 led in debug screen
#define r4_debug 0x1e   //r4 led in debug screen
#define r5_debug 0x3e   //r5 led in debug screen    
#define r6_debug 0x7e   //r6 led in debug screen
#define r7_debug 0xfe   //r7 led in debug screen
#define r8_debug 0x1fe  //r8 led in debug screen
#define r9_debug 0x3fe  //r8 led in debug screen    
#define r10_debug 0x7fe //r10 led in debug screen

#define r1_relay 0x80   //load selector relay 1
#define r2_relay 0xc0    //load selector relay 2
#define r3_relay 0xe0    //load selector relay 3
#define r4_relay 0xf0    //load selector relay 4
#define r5_relay 0xf8    //load selector relay 5
#define r6_relay 0xfc    //load selector relay 6
#define r7_relay 0xfe    //load selector relay 7
#define r8_relay 0xff    //load selector relay 8

#define relay_1 PORTEbits.RE7   //load selector relay 1
#define relay_2 PORTEbits.RE6   //load selector relay 2
#define relay_3 PORTEbits.RE5   //load selector relay 3
#define relay_4 PORTEbits.RE4   //load selector relay 4
#define relay_5 PORTEbits.RE3   //load selector relay 5
#define relay_6 PORTEbits.RE2   //load selector relay 6
#define relay_7 PORTEbits.RE1   //load selector relay 7
#define relay_8 PORTEbits.RE0   //load selector relay 8
#define relay_9 PORTDbits.RD7   //load selector relay 9
#define relay_10 PORTGbits.RG3  //load selector relay 10   D11/RG3
#define byp_inter PORTGbits.RG2  //load selector relay 11
#define relay_12 PORTDbits.RD0  //load selector relay 12
#define sys_led PORTBbits.RB15  //system led pin
#define PR_sen_dir TRISFbits.TRISF6 //PR sense pin direction
#define PR_sense PORTFbits.RF6 //PR sense pin
#define overtemp_ind PORTCbits.RC14  //start condition input pin

#define debug_scrn_pin 1112
#define display_delay 15
#define NORMAL 0
#define FAULT 1
#define ON 0
#define OFF 1
#define LOCAL 0
#define REMOTE 1
#define FOUND 0
#define NOTFOUND 1
#define load_sel PORTFbits.RF0
#define EandF PORTCbits.RC13 //interlock feedback
#define load_sel_dir TRISFbits.TRISF0
#define overtemp_dir TRISCbits.TRISC14 //start condition pin direction
#define EandF_dir TRISCbits.TRISC13 //EandF pin direction

//  capture definitions
#define cap_samp_count 10           //capture pulse sample count
#define cap_int_priority 1          //capture interrupt priority
#define cap_prescalar 64            //capture timer prescalar
#define FREQ_cycle 50            //  Fcy / 1000
#define frequency_error_time_in_secs 1      //frequeny stable find out duration
#define onesecond_count 12       //frequency error count limit in seconds as per timer clock_tick
#define freq_MAX_LMT 999     //frequency maximum limit to display
#define freq_MIN_LMT 200     //frequency maximum limit to display

//  PWM definitions
#define PRI_time_in_us vt_number        // desired time in micro seconds
#define SEC_time_in_us 2500             // desired time in micro seconds
#define PRI_duty_cycle PRI_phase/2      // PRI_phase/2 = 50%duty cycle
#define SEC_duty_cycle SEC_phase/2      // SEC_phase/2 = 50%duty cycle
#define PWM_prescalar 6                 //Divide-by-64, maximum PWM timing resolution

//  Timer definitions
#define timer2_toggle PORTGbits.RG2  //timer 2 toggler pin
#define timer3_toggle PORTDbits.RD11  //timer 3 toggler pin  //RG3/RD11
#define t2_periodvalue 0xffff   //((prescalar * t3_periodvalue) / FCY) //time_duration to clock_tick = 83.88 mS
#define t4_periodvalue 7812 //for 10mS 
#define t2_int_priority 4   //timer 2 interrupt priority
#define t2_prescalar 0b10   //1:64 prescalar
#define t4_prescalar 0b10   //1:64 prescalar
#define t3_periodvalue 244  // ((prescalar * t3_periodvalue) / FCY) //time_duration = 1.250mS
#define t3_int_priority 5   //timer 3 interrupt priority
#define t3_prescalar 0b11   //1:256 prescalar

//  UART definitions
#define sys_led_dir TRISBbits.TRISB15   //system led pin direction
#define Fcy 50000000UL //system clock 1 instruction cycle = 2 clock cycle i.e., Fcy=fosc/2 , 50MIPS
#define BAUDRATE 115200      //baudrate setting
#define BRGVAL (((Fcy/BAUDRATE)/16))    //baudrate formula setting
#define u1_rx_int_priority 2        //UART 1 receive interrupt priority
#define u2_rx_int_priority 3        //UART 2 receive interrupt priority
#define MAX_QSER 100   //change this according to que length

#define labstart_byte 0x5a //labview start byte
#define lab_recv_byte 0xA5

//LCM definitions
#define mainscreen_startaddress 0x0020  //LCM main screen start addres
#define debug_startaddress 0x0500   //LCM debug screen start address
#define load_selection_addr 0x0010  //LCM main screen load selection start address
#define slider_address 0x0012   //LCM main screen slider selection address
#define local_remote_addr 0x0013
#define PWM_start_addr 0x00FC   //LCM debug screen PWM input start address
#define LCMstart_MSB 0x5a   //LCM receive start byte MSB
#define LCMstart_LSB 0xa5   //LCM receive start byte LSB
#define start_byte 0x5A
#define LCM_to_write 0x82   //LCM to write byte
#define LCM_to_read 0x83    //LCM to read byte
#define sizeofmain_screen 10    //array size of main screen
#define sizeofdebug_screen 30   //array size of debug screen
#define sizeoflcm_receive 12    //array size of LCM receive 

struct {
    uint8_t qdata[MAX_QSER]; // structure for serial que
    uint16_t qin; //serial que address position while storing
    uint16_t qout; //serial que address position while retrieving
    uint16_t qcount; //serial que data count
    bool clock_tickerr; //serial que clock_tick flag
} serial1, serial2;
/*
struct ADC{
    uint32_t disp_volt, channel_volt;
    uint16_t channel_count, LCM_dedug_volt;
} ADC0, ADC1, ADC2, ADC3, ADC4, ADC5;

 */
/****************************   variable's declaration   **********************************/
unsigned short int power, captured_1st_IC1, captured_2nd_IC1, vt_number = 0, inp_freq = 0, rec_crc_val, captured_1st_IC2, captured_2nd_IC2, captured_1st_IC3, captured_2nd_IC3;
unsigned int AN0, AN1, AN2, AN3, AN4, AN5, AN14, AN15;
uint8_t lab_relay_drive, byp_int, clock_tick_lab;
uint8_t buffer = 0, lab_load_sel, receive_count, vt_receive[5], labview_receive[5], cap_clk_tick, cap_clock_tick, clocktick_forLCM, first = 0, completed = 0, checksum = 0, lcm_receive[sizeoflcm_receive];
uint8_t completed_2 = 0, completed_3 = 0, first2 = 0, first3 = 0, cap2_clk_tick = 0, cap3_clk_tick = 0, system = 0, relay_drive_lcm, EandFdata, clock_tick;
uint16_t LCM_screendata[sizeofmain_screen], LCM_debugdata[sizeofdebug_screen], Password=0;
uint16_t adc_channel_0, adc_channel_1, adc_channel_2, adc_channel_3, adc_channel_4, adc_channel_5, LCM_chn0_volt, LCM_chn1_volt, LCM_chn2_volt, LCM_chn3_volt, LCM_chn4_volt, LCM_chn5_volt;
uint32_t Van, Vbn, Vcn, Ia, Ib, Ic, voltage, current, PRI_phase = 0, deb_freq, frequency;
uint32_t chn0_volt, chn1_volt, chn2_volt, chn3_volt, chn4_volt, chn5_volt, avgpower;
/*******************************************************************************/

/*******************************************************************************/
/*                                                                             */
/*                              Interrupt Function                             */
/*                               for UART1 receive                             */
/*                                using FIFO method                            */

/*******************************************************************************/
void __attribute__((__interrupt__, __no_auto_psv__)) _U1RXInterrupt(void) {
    if (serial1.qcount < MAX_QSER) // check whether the que is full..if full set que clock_tick flag and return
    {
        serial1.clock_tickerr = false;
        serial1.qdata[serial1.qin] = U1RXREG; // if the que is not full insert the data into the array
        ++serial1.qcount; // increment q count

        if (serial1.qin == MAX_QSER - 1) serial1.qin = 0; // check whether qin has reached maximum  and if its true clear the qin..round robin 

        else ++serial1.qin; // increment qin
    } else {
        serial1.qcount = MAX_QSER; // if the que is full store max_q value to count
        serial1.clock_tickerr = true;
    }
    IFS0bits.U1RXIF = 0; // Clear TX Interrupt flag
}
/*******************************************************************************/
/*                                                                             */
/*                              Interrupt Function                             */
/*                               for UART2 receive                             */
/*                                using FIFO method                            */

/*******************************************************************************/
void __attribute__((__interrupt__, __no_auto_psv__)) _U2RXInterrupt(void) {
    if (serial2.qcount < MAX_QSER) // check whether the que is full..if full set que ovverflow flag and return
    {
        serial2.clock_tickerr = false;
        serial2.qdata[serial2.qin] = U2RXREG; // if the que is not full insert the data into the array
        ++serial2.qcount; // increment qcount

        if (serial2.qin == MAX_QSER - 1) serial2.qin = 0; // check whether qin has reached maximum  and if its true clear the qin..roundrobin 

        else ++serial2.qin; // increment qin
    } else {
        serial2.qcount = MAX_QSER; // if the que is full store max_q value to count
        serial2.clock_tickerr = true;
    }
    IFS1bits.U2RXIF = 0; // Clear TX Interrupt flag
}

/*******************************************************************************/
/*                                                                             */
/*                              Interrupt Function                             */
/*                               for input capture                             */
//  range is limited to 200 HZ to 999 HZ
//  available range is 194 HZ to 9 KHZ
//  If we tend to increase the delay time in collect_input_capture 
//  theoretically it will go to 12 HZ to 780 kHZ.
//  resolution is + or - 1.28 uS

/*******************************************************************************/
void __attribute__((__interrupt__, __no_auto_psv__)) _IC1Interrupt(void) {

    if (completed == 0) {
        if (first == 1) { //to take end of time
            captured_2nd_IC1 = IC1BUF; //end time have been captured  
            completed = 1; //second rising time captured
            cap_clock_tick = cap_clk_tick;
        } else if (first == 0) { //to take start of time       
            captured_1st_IC1 = IC1BUF; //start time have been captured
            first = 1; //first rising time captured
            cap_clk_tick = 0; //clearing the timer clock_tick count
        }
    }
    IFS0bits.IC1IF = 0;

}


/*******************************************************************************/
/*                                                                             */
/*                              Interrupt Function                             */
/*                               for input capture                             */
//  range is limited to 200 HZ to 999 HZ
//  available range is 194 HZ to 9 KHZ
//  If we tend to increase the delay time in collect_input_capture 
//  theoretically it will go to 12 HZ to 780 kHZ.
//  resolution is + or - 1.28 uS

/*******************************************************************************/
void __attribute__((__interrupt__, __no_auto_psv__)) _IC2Interrupt(void) {

    if (completed_2 == 0) {
        if (first2 == 1) { //to take end of time
            captured_2nd_IC2 = IC2BUF; //end time have been captured  
            completed_2 = 1; //second rising time captured
        } else if (first2 == 0) { //to take start of time       
            captured_1st_IC2 = IC2BUF; //start time have been captured
            first2 = 1; //first rising time captured
            cap2_clk_tick = 0; //clearing the timer clock_tick count
        }
    }
    IFS0bits.IC2IF = 0;

}

/*******************************************************************************/
/*                                                                             */
/*                              Interrupt Function                             */
/*                               for input capture                             */
//  range is limited to 200 HZ to 999 HZ
//  available range is 194 HZ to 9 KHZ
//  If we tend to increase the delay time in collect_input_capture 
//  theoretically it will go to 12 HZ to 780 kHZ.
//  resolution is + or - 1.28 uS

/*******************************************************************************/
void __attribute__((__interrupt__, __no_auto_psv__)) _IC3Interrupt(void) {

    if (completed_3 == 0) {
        if (first3 == 1) { //to take end of time
            captured_2nd_IC3 = IC3BUF; //end time have been captured  
            completed_3 = 1; //second rising time captured
        } else if (first3 == 0) { //to take start of time       
            captured_1st_IC3 = IC3BUF; //start time have been captured
            first3 = 1; //first rising time captured
            cap3_clk_tick = 0; //clearing the timer clock_tick count
        }
    }
    IFS2bits.IC3IF = 0;

}

/*******************************************************************************/
/*                              Interrupt Function                             */
/*                                for timer 2                                  */
/*                        time_duration  = 83.88 mS                            */
// resolution = 1.28 uS

/*******************************************************************************/

void __attribute__((__interrupt__, __no_auto_psv__)) _T2Interrupt(void) {
    //timer2_toggle = ~timer2_toggle; //toggling the timer 2 pin
    cap_clk_tick++; //check for capture operation clock_tick
    clock_tick++;

    IFS0bits.T2IF = 0; // Clear Timer2 Interrupt Flag
}
/*******************************************************************************/
/*                              Interrupt Function                             */
/*                                for timer 3                                  */
/*           resolution = 5.12 uS             resolution = 3HZ                 */

/*******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _T3Interrupt(void) {

    timer3_toggle = ~timer3_toggle; //toggling the timer 3 pin
    IFS0bits.T3IF = 0; // Clear Timer3 Interrupt Flag
}
/*******************************************************************************/
/*                              Interrupt Function                             */
/*                                for timer 4                                  */
/*           resolution = 1.28 uS             overflow = 10mS                  */

/*******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _T4Interrupt(void) {
    cap2_clk_tick++; //check for capture operation clock_tick
    cap3_clk_tick++; //check for capture operation clock_tick 
    IFS1bits.T4IF = 0; // Clear Timer3 Interrupt Flag
}
/*******************************************************************************/
/*                                                                             */
/*                              Main Function starts                           */
/*                                                                             */

/*******************************************************************************/
int main(void) {

    system_init(); //function call for system initialization
    Serial_init(); //function call for UART initialization
    ADC_init(); //function call for ADC initialization
    //config_pwm();   //function call for PWM configuration
    Timer2_init(); //function call for timer 2 initialization    
    Timer3_init(); //function call for timer 3 initialization
    //Timer4_init();  //function call for timer 4 initialization
    capture_init(); //function call for capture initialization

    clear_screen(); //to clear all the display screens
    while (1) {

        collect_adc_pair0(&adc_channel_0, &adc_channel_1); //to collect samples and return average of ADC pair0
        collect_adc_pair1(&adc_channel_2, &adc_channel_3); //to collect samples and return average of ADC pair1
        collect_adc_pair2(&adc_channel_4, &adc_channel_5); //to collect samples and return average of ADC pair2   
        convert_adc_data(); //to convert ADC data to voltage and current format   

        collect_input_capture(&frequency); //to collect samples and return average of captured pulse                 
        if (frequency >= freq_MAX_LMT)frequency = freq_MAX_LMT; //frequency maximum limit is 999 HZ  LCM can display up to 999
        if (cap_clock_tick >= 2 || frequency <= freq_MIN_LMT)frequency = freq_MIN_LMT; //frequency minimum limit is 200 HZ
        if (cap_clk_tick >= (frequency_error_time_in_secs * onesecond_count))frequency = 0; //to reset frequency to zero when capture pulse remains high/low      

#ifdef LCM

        LCM_receive_process(); //for receive from LCM
        relay_drive_process(); //to drive the relay
        LCM_display_process(); //to display in LCM

#endif

#ifdef vt100

        VT100_receive_process(); //vt100 screen receive process
        VT100_display_process(); //vt100 display

#endif  
#ifdef labview
        labview_receive_process(); //to receive from lab view
        labview_write_process(); //to write in lab view
        labview_relay_drive(); //to drive the relay based on lab view load selection
#endif

        //sys_led = 0; //making led low
        //__delay32(Fcy / 2); //50 MIPS
        //sys_led = 1; //making led high
        __delay32(Fcy / 4); //50 MIPS

        RCONbits.SWDTEN = 0; //to clear watch dog timer
    }
    return 0;
}
/************************************************************************************************/
//Function Name			: LCM_write(size, address, data array)
//Purpose               : To write in LCM
// input                : data size count ,write address, data stored array 
// output               : It will write the data in UART terminal after framing as per LCM with CRC.

/************************************************************************************************/
void LCM_write(uint8_t count, uint16_t address, uint16_t *lcmdata) {
    uint8_t LSB, MSB, LCM_datacount, crc_arr[60], addr_ptr = 0;
    uint16_t crc_value;

    Serial1_write_byte(LCMstart_MSB); //LSB start byte for LCM
    Serial1_write_byte(LCMstart_LSB); //MSB start byte for LCM
    LCM_datacount = ((count * 2) + 5); //data count going to write
    Serial1_write_byte(LCM_datacount); //writing the byte count

    Serial1_write_byte(LCM_to_write); //write address
    crc_arr[addr_ptr++] = 0x82; //to write in LCM
    MSB = ((address & 0xff00) >> 8); //MSB of start address
    LSB = (address & 0x00ff); //LSB of start address
    Serial1_write_byte(MSB); //write MSB start address in screen
    crc_arr[addr_ptr++] = MSB; //write MSB start address in CRC array 
    Serial1_write_byte(LSB); //write LSB start address in screen
    crc_arr[addr_ptr++] = LSB; //write LSB start address in CRC array  

    while (count--) {
        MSB = ((*lcmdata & 0xff00) >> 8); //MSB of data
        LSB = (*lcmdata++ & 0x00ff); //LSB of data
        Serial1_write_byte(MSB); //write MSB data in screen
        crc_arr[addr_ptr++] = MSB; //write MSB data in CRC array
        Serial1_write_byte(LSB); //write LSB data in screen
        crc_arr[addr_ptr++] = LSB; //write LSB data in CRC array
    }
    crc_value = crc(&crc_arr, addr_ptr); //CRC calculation 
    MSB = ((crc_value & 0xff00) >> 8); //MSB of CRC
    LSB = (crc_value & 0x00ff); //LSB of CRC
    Serial1_write_byte(MSB); //write MSB CRC 
    Serial1_write_byte(LSB); //write LSB CRC
}

/************************************************************************************************/
//Function Name			: LCM_receive_process(size, address, data array)
//Purpose               : To receive data from LCM
// input                : - 
// output               : -.

/************************************************************************************************/
void LCM_receive_process() {
    uint8_t check_count, rec_check_crc[20];
    for (receive_count = 0; receive_count < 80; receive_count++) {
        unsigned char received_char;
        if (serial1.qcount != 0) // check whether que is not empty
        {
            received_char = getq_serial1(); //receiving data from que
            if ((received_char == start_byte) || (buffer == 11)) //when receiving start byte or buffer fulls reset the array
            {
                buffer = 0; //clearing the buffer           
            }
            lcm_receive[buffer++] = received_char; //storing the received data in array
        }
    }

    if (lcm_receive[0] == start_byte) //if received is start byte
    {
        for (check_count = 0; check_count < lcm_receive[2]; check_count++) //to check crc
        {
            rec_check_crc[check_count] = lcm_receive[check_count + 3]; //values to be check for crc
        }
        rec_crc_val = crc(&rec_check_crc, check_count); //function call for crc

        if (rec_crc_val == 0) {
            switch (lcm_receive[5]) //switching the address
            {
                case 0x13:
                    system = lcm_receive[8]; //system / remote slider data
                    break;
                case 0x10:
                    relay_drive_lcm = lcm_receive[8]; //relay driving data
                    relay_drive_lcm = relay_drive_lcm / 8;
                    break;
                case 0x12:
                    EandFdata = lcm_receive[8]; //E and F slider data
                    break;
                case 0xfc:
                    inp_freq = (((lcm_receive[7] << 8) & 0xff00) + (lcm_receive[8] & 0x00ff)); //convert received hex to decimal   
                    break;
                case 0x18:
                    Password = (((lcm_receive[7] << 8) & 0xff00) + (lcm_receive[8] & 0x00ff)); //convert received hex to decimal                     
                    break;
                default:break;
            }
        }
    }
}
/************************************************************************************************/
//Function Name			: relay_drive_process(size, address, data array)
//Purpose               : To drive the relay
// input                : - 
// output               : drive the relay sequentially.

/************************************************************************************************/

void relay_drive_process() {
    if (overtemp_ind == NORMAL && system == LOCAL && load_sel == ON) {
        switch (relay_drive_lcm) {
            case 0:
                LCM_debugdata[20] = 0; //0kW initial condition
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = 0x00; //0kW initial condition
                break;
            case 1:
                LCM_debugdata[20] = r1_debug; //8KW R1 led pin for debug screen 
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = r1_relay; //load selector relay 1
                break;
            case 2:
                LCM_debugdata[20] = r2_debug; //16KW R2 led pin for debug screen 
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = r2_relay; //load selector relay 
                break;
            case 3:
                LCM_debugdata[20] = r3_debug; //24KW R3 led pin for debug screen 
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = r3_relay; //load selector relay 3
                break;
            case 4:
                LCM_debugdata[20] = r4_debug; //32KW R4 led pin for debug screen 
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = r4_relay; //load selector relay 4
                break;
            case 5:
                LCM_debugdata[20] = r5_debug; //40KW R5 led pin for debug screen
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = r5_relay; //load selector relay 5
                break;
            case 6:
                LCM_debugdata[20] = r6_debug; //48KW R6 led pin for debug screen
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = r6_relay; //load selector relay 6
                break;
            case 7:
                LCM_debugdata[20] = r7_debug; //56KW R7 led pin for debug screen
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = r7_relay; //load selector relay 7
                break;
            case 8:
                LCM_debugdata[20] = r8_debug; //64KW R8 led pin for debug screen
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = r8_relay; //load selector relay 8
                break;
            case 9:
                LCM_debugdata[20] = r9_debug; //72KW R9 led pin for debug screen 
                relay_drive_port = r8_relay; //load selector relay 8
                relay_10 = 0; //turn off relay 10
                relay_9 = 1; //turn on relay 9
                break;
            case 10:
                LCM_debugdata[20] = r10_debug; //72KW R9 led pin for debug screen 
                relay_drive_port = r8_relay; //load selector relay 8
                relay_10 = 1; //turn off relay 10
                relay_9 = 1; //turn on relay 9
                break;
            default:
                LCM_debugdata[20] = 0; //by default condition
                break;
        }
    }

    if (system == LOCAL) {
        switch (EandFdata) {
            case 0:
                byp_inter = 0; //bypass mode 
                LCM_debugdata[20] &= ~(1 << 11);
                break;
            case 1:
                byp_inter = 1; //interlock mode 
                LCM_debugdata[20] |= (1 << 11);
                break;
        }
        if (overtemp_ind == FAULT || load_sel == OFF) //load selector switch
        {
            __delay32(Fcy / 1000);
            if (overtemp_ind == FAULT || load_sel == OFF) //load selector switch
            {
                LCM_debugdata[20] = 0; //0kW initial condition
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = 0x00; //turn off all led                                                    
            }
        }
    }
    if(Password == 0)
    {
        printf("%c%c%c%c%c%cPls Enter the Pin No %c%c",0x5A, 0xA5, 0x1A, 0x82, 0x05, 0x19, 0x3A, 0xAD); //correct pin no 
    }
    
    if (Password == debug_scrn_pin) {
        printf("%c%c%c%c%c%c%c%c%c", 0x5A, 0xA5, 0x06, 0x80, 0x03, 0x00, 0x04, 0xD8, 0x27);//page switching
        lcm_receive[5] = 0;
        Password = 0;
    }
    if(Password != debug_scrn_pin && Password !=0 )
    {          
        printf("%c%c%c%c%c%cYour Pin No is Wrong!%c%c",0x5A, 0xA5, 0x1A, 0x82, 0x05, 0x19, 0x9A, 0xA8); //wrong pin no
        lcm_receive[5] = 0;
        Password = 0;
        __delay32(Fcy);
        __delay32(Fcy);
    }
    
   

}

/************************************************************************************************/
//Function Name			: LCM_display_process(size, address, data array)
//Purpose               : To display in LCM
// input                : - 
// output               : display the contents in LCM screen.

/************************************************************************************************/
void LCM_display_process() {
    uint8_t scr_ptr = 0;
    if (PR_sense == 1) { // phase reversal detected 
        __delay32(Fcy / 1000);
        if (PR_sense == 1) {
            LCM_debugdata[20] |= 1; //display in screen as green
        }
    } else if (PR_sense == 0) { // phase reversal not detected
        __delay32(Fcy / 1000);
        if (PR_sense == 0) {
            LCM_debugdata[20] &= 0xfffe; //display in screen as red
        }
    }
    if (overtemp_ind == NORMAL) //over temperature is normal
    {
        __delay32(Fcy / 1000);
        if (overtemp_ind == NORMAL) //over temperature is normal
        {
            __delay32(Fcy / 1000);
            LCM_debugdata[20] |= (1 << 14); //display in screen as green
        }
    } else if (overtemp_ind == FAULT) //over temperature indication
    {
        __delay32(Fcy / 1000);
        LCM_debugdata[20] &= ~(1 << 14); //led indication off
    }

    if (EandF == FOUND) //feedback input is normal
    {
        LCM_debugdata[20] |= (1 << 15); //display in screen as green
    } else if (EandF == NOTFOUND) //feedback input is not found
    {
        LCM_debugdata[20] &= ~(1 << 15); //led indication off
    }
    deb_freq = 195312 / (inp_freq * 2); //(Fcy / pre scalar)/(desired frequency)  i.e 50M/256 = 195312
    PR3 = deb_freq; //t3_period value; 
    if (clock_tick >= display_delay) {
        LCM_screendata[scr_ptr++] = AN0; //write AN5-VAN in LCM main screen
        LCM_screendata[scr_ptr++] = AN1; //write AN4-VBN in LCM main screen
        LCM_screendata[scr_ptr++] = AN2; //write AN3-VCN in LCM main screen
        LCM_screendata[scr_ptr++] = AN3; //write AN2-IA in LCM main screen
        LCM_screendata[scr_ptr++] = AN4; //write AN1-IB in LCM main screen
        LCM_screendata[scr_ptr++] = AN5; //write AN0-IC in LCM main screen
        LCM_screendata[scr_ptr++] = frequency; //write frequency in LCM main screen
        LCM_screendata[scr_ptr++] = power; //write power in LCM screen
        LCM_write(scr_ptr, mainscreen_startaddress, & LCM_screendata); //function call to write (size_of_data, start address, data array )
        clock_tick = 0;
    }
    LCM_debugdata[0] = adc_channel_0; //write AN0 ADC data in debug screen         
    LCM_debugdata[1] = adc_channel_1; //write AN1 ADC data in debug screen
    LCM_debugdata[2] = adc_channel_2; //write AN2 ADC data in debug screen
    LCM_debugdata[3] = adc_channel_3; //write AN3 ADC data in debug screen
    LCM_debugdata[4] = adc_channel_4; //write AN4 ADC data in debug screen
    LCM_debugdata[5] = adc_channel_5; //write AN5 ADC data in debug screen            
    LCM_debugdata[6] = LCM_chn0_volt; //write AN0 converted ADC data to voltage data in debug screen
    LCM_debugdata[7] = LCM_chn1_volt; //write AN1 converted ADC data to voltage data in debug screen
    LCM_debugdata[8] = LCM_chn2_volt; //write AN2 converted ADC data to voltage data in debug screen
    LCM_debugdata[9] = LCM_chn3_volt; //write AN3 converted ADC data to voltage data in debug screen
    LCM_debugdata[10] = LCM_chn4_volt; //write AN4 converted ADC data to voltage data in debug screen
    LCM_debugdata[11] = LCM_chn5_volt; //write AN5 converted ADC data to voltage data in debug screen        

    LCM_debugdata[13] = frequency * 10; //write IC2 in LCM debug screen
    LCM_debugdata[14] = frequency * 10; //write IC3 in LCM debug screen
    LCM_debugdata[15] = 0; //write IC4 in LCM debug screen

    LCM_debugdata[17] = 0; //write IC2 reg count in LCM debug screen
    LCM_debugdata[18] = 0; //write IC3 reg count in LCM debug screen
    LCM_debugdata[19] = 0; //write IC4 reg count in LCM debug screen     

    LCM_debugdata[21] = rec_crc_val; //write debug 1 in LCM debug screen 
    LCM_debugdata[22] = 0; //write debug 2 in LCM debug screen
    LCM_debugdata[23] = 0; //write debug 3 in LCM debug screen

    LCM_write(24, debug_startaddress, & LCM_debugdata); //function call to write data in debug screen

}
/************************************************************************************************/
//Function Name			: system_init
//Purpose               : To receive from LCM
// input                : - 
// output               : -

/************************************************************************************************/
void system_init() {
    RCONbits.SWDTEN = 1; //watch dog timer enable

    PLLFBD = (MUL - 2); //multiplier value
    CLKDIVbits.PLLPOST = (POST - 2); //divider value
    CLKDIVbits.PLLPRE = (PRE - 2); //divider value
    while (OSCCONbits.COSC != 0b011); //wait for clock switch to occur

    ACLKCONbits.ASRCSEL = 1; // primary oscillator provides input for Auxiliary PLL (x16)
    ACLKCONbits.SELACLK = 1; // Auxiliary Oscillator provides clock source for PWM & ADC
    ACLKCONbits.APSTSCLR = 6; //Divide Auxiliary clock by 2
    ACLKCONbits.ENAPLL = 1; // Enable Auxiliary PLL
    while (ACLKCONbits.APLLCK != 1); // Wait for Auxiliary PLL to Lock    

    TRISE = 0x0000; //relay driving pin's set as output
    TRISDbits.TRISD7 = 0; //relay_9 driving pin as output
    TRISGbits.TRISG3 = 0; //relay_10 driving pin as output
    TRISGbits.TRISG2 = 0; //relay_11 driving pin as output
    TRISDbits.TRISD0 = 0; //relay_12 driving pin as output
    TRISGbits.TRISG2 = 0; //timer 2 toggle pin direction as output
    TRISDbits.TRISD11 = 0; //timer 3 toggle pin direction as output
    TRISDbits.TRISD8 = 1; //input capture pin set as input
    PR_sen_dir = 1; //PR sense pin set as input        
    sys_led_dir = 0; //making led as output
    overtemp_dir = 1; //start condition input pin direction
    EandF_dir = 1; //EandF input pin direction
    load_sel_dir = 1;
}

/************************************************************************************************/
//Function Name			: config_pwm
//Purpose               : To configure PWM
//Description			: configure PWM registers to get the desired pulse output
//PWM formula           : phase2, s-phase2 = Ref-clk*desired PWM period / 7.37MHZ*1.04nS*pre-scalar

/************************************************************************************************/
void config_pwm() {
    unsigned long int SEC_phase = 0;
    PWMCON2bits.ITB = 1; // PHASEx/SPHASEx provides the PWM time period value
    PWMCON2bits.MDCS = 0; // PDC2 and SDC2 provides duty cycle value
    PWMCON2bits.DTC = 0b10; //Dead-time function is disabled

    IOCON2bits.PENH = 1; /* PWM Output pin control assigned to PWM generator */
    IOCON2bits.PENL = 1; /* PWM Output pin control assigned to PWM generator */
    IOCON2bits.POLH = 0; /* PWM O/P active high */
    IOCON2bits.POLL = 0; /* PWM O/P active high */
    IOCON2bits.PMOD = 0b11; // PWM I/O pin pair is in the True Independent Output mode

    PTCON2bits.PCLKDIV = PWM_prescalar; //pre-scalar
    PRI_phase = ((PRI_time_in_us * 100000) / (104 * pow(2, PWM_prescalar))); //((desired time) / (1.04nS * pre_scalar))
    PHASE2 = PRI_phase; // Primary phase shift value 
    SEC_phase = ((SEC_time_in_us * 100000) / (104 * pow(2, PWM_prescalar))); //((desired time) / (1.04nS * pre_scalar))
    SPHASE2 = SEC_phase; // Secondary phase shift value
    PDC2 = PRI_duty_cycle; // Independent Primary Duty Cycle is 50% of the period
    SDC2 = SEC_duty_cycle; // Independent Secondary Duty Cycle is 50% of the period

    PTCONbits.PTEN = 1; /* Enable High-Speed PWM module */
}
/************************************************************************************************/
//Function Name			: ADC_init
//Purpose			:ADC initialization
//Description			:To initialize ADC registers to read the voltage

/************************************************************************************************/
void ADC_init() {
    ADCONbits.ADON = 1; // turn ADC ON
    ADCONbits.SLOWCLK = 1; //ADC is clocked by the auxiliary PLL (ACLK)
    ADCONbits.FORM = 0; // Integer output
    ADCONbits.ADCS = 0b110; //Conversion Clock Divider.. minimum TAD is 35.8 nS as per electrical characteristics.
}
/************************************************************************************************/
//Function Name			: collect_adc_pair0
//Purpose               : To get ADC samples
// input                : none
// output               : It will return the measured DC voltage of AN0 and AN1 by getting desired samples.

/************************************************************************************************/
void collect_adc_pair0(unsigned int *adc_channel_0, unsigned int *adc_channel_1) {
    int sample;
    uint32_t adc_buffer1 = 0, adc_buffer2 = 0;
    for (sample = 0; sample < adcpair0_samp_count; sample++) { //sample count

        ADCPC0bits.TRGSRC0 = 0b00001; //Individual software trigger is selected
        ADCPC0bits.SWTRG0 = 1; //Starts conversion of AN0 and AN1 
        __delay32(100); //conversion time
        //while (ADSTATbits.P0RDY == 0); //Conversion Data for Pair 0 Ready 
        //ADSTATbits.P0RDY = 0;
        ADCPC0bits.PEND0 = 0; //Conversion is complete
        adc_buffer1 += ADCBUF0; //getting values from buffer
        adc_buffer2 += ADCBUF1; //getting values from buffer
        if (sample == adcpair0_samp_count - 1) {
            *adc_channel_0 = (adc_buffer1 / adcpair0_samp_count); //getting average of samples
            *adc_channel_1 = (adc_buffer2 / adcpair0_samp_count); //getting average of samples
#ifdef vt100
            printf("%c[5;17H %lu  ", 27, adc_channel_0); //to VT 100 terminal         
            printf("%c[5;28H %lu  ", 27, adc_channel_1); //to VT 100 terminal  
            printf("%c[7;17H %.3f A ", 27, adc_channel_0 / DC_ref); //to print AN0 voltage reference (2.5 = 409.2) (3.3 = 310)
            printf("%c[7;28H %.3f A ", 27, adc_channel_1 / DC_ref); //to print AN0 voltage reference (2.5 = 409.2) (3.3 = 310)
#endif

        }
    }
}
/************************************************************************************************/
//Function Name			: collect_adc_pair1
//Purpose               : To get ADC samples
// input                : none
// output               : It will return the measured DC voltage of AN2 and AN3 by getting desired samples.

/************************************************************************************************/
void collect_adc_pair1(unsigned int *adc_channel_2, unsigned int *adc_channel_3) {
    int sample;
    uint32_t adc_buffer1 = 0, adc_buffer2 = 0;
    for (sample = 0; sample < adcpair1_samp_count; sample++) { //sample count

        ADCPC0bits.TRGSRC1 = 0b00001; //Individual software trigger is selected
        ADCPC0bits.SWTRG1 = 1; //Starts conversion of AN3 and AN2 
        __delay32(100); //conversion time
        //while (ADSTATbits.P1RDY == 0); //Conversion Data for Pair 1 Ready 
        //ADSTATbits.P0RDY = 0;
        ADCPC0bits.PEND1 = 0; //Conversion is complete
        adc_buffer1 += ADCBUF2; //getting values from buffer
        adc_buffer2 += ADCBUF3; //getting values from buffer
        if (sample == adcpair1_samp_count - 1) {
            *adc_channel_2 = (adc_buffer1 / adcpair1_samp_count); //getting average of samples
            *adc_channel_3 = (adc_buffer2 / adcpair1_samp_count); //getting average of samples
#ifdef vt100
            printf("%c[5;39H %lu  ", 27, adc_buffer1); //to VT 100 terminal                
            printf("%c[5;50H %lu  ", 27, adc_buffer2); //to VT 100 terminal  
            printf("%c[7;39H %.3f A ", 27, adc_buffer1 / DC_ref); //to print AN0 voltage reference (2.5 = 409.2) (3.3 = 310)
            printf("%c[7;50H %.3f v ", 27, adc_buffer2 / DC_ref); //to print AN0 voltage reference (2.5 = 409.2) (3.3 = 310)
#endif

        }
    }
}
/************************************************************************************************/
//Function Name			: collect_adc_pair2
//Purpose               : To get ADC samples
// input                : none
// output               : It will return the measured DC voltage of AN4 and AN5 by getting desired samples.

/************************************************************************************************/
void collect_adc_pair2(unsigned int *adc_channel_4, unsigned int *adc_channel_5) { //sample count
    int sample;
    uint32_t adc_buffer1 = 0, adc_buffer2 = 0;
    for (sample = 0; sample < adcpair2_samp_count; sample++) {

        ADCPC1bits.TRGSRC2 = 0b00001; //Individual software trigger is selected
        ADCPC1bits.SWTRG2 = 1; //Starts conversion of AN5 and AN5 
        __delay32(100); //conversion time
        //while (ADSTATbits.P2RDY == 0); //Conversion Data for Pair 2 Ready 
        ADCPC1bits.PEND2 = 0; //Conversion is complete
        adc_buffer1 += ADCBUF4; //getting values from buffer
        adc_buffer2 += ADCBUF5; //getting values from buffer
        if (sample == adcpair2_samp_count - 1) {
            *adc_channel_4 = (adc_buffer1 / adcpair2_samp_count); //getting average of samples
            *adc_channel_5 = (adc_buffer2 / adcpair2_samp_count); //getting average of samples

#ifdef vt100
            printf("%c[5;61H %lu  ", 27, adc_buffer1); //to VT 100 terminal                       
            printf("%c[5;72H %lu  ", 27, adc_buffer2); //to VT 100 terminal
            printf("%c[7;61H %.3f v ", 27, adc_buffer1 / DC_ref); //to print AN0 voltage reference (2.5 = 409.2) (3.3 = 310)
            printf("%c[7;72H %.3f v ", 27, adc_buffer2 / DC_ref); //to print AN0 voltage reference (2.5 = 409.2) (3.3 = 310)
#endif


        }
    }
}

/************************************************************************************************/
//Function Name			: adc_pair8
//Purpose               : To get ADC samples
// input                : none
// output               : It will return the measured DC voltage of AN14 and AN15 by getting desired samples.
/************************************************************************************************/
/*
void collect_adc_pair7(unsigned int *AN14, unsigned int *AN15) {
    int sample;
    for (sample = 0; sample < adcpair8_samp_count; sample++) {
        static uint32_t adc_buffer1 = 0, adc_buffer2 = 0;
        ADCPC3bits.TRGSRC7 = 0b00001;//Individual software trigger is selected
        ADCPC3bits.SWTRG7 = 1;//Starts conversion of AN5 and AN5 
        while (ADSTATbits.P7RDY == 0);//Conversion Data for Pair 7 Ready 
        ADCPC3bits.PEND7 = 0;//Conversion is complete
        adc_buffer1 += ADCBUF14;//getting values from buffer
        adc_buffer2 += ADCBUF15;//getting values from buffer
        if (sample == adcpair8_samp_count - 1) {
            adc_buffer1 = (adc_buffer1 / adcpair8_samp_count);//getting average of samples
            adc_buffer2 = (adc_buffer2 / adcpair8_samp_count);//getting average of samples
            #ifdef vt100
            printf("%c%c%c%c%c%c%c %lu  ", 27, '[', '5', ';', '8', '3', 'H',adc_buffer1);   //to vt 100                           
            printf("%c%c%c%c%c%c%c %lu  ", 27, '[', '5', ';', '9', '4', 'H',adc_buffer2);//to vt 100        
            #endif
 *AN14 = (adc_buffer1 / current_resolution); //converting to phase current
 *AN15 = (adc_buffer2 / current_resolution);//converting to phase current
        }
    }
}*/
/************************************************************************************************/
//Function Name			: convert ADC data
//Purpose               : To convert ADC data to required display data
// input                : - 
// output               : -.

/************************************************************************************************/
void convert_adc_data() {
    if (adc_channel_0 > ADC_MAX)adc_channel_0 = ADC_MAX; //range limit setting
    if (adc_channel_1 > ADC_MAX)adc_channel_1 = ADC_MAX; //range limit setting
    if (adc_channel_2 > ADC_MAX)adc_channel_2 = ADC_MAX; //range limit setting
    if (adc_channel_3 > ADC_MAX)adc_channel_3 = ADC_MAX; //range limit setting
    if (adc_channel_4 > ADC_MAX)adc_channel_4 = ADC_MAX; //range limit setting
    if (adc_channel_5 > ADC_MAX)adc_channel_5 = ADC_MAX; //range limit setting

    Van = ((adc_channel_5 * 100000) / voltage_resolution); //ADC - voltage conversion with two decimal places
    Vbn = ((adc_channel_4 * 100000) / voltage_resolution); //ADC - voltage conversion
    Vcn = ((adc_channel_3 * 100000) / voltage_resolution); //ADC - voltage conversion  
    Ia = ((adc_channel_2 * 100000) / current_resolution); //ADC - voltage conversion
    Ib = ((adc_channel_1 * 100000) / current_resolution); //ADC - voltage conversion
    Ic = ((adc_channel_0 * 100000) / current_resolution); //ADC - voltage conversion

    AN0 = Van / 100; //converting to display format
    AN1 = Vbn / 100; //converting to display format
    AN2 = Vcn / 100; //converting to display format
    AN3 = Ia / 100; //converting to display format
    AN4 = Ib / 100; //converting to display format
    AN5 = Ic / 100; //converting to display format

    chn0_volt = ((adc_channel_0 * 100000) / DC_ref); //ADC - voltage conversion as per input voltage
    chn1_volt = ((adc_channel_1 * 100000) / DC_ref); //ADC - voltage conversion as per input voltage
    chn2_volt = ((adc_channel_2 * 100000) / DC_ref); //ADC - voltage conversion as per input voltage
    chn3_volt = ((adc_channel_3 * 100000) / DC_ref); //ADC - voltage conversion as per input voltage
    chn4_volt = ((adc_channel_4 * 100000) / DC_ref); //ADC - voltage conversion as per input voltage
    chn5_volt = ((adc_channel_5 * 100000) / DC_ref); //ADC - voltage conversion as per input voltage

    LCM_chn0_volt = chn0_volt / 100;
    LCM_chn1_volt = chn1_volt / 100;
    LCM_chn2_volt = chn2_volt / 100;
    LCM_chn3_volt = chn3_volt / 100;
    LCM_chn4_volt = chn4_volt / 100;
    LCM_chn5_volt = chn5_volt / 100;

    current = (((Ia + Ib + Ic) / 3)); //to find average voltage
    voltage = ((Van + Vbn + Vcn) / 3); //to find average current
    avgpower = ((voltage * current * 3) / 1000000); //to calculate power in KW
    power = avgpower; //getting the power obtained 
}
/************************************************************************************************/
//Function Name			: Timer2_init
//Purpose               :timer initialization
//Description			:To initialize timer registers to set the desired period
//                          Tcy = (pre-scalar * TMR register) / (Fcy)
//  Timer 2 clock_tick = 83.8848 mS
//  Timer 2 resolution = 1.28 uS

/************************************************************************************************/
void Timer2_init() {

    T2CONbits.TON = 0; // Stop any 16/32-bit Timer2 operation
    T2CONbits.TCS = 0; // Select internal instruction cycle clock
    T2CONbits.TGATE = 0; // Disable Gated Timer mode
    T2CONbits.TCKPS = t2_prescalar; // Select 1:64 Pre scaler
    TMR2 = 0x00; // Clear 16-bit Timer 
    PR2 = t2_periodvalue; // Load 16-bit period value 
    IPC1bits.T2IP = 8 - t2_int_priority; // Set Timer2 Interrupt Priority Level
    IFS0bits.T2IF = 0; // Clear Timer2 Interrupt Flag
    IEC0bits.T2IE = 1; // Enable Timer2 interrupt
    T2CONbits.TON = 1; // Start 16-bit Timer
}
/************************************************************************************************/
//Function Name			: Timer3_init
//Purpose               :timer 3 initialization
//Description			:To initialize timer registers to set the desired period
//                          Tcy = (pre-scalar * TMR register) / (Fcy)
//  Timer 3 clock_tick = 1.25 mS
//  Timer 3 resolution = 5.12 uS

/************************************************************************************************/
void Timer3_init() {

    T3CONbits.TON = 0; // Stop any 16/32-bit Timer2 operation
    T3CONbits.TCS = 0; // Select internal instruction cycle clock
    T3CONbits.TGATE = 0; // Disable Gated Timer mode
    T3CONbits.TCKPS = t3_prescalar; // Select 1:256 Pre scaler
    TMR3 = 0x00; // Clear 32-bit Timer 
    deb_freq = 195312 / (vt_number * 2); //(Fcy / pre scalar)/(desired frequency)  i.e 50M/256 = 195312
    PR3 = deb_freq; //t3_period value; // Load 16-bit period value
    IPC2bits.T3IP = 8 - t2_int_priority; // Set Timer3 Interrupt Priority Level
    IFS0bits.T3IF = 0; // Clear Timer3 Interrupt Flag
    IEC0bits.T3IE = 1; // Enable Timer3 interrupt
    T3CONbits.TON = 1; // Start 16-bit Timer
}

/************************************************************************************************/
//Function Name			: Timer4_init
//Purpose               :timer 4 initialization
//Description			:To initialize timer registers to set the desired period
//                          Tcy = (pre-scalar * TMR register) / (Fcy)
//  Timer 4 clock_tick = 1.25 mS
//  Timer 4 resolution = 5.12 uS

/************************************************************************************************/
void Timer4_init() {

    T4CONbits.TON = 0; // Stop any 16/32-bit Timer2 operation
    T4CONbits.TCS = 0; // Select internal instruction cycle clock
    T4CONbits.TGATE = 0; // Disable Gated Timer mode
    T4CONbits.TCKPS = t4_prescalar; // Select 1:256 Pre scaler
    TMR4 = 0x00; // Clear 32-bit Timer 

    PR3 = t4_periodvalue; //t3_period value; // Load 16-bit period value
    IPC6bits.T4IP = 1; // Set Timer3 Interrupt Priority Level
    IFS1bits.T4IF = 0; // Clear Timer3 Interrupt Flag
    IEC1bits.T4IE = 1; // Enable Timer3 interrupt
    T4CONbits.TON = 1; // Start 16-bit Timer
}
/************************************************************************************************/
// function name : getq_serial1
// purpose       : if there is data in que return the data otherwise returns null..qcount should be checked for nonzero before calling this .
// input         : none
// output        : returns the  byte from que

/************************************************************************************************/
uint8_t getq_serial1(void) {
    uint8_t serialdata;
    if (serial1.qcount != 0) // check whether que is not empty
    {
        serialdata = serial1.qdata[serial1.qout]; // get the data from the que
        --serial1.qcount; // decrement the qcount
        if (serial1.qout == (MAX_QSER - 1)) serial1.qout = 0; // if the que is full clear the qout...round robin
        else ++serial1.qout; // increment the .qout
        return serialdata; // return the ser data
    }// end of outer if loop
    else return (0x0); // return 0x00 for no data.this is only standby ...main checking always from calling program for qempty before calling this
} // end of function
/************************************************************************************************/
// function name : getq_serial2
// purpose       : if there is data in que return the data otherwise returns null..qcount should be checked for nonzero before calling this .
// input         : none
// output        : returns the  byte from que

/************************************************************************************************/
uint8_t getq_serial2(void) {
    uint8_t serialdata;
    if (serial2.qcount != 0) // check whether que is not empty
    {
        serialdata = serial2.qdata[serial2.qout]; // get the data from the que
        --serial2.qcount; // decrement the qcount
        if (serial2.qout == (MAX_QSER - 1)) serial2.qout = 0; // if the que is full clear the qout...round robin
        else ++serial2.qout; // increment the .qout
        return serialdata; // return the ser data
    }// end of outer if loop
    else return (0x0); // return 0x00 for no data.this is only standby ...main checking always from calling program for qempty before calling this
} // end of function

/************************************************************************************************/
//Function Name			: Serial_init
//Purpose               : UART initialization
//Description			: Initialize UART registers to get the data out

/************************************************************************************************/
void Serial_init() {
    U1MODEbits.STSEL = 0; // 1-Stop bit
    U1MODEbits.PDSEL = 0; // No Parity, 8-Data bits
    U1MODEbits.ABAUD = 0; // Auto-Baud disabled
    U1MODEbits.BRGH = 0; // Standard-Speed mode
    U1BRG = BRGVAL; // Baud Rate setting		 
    U1STAbits.UTXISEL0 = 0; // Interrupt after one TX character is transmitted
    U1STAbits.UTXISEL1 = 0; //Interrupt when a character is transferred to the Transmit Shift Register
    U1STAbits.URXISEL = 0; // Interrupt after one RX character is received;    
    IEC0bits.U1RXIE = 1; // Enable UART 1 RX interrupt
    IPC2bits.U1RXIP = 8 - u1_rx_int_priority; //UART1 interrupt priority
    U1MODEbits.UARTEN = 1; // Enable UART
    U1STAbits.UTXEN = 1; // Enable 1 UART TX


    U2MODEbits.STSEL = 0; // 1-Stop bit
    U2MODEbits.PDSEL = 0; // No Parity, 8-Data bits
    U2MODEbits.ABAUD = 0; // Auto-Baud disabled
    U2MODEbits.BRGH = 0; // Standard-Speed mode
    U2BRG = BRGVAL; // Baud Rate setting 
    U2STAbits.UTXISEL0 = 0; // Interrupt after one TX character is transmitted
    U2STAbits.UTXISEL1 = 0; //Interrupt when a character is transferred to the Transmit Shift Register
    U2STAbits.URXISEL = 0; // Interrupt after one RX character is received;    
    IEC1bits.U2RXIE = 1; // Enable UART 2 RX interrupt
    IPC7bits.U2RXIP = 8 - u2_rx_int_priority; //UART2 interrupt priority
    U2MODEbits.UARTEN = 1; // Enable UART
    U2STAbits.UTXEN = 1; // Enable 2 UART TX

}

void putch(uint8_t byt) //for transmitting the char from standard printf function
{
    while (!U1STAbits.TRMT);
    U1TXREG = byt;
}
/************************************************************************************************/
//Function Name			: Serial1_write_byte
//Purpose                :write UART1 byte
//Description			:To write UART1 bytes in UART1 buffer

/************************************************************************************************/
void Serial1_write_byte(uint8_t byte) //for transmitting one single byte definition
{
    while (!U1STAbits.TRMT); //waiting for last transmitted char
    U1TXREG = byte; //transmit a char in UART buffer
}
/************************************************************************************************/
//Function Name			: Serial1_write_string
//Purpose                :write UART string
//Description			:To write UART1 strings in UART1 buffer by splitting it in to bytes

/************************************************************************************************/
void Serial1_write_string(char *str) //for transmitting entire string definition
{
    while (*str) {
        Serial1_write_byte(*str++); //string to byte
    }
}
/************************************************************************************************/
//Function Name			: Serial1_write_number
//Purpose                :write UART number
//Description			:To write UART1 numbers in UART1 buffer by converting it in to strings

/************************************************************************************************/
void Serial1_write_number(uint16_t num) //to transmit a number by converting it to string
{
    uint8_t num_count = 0, divd;
    char num_str[7]; //array for converted number
    uint16_t dividend;
    for (divd = 4; divd >= 1; divd--) { //size of number
        if (num / pow(10, divd) || num_count) { //getting MSW of number
            dividend = pow(10, divd); //getting the dividend
            num_str[num_count++] = (num / dividend) | 0x30; //storing the numbers in arrays position     
            num = num % dividend; //eliminating the last number
        }
    }
    num_str[num_count++] = num | 0x30; //converting decimal number to asci value
    num_str[num_count] = '\0'; //adding null char to last byte
    Serial1_write_string(num_str); //passing the converted number in string format
}
/************************************************************************************************/
//Function Name			: Serial2_write_byte
//Purpose                :write UART byte
//Description			:To write UART2 bytes in UART2 buffer

/************************************************************************************************/
void Serial2_write_byte(uint8_t byte) { //for transmitting one single byte definition
    while (!U2STAbits.TRMT); //waiting for last transmitted char
    U2TXREG = byte; //transmit a char in UART buffer
}

/************************************************************************************************/
//Function Name			: Serial2_write_string
//Purpose                :write UART string
//Description			:To write UART2 strings in UART2 buffer by splitting it in to bytes

/************************************************************************************************/
void Serial2_write_string(char *str) { //to transmit a number by converting it to string
    while (*str) {
        Serial2_write_byte(*str++); //string to byte
    }
}
/************************************************************************************************/
//Function Name			: Serial2_write_number
//Purpose                :write UART number
//Description			:To write UART2 numbers in UART2 buffer by converting it in to strings

/************************************************************************************************/
void Serial2_write_number(uint16_t num) { //to transmit a number by converting it to string
    uint8_t num_count = 0, divd;
    char num_str[7]; //array for converted number
    uint16_t dividend;
    for (divd = 4; divd >= 1; divd--) { //size of number
        if (num / pow(10, divd) || num_count) { //getting MSW of number
            dividend = pow(10, divd); //getting the dividend
            num_str[num_count++] = (num / dividend) | 0x30; //storing the numbers in arrays position        
            num = num % dividend; //eliminating the last number
        }
    }
    num_str[num_count++] = num | 0x30; //converting decimal number to asci value
    num_str[num_count] = '\0'; //adding null char to last byte
    Serial2_write_string(num_str); //passing the converted number in string format
}


/************************************************************************************************/
//Function Name			: capture init
//Purpose           	: capture initialization
//Description			: To initialize capture registers to read the frequency

/************************************************************************************************/
void capture_init() {
    IC1CONbits.ICM = 0b00; // Disable Input Capture 1 module
    IC1CONbits.ICTMR = 1; // Select Timer2 as the IC1 Time base
    IC1CONbits.ICI = 0b00; // Interrupt on every capture event

    // Enable Capture Interrupt And Timer2
    IPC0bits.IC1IP = 8 - cap_int_priority; // Setup IC1 interrupt priority level
    IFS0bits.IC1IF = 0; // Clear IC1 Interrupt Status Flag
    IEC0bits.IC1IE = 1; // Enable IC1 interrupt
}
/************************************************************************************************/
//Function Name			: captured frequency
//Purpose                :To get frequency samples
//Description			:It will return the measured captured frequency by getting desired samples.

/************************************************************************************************/
void collect_input_capture(unsigned long *frequency) {
    unsigned long int total_sampled_time = 0, time = 0;
    unsigned char count = 0, sample;
    unsigned short int time_period = 0;
    IC1CONbits.ICM = 0b011; //turn on capture module
    __delay32(Fcy / 500); //wait for 2mS to initialize capture module
    for (sample = 0; sample < cap_samp_count; sample++) {
        if (completed == 1) { //when pulse time captured         
            first = 0; //end of pulse is captured
            time_period = ((PR2 - captured_1st_IC1) + captured_2nd_IC1); //pulse captured 
            completed = 0; //conversion process over
            total_sampled_time += time_period; //collects all the time period duration
            count++;
            if (count == cap_samp_count) { //when count reaches desired samples
                count = 0; //reset the count
                IC1CONbits.ICM = 0b00; //turn off capture module
                total_sampled_time = (total_sampled_time / cap_samp_count); //average of samples
                time = ((cap_prescalar * total_sampled_time) / FREQ_cycle); //((pre-scalar*total_sampled_time)/(FCY/1000)) to get in mS;
#ifdef vt100
                printf("%c[11;32H %.4f mS   ", 27, time); //to vt100
                printf("%c[11;45H %.2f   ", 27, total_sampled_time); //to vt100
#endif
#ifdef LCM
                LCM_debugdata[16] = total_sampled_time; //total_sampled_time;
#endif
                *frequency = (Fcy * 10 / (cap_prescalar * total_sampled_time)); // to find frequency 
                LCM_debugdata[12] = *frequency; //write frequency in LCM debug screen
                *frequency = ((*frequency + 4) / 10);
                total_sampled_time = 0;
            }
            __delay32(500000); //wait 10mS for another pulse
        }
    }

}
/************************************************************************************************/
//Function Name			: capture2 init
//Purpose           	: capture initialization
//Description			: To initialize capture registers to read the frequency

/************************************************************************************************/
void capture2_init() {
    IC2CONbits.ICM = 0b00; // Disable Input Capture 1 module
    IC2CONbits.ICTMR = 1; // Select Timer2 as the IC1 Time base
    IC2CONbits.ICI = 0b00; // Interrupt on every capture event

    // Enable Capture Interrupt And Timer2
    IPC1bits.IC2IP = 8 - cap_int_priority; // Setup IC1 interrupt priority level
    IFS0bits.IC2IF = 0; // Clear IC1 Interrupt Status Flag
    IEC0bits.IC2IE = 1; // Enable IC1 interrupt
}
/************************************************************************************************/
//Function Name			: captured2 frequency
//Purpose                :To get frequency samples
//Description			:It will return the measured captured frequency by getting desired samples.

/************************************************************************************************/
void captured2_frequency(unsigned long *frequency_2) {
    unsigned long int total_sampled_time = 0, time = 0;
    unsigned char count = 0, sample;
    unsigned short int time_period = 0;
    for (sample = 0; sample < cap_samp_count; sample++) {
        if (completed_2 == 1) { //when pulse time captured         
            first2 = 0; //end of pulse is captured
            time_period = ((PR2 - captured_1st_IC2) + captured_2nd_IC2); //pulse captured 
            completed_2 = 0; //conversion process over
            total_sampled_time += time_period; //collects all the time period duration
            count++;
            if (count == cap_samp_count) { //when count reaches desired samples
                count = 0; //reset the count
                IC2CONbits.ICM = 0b00; //turn off capture module
                total_sampled_time = (total_sampled_time / cap_samp_count); //average of samples
                time = ((cap_prescalar * total_sampled_time) / FREQ_cycle); //((pre-scalar*total_sampled_time)/(FCY/1000)) to get in mS;
#ifdef vt100
                printf("%c[11;32H %.4f mS   ", 27, time); //to vt100
                printf("%c[11;45H %.2f   ", 27, total_sampled_time); //to vt100
#endif
#ifdef LCM
                LCM_debugdata[17] = total_sampled_time; //total_sampled_time;
#endif
                *frequency_2 = (1000 / time); // to find frequency                   
                total_sampled_time = 0;
            }
            __delay32(500000); //wait 10mS for another pulse
        }
    }

}

/************************************************************************************************/
//Function Name			: capture3 init
//Purpose           	: capture initialization
//Description			: To initialize capture registers to read the frequency

/************************************************************************************************/
void capture3_init() {
    IC3CONbits.ICM = 0b00; // Disable Input Capture 1 module
    IC3CONbits.ICTMR = 1; // Select Timer2 as the IC1 Time base
    IC3CONbits.ICI = 0b00; // Interrupt on every capture event

    // Enable Capture Interrupt And Timer2
    IPC9bits.IC3IP = 8 - cap_int_priority; // Setup IC1 interrupt priority level
    IFS2bits.IC3IF = 0; // Clear IC1 Interrupt Status Flag
    IEC2bits.IC3IE = 1; // Enable IC1 interrupt
}
/************************************************************************************************/
//Function Name			: captured frequency
//Purpose                :To get frequency samples
//Description			:It will return the measured captured frequency by getting desired samples.

/************************************************************************************************/
void captured3_frequency(unsigned long *frequency_3) {
    unsigned long int total_sampled_time = 0, time = 0;
    unsigned char count = 0, sample;
    unsigned short int time_period = 0;
    for (sample = 0; sample < cap_samp_count; sample++) {
        if (completed_3 == 1) { //when pulse time captured         
            first3 = 0; //end of pulse is captured
            time_period = ((PR2 - captured_1st_IC3) + captured_2nd_IC3); //pulse captured 
            completed_3 = 0; //conversion process over
            total_sampled_time += time_period; //collects all the time period duration
            count++;
            if (count == cap_samp_count) { //when count reaches desired samples
                count = 0; //reset the count
                IC3CONbits.ICM = 0b00; //turn off capture module
                total_sampled_time = (total_sampled_time / cap_samp_count); //average of samples
                time = ((cap_prescalar * total_sampled_time) / FREQ_cycle); //((pre-scalar*total_sampled_time)/(FCY/1000)) to get in mS;
#ifdef vt100
                printf("%c[11;32H %.4f mS   ", 27, time); //to vt100
                printf("%c[11;45H %.2f   ", 27, total_sampled_time); //to vt100
#endif
#ifdef LCM
                LCM_debugdata[18] = total_sampled_time; //total_sampled_time;
#endif
                *frequency_3 = (1000 / time); // to find frequency                   
                total_sampled_time = 0;
            }
            __delay32(500000); //wait 10mS for another pulse
        }
    }

}
/************************************************************************************************/
//Function Name			: clear_screen
//Purpose               : To clear the entire screen
//Description			: It will clear the entire VT100, Lab-view and LCM screen

/************************************************************************************************/
void clear_screen() {
#ifdef vt100
    printf("%c[2J", 27); //to clear the entire VT screen
#endif
#ifdef LCM  //to clear the entire LCM screen
    LCM_write(8, mainscreen_startaddress, & LCM_screendata);
    LCM_write(24, debug_startaddress, & LCM_debugdata);
    LCM_write(1, load_selection_addr, & LCM_screendata);
    LCM_write(1, slider_address, & LCM_screendata);
    LCM_write(1, local_remote_addr, & LCM_screendata);
    LCM_write(4, PWM_start_addr, & LCM_debugdata);
#endif
    __delay32(Fcy / 400);
#ifdef labview  ////to clear the entire labview screen
    Serial2_write_byte(0x40);
    Serial2_write_byte(0x40);
    Serial2_write_byte(0x40);
    Serial2_write_byte(0x40);
#endif
    __delay32(Fcy / 400);
}
/************************************************************************************************/
//Function Name			: write checksum
//Purpose               : To find the checksum
//Description			: It will find the checksum and store it

/************************************************************************************************/
void write_checksum(unsigned int add) //to add checksum and write to uart
{
    checksum = ((checksum ^ ((add & 0xff00) >> 8)) ^ (add & 0x00ff)); //ex-or operation for previous byte and new byte
}
/************************************************************************************************/
//Function Name			: Lab_screen_data
//Purpose                :To write the lab screen data
//Description			:It will split the data byte and write in LCM screen.

/************************************************************************************************/
void Lab_screen_data(unsigned int send) {
    Serial2_write_byte((send & 0xff00) >> 8); //send MSW
    Serial2_write_byte(send & 0x00ff); //send LSW
}
/************************************************************************************************/
//Function Name			: labview_receive_process
//Purpose                :To get data from lab view
//Description			:It will receive data from lab view using FIFI logic store the address bytes.

/************************************************************************************************/
void labview_receive_process() {
    for (receive_count = 0; receive_count < 10; receive_count++) {
        unsigned char received_char;
        if (serial2.qcount != 0) // check whether que is not empty
        {
            received_char = getq_serial2();
            if ((received_char == 0xa5) || (buffer == 5)) //when receiving start byte or buffer fulls reset the array
            {
                buffer = 0;
            }
            labview_receive[buffer++] = received_char; //storing the received data in array
        }
    }

    if (labview_receive[0] == lab_recv_byte) //indicates the start byte  
    {
        switch (labview_receive[1]) {   //address byte
            case 0x00:lab_relay_drive = labview_receive[2];
                lab_relay_drive = lab_relay_drive / 8;
                break;
            case 0x23:byp_int = labview_receive[2]; //data byte
                break;
            case 0x33:lab_load_sel = labview_receive[2];//data byte
                break;
            default:
                break;
        }
    }
}
/************************************************************************************************/
//Function Name			: labview_write_process
//Purpose                :To write data to lab view
//Description			:It will find the checksum and digital inputs ,then write the data to lab view terminal

/************************************************************************************************/
void labview_write_process() {
    unsigned char indication = 0;
    
    /****   Digital input process   ****/
    if (PR_sense == 1) { //if phase reversal not detected 
        __delay32(Fcy / 1000);
        if (PR_sense == 1) {
            indication = 0; //phase reversal data
        }
    } else if (PR_sense == 0) { //if phase reversal detected
        __delay32(Fcy / 1000);
        if (PR_sense == 0) {
            indication = 1; //phase reversal data
        }
    }
    if (EandF == NOTFOUND) //feedback input is normal
    {
        indication &= ~(1 << 1); //display in screen as WHITE           
    } else if (EandF == FOUND) //feedback input is not found
    {
        indication |= (1 << 1); //display in screen as GREEN
    }

    if (overtemp_ind == NORMAL) //over temperature is normal
    {
        __delay32(Fcy / 1000);
        if (overtemp_ind == NORMAL) //over temperature is normal
        {
            indication &= ~(1 << 2); //led indication off
        }
    } else if (overtemp_ind == FAULT) //over temperature indication
    {
        __delay32(Fcy / 1000);
        if (overtemp_ind == FAULT) //over temperature indication
        {
            indication |= (1 << 2); //display in screen as red
        }
    }

    /****checksum finding process****/
    write_checksum(labstart_byte); //add to checksum 
    write_checksum(AN0); //add to checksum 
    write_checksum(AN1); //add to checksum 
    write_checksum(AN2); //add to checksum 
    write_checksum(AN3); //add to checksum 
    write_checksum(AN4); //add to checksum 
    write_checksum(AN5); //add to checksum
    write_checksum(power); //add to checksum 
    write_checksum(frequency); //add to checksum 
    write_checksum(indication); //led operation 

    /****   write to lab view terminal process ****/
    Serial2_write_byte(labstart_byte);
    Lab_screen_data(AN0);   //write to lab view terminal
    Lab_screen_data(AN1);   //write to lab view terminal
    Lab_screen_data(AN2);   //write to lab view terminal
    Lab_screen_data(AN3);   //write to lab view terminal
    Lab_screen_data(AN4);   //write to lab view terminal
    Lab_screen_data(AN5);   //write to lab view terminal
    Lab_screen_data(power); //write to lab view terminal
    Lab_screen_data(frequency);//write to lab view terminal
    Lab_screen_data(indication);//write to lab view terminal
    Serial2_write_byte(checksum); //write checksum
}
/************************************************************************************************/
//Function Name			: labview_relay_drive
//Purpose                :To drive the relays
//Description			:It will drive the relays based on the user input's 

/************************************************************************************************/
void labview_relay_drive() {
    if (system == REMOTE && overtemp_ind == NORMAL && lab_load_sel == 0x50) {
        switch (lab_relay_drive) {
            case 0: relay_drive_port = 0x00;
                relay_9 = 0; //turn off relay 9  
                relay_10 = 0;
                break;
            case 1: relay_drive_port = r1_relay; //load selector relay 1
                relay_9 = 0; //turn off relay 9 
                relay_10 = 0;
                break;
            case 2:relay_drive_port = r2_relay; //load selector relay 2
                relay_9 = 0; //turn off relay 9 
                relay_10 = 0;
                break;
            case 3:relay_drive_port = r3_relay; //load selector relay 3
                relay_9 = 0; //turn off relay 9
                relay_10 = 0;
                break;
            case 4:relay_drive_port = r4_relay; //load selector relay 4
                relay_9 = 0; //turn off relay 9
                relay_10 = 0;
                break;
            case 5:relay_drive_port = r5_relay; //load selector relay 5
                relay_9 = 0; //turn off relay 9
                relay_10 = 0;
                break;
            case 6:relay_drive_port = r6_relay; //load selector relay 6
                relay_9 = 0; //turn off relay 9
                relay_10 = 0;
                break;
            case 7:relay_drive_port = r7_relay; //load selector relay 7
                relay_9 = 0; //turn off relay 9
                relay_10 = 0;
                break;
            case 8:
                relay_9 = 0; //turn off relay 9
                relay_10 = 0;
                relay_drive_port = r8_relay; //load selector relay 8
                break;
            case 9:
                relay_9 = 1; //turn on relay 9
                relay_10 = 0;
                relay_drive_port = r8_relay; //load selector relay 8
                break;
            case 10:
                relay_9 = 1; //turn on relay 10
                relay_10 = 1;
                relay_drive_port = r8_relay; //to retain the last data
                break;

            default: break;

        }
    }
    if (system == REMOTE) {
        switch (byp_int) {
            case 0x53:
                byp_inter = 1; //bypass mode  
                break;
            case 0x57:
                byp_inter = 0; //interlock mode    
                break;
        }

        if (overtemp_ind == FAULT || lab_load_sel == 0x55) {
            __delay32(Fcy / 1000);
            if (overtemp_ind == FAULT || lab_load_sel == 0x55) //load selector switch
            {
                relay_10 = 0; //turn off relay 10
                relay_9 = 0; //turn off relay 9
                relay_drive_port = 0x00; //turn off all led                                                    
            }
        }
    }

}
/************************************************************************************************/
//Function Name			: VT100_receive_process
//Purpose                :To receive data from VT100 terminal
//Description			:It will receive the data from terminal for debugging process

/************************************************************************************************/
void VT100_receive_process() {
    for (receive_count = 0; receive_count < 10; receive_count++) {
        unsigned char received_char;
        if (serial1.qcount != 0) // check whether que is not empty
        {
            received_char = getq_serial1();
            if ((received_char == 0x57) || (buffer == 5)) //when receiving start byte or buffer fulls reset the array
            {
                buffer = 0;
            }
            vt_receive[buffer++] = received_char; //storing the received data in array
        }
    }

    if (vt_receive[0] == 0x57) //if start byte for VT 100 have received
        vt_number = ((((((vt_receive[1]&0xf0) >> 4)*10)+(vt_receive[1]&0x0f))*100)+((((vt_receive[2]&0xf0) >> 4)*10)+(vt_receive[2]&0x0f))); //convert received hex to decimal 
    printf("%d %d %d  %d   ", vt_receive[0], vt_receive[1], vt_receive[2], vt_number); //to debug

    deb_freq = 195312 / (vt_number * 2); //(Fcy / pre scalar)/(desired frequency)  i.e 50M/256 = 195312
    PR3 = deb_freq; //t3_period value; 
}
/************************************************************************************************/
//Function Name			: VT100_display_process
//Purpose               :To display the data to VT100 terminal
//Description			:It will write the data to VT100 terminal

/************************************************************************************************/
void VT100_display_process() {
    printf("%c[2;15H MAK LOAD BANK TESTING  LBA-1.0", 27); //to print header
    printf("%c[4;17H ch0 ", 27); //to print CH0
    printf("%c[4;28H ch1 ", 27); //to print CH0
    printf("%c[4;39H ch2 ", 27); //to print CH0
    printf("%c[4;50H ch3 ", 27); //to print CH0
    printf("%c[4;61H ch4 ", 27); //to print CH0
    printf("%c[4;72H ch5 ", 27); //to print CH0

    printf("%c[5;3H ADC data    : ", 27); //to print "ADC data"
    printf("%c[6;3H AC voltage  : ", 27); //to print "AC voltage"
    printf("%c[11;3H Captured   :  ", 27); //to print "captured"
    printf("%c[7;3H DC voltage  : ", 27); //to print "AC voltage"

    printf("%c[6;17H %d A ", 27, AN0); //to print AN0 voltage
    printf("%c[6;28H %d A ", 27, AN1); //to print AN1 voltage
    printf("%c[6;39H %d A ", 27, AN2); //to print AN2 voltage
    printf("%c[6;50H %d v ", 27, AN3); //to print AN3 current
    printf("%c[6;61H %d v ", 27, AN4); //to print AN4 current
    printf("%c[6;72H %d v ", 27, AN5); //to print AN5 current             

    printf("%c[10;18H Frequency ", 27); //to print "frequency"
    printf("%c[10;32H Time ", 27); //to print "time"
    printf("%c[10;45H cap_reg ", 27); //to print "cap reg"

    printf("%c[11;18H %ld HZ  ", 27, frequency); //to print frequency
    printf("%c[16;10H%c Power  :  %.3lf kW", 27, (power / 10));

    printf("%c[17;10H debug  :  ", 27);
}
