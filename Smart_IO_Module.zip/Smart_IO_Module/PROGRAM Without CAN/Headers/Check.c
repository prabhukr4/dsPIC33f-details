
//    RX2_data[rx2_count] = U2RXREG; // if the que is not full insert the data into the array
//    if(RX2_data[0] == MOD_SLAVE_ID && rx2_count<=99)    // if the character is slave id, then only it accept to receive data
//    {
//        MOD.Slave_flag = true;                      // For next step go to MODBUS.h and collect query from master
//        rx2_count++;                            // Need to Receive the perfect commands
//    }
//    else
//    {
//        MOD.Slave_flag = false;
//        rx2_count=0;
//    }

////--------------------------------------------------------------------------------------------------------------------------------
//    if(MOD.Slave_flag == true)                                      // When slave id matches the flag will set
//    {
//        switch(RX2_data[1])
//        {
//            case MOD_READ_FUN_CODE:                                 // 03
//                    MODrx.Data_length = MOD_READ_FUN_LENGTH;              //8, if Function code is 0x03-Read Holding register, that have totally 8 bytes for query
//                    MOD.Read_flag = true;
//                    break;
//            case MOD_SINGLE_WRITE_FUN_CODE:                         // 06
//                    MODrx.Data_length = MOD_SINGLE_WRITE_FUN_LENGTH;      //8, if Function code is 0x06-Write Single register, that have totally 8 bytes for query
//                    MOD.Single_Write_flag = true;
//                    break;
//            case MOD_MULTI_WRITE_FUN_CODE:                          // 16
//                    MODrx.Data_length = MOD_MULTI_WRITE_FUN_LENGTH;       //19, if Function code is 0x10-Write Single register, that have totally 19 bytes for query
//                    MOD.Multi_Write_flag = true;
//                    break;
//            default:
//                MOD.Read_flag = false;
//                MOD.Single_Write_flag = false;
//                MOD.Multi_Write_flag = false;
//        }
//    }
//    if(rx2_count >= MODrx.Data_length-1)                              // Function code based the Data length will assigned, depends on the received data is loaded to MODrx.Array 
//    {
//         MOD.Buff_full = true;                                      // As per the format of data, the Buffer is Full, means ready to Process or respond
//         for(x=0; x<MODrx.Data_length; x++)                           // Data_length is 18; 0-17
//         {
//             MODrx.Array[x] = RX2_data[x];
//         }
//         rx2_count = 0;                                         // After data loaded to MODrx.Array rx2_count is Zero
//    }
//------------------------------------------------------------------------------------------------------------------------------------ 