//  Timer definitions
#define timer2_toggle PORTGbits.RG2  //timer 2 toggler pin
#define timer3_toggle PORTDbits.RD11  //timer 3 toggler pin  //RG3/RD11
#define t2_periodvalue 0xffff   //((prescalar * t3_periodvalue) / FCY) //time_duration to clock_tick = 83.88 mS
#define t4_periodvalue 7812 //for 10mS 
#define t2_int_priority 4   //timer 2 interrupt priority
#define t2_prescalar 0b10   //1:64 prescalar
#define t4_prescalar 0b10   //1:64 prescalar
#define t3_periodvalue 244  // ((prescalar * t3_periodvalue) / FCY) //time_duration = 1.250mS
#define t3_int_priority 5   //timer 3 interrupt priority
#define t3_prescalar 0b11   //1:256 prescalar

/************************************************************************************************/
//Function Name			: Timer2_init
//Purpose               :timer initialization
//Description			:To initialize timer registers to set the desired period
//                          Tcy = (pre-scalar * TMR register) / (Fcy)
//  Timer 2 clock_tick = 83.8848 mS
//  Timer 2 resolution = 1.28 uS

/************************************************************************************************/
void Timer2_init() {

    T2CONbits.TON = 0; // Stop any 16/32-bit Timer2 operation
    T2CONbits.TCS = 0; // Select internal instruction cycle clock
    T2CONbits.TGATE = 0; // Disable Gated Timer mode
    T2CONbits.TCKPS = t2_prescalar; // Select 1:64 Pre scaler
    TMR2 = 0x00; // Clear 16-bit Timer 
    PR2 = t2_periodvalue; // Load 16-bit period value 
    IPC1bits.T2IP = 8 - t2_int_priority; // Set Timer2 Interrupt Priority Level
    IFS0bits.T2IF = 0; // Clear Timer2 Interrupt Flag
    IEC0bits.T2IE = 1; // Enable Timer2 interrupt
    T2CONbits.TON = 1; // Start 16-bit Timer
}
/*******************************************************************************/
/*                              Interrupt Function                             */
/*                                for timer 2                                  */
/*                        time_duration  = 83.88 mS                            */
// resolution = 1.28 uS

/*******************************************************************************/

void __attribute__((__interrupt__, __no_auto_psv__)) _T2Interrupt(void) {
    //timer2_toggle = ~timer2_toggle; //toggling the timer 2 pin
    cap_clk_tick++; //check for capture operation clock_tick
    clock_tick++;

    IFS0bits.T2IF = 0; // Clear Timer2 Interrupt Flag
}
/************************************************************************************************/
//Function Name			: Timer3_init
//Purpose               :timer 3 initialization
//Description			:To initialize timer registers to set the desired period
//                          Tcy = (pre-scalar * TMR register) / (Fcy)
//  Timer 3 clock_tick = 1.25 mS
//  Timer 3 resolution = 5.12 uS

/************************************************************************************************/
void Timer3_init() {

    T3CONbits.TON = 0; // Stop any 16/32-bit Timer2 operation
    T3CONbits.TCS = 0; // Select internal instruction cycle clock
    T3CONbits.TGATE = 0; // Disable Gated Timer mode
    T3CONbits.TCKPS = t3_prescalar; // Select 1:256 Pre scaler
    TMR3 = 0x00; // Clear 32-bit Timer 
    deb_freq = 195312 / (vt_number * 2); //(Fcy / pre scalar)/(desired frequency)  i.e 50M/256 = 195312
    PR3 = deb_freq; //t3_period value; // Load 16-bit period value
    IPC2bits.T3IP = 8 - t2_int_priority; // Set Timer3 Interrupt Priority Level
    IFS0bits.T3IF = 0; // Clear Timer3 Interrupt Flag
    IEC0bits.T3IE = 1; // Enable Timer3 interrupt
    T3CONbits.TON = 1; // Start 16-bit Timer
}
/*******************************************************************************/
/*                              Interrupt Function                             */
/*                                for timer 3                                  */
/*           resolution = 5.12 uS             resolution = 3HZ                 */

/*******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _T3Interrupt(void) {

    timer3_toggle = ~timer3_toggle; //toggling the timer 3 pin
    IFS0bits.T3IF = 0; // Clear Timer3 Interrupt Flag
}

/************************************************************************************************/
//Function Name			: Timer4_init
//Purpose               :timer 4 initialization
//Description			:To initialize timer registers to set the desired period
//                          Tcy = (pre-scalar * TMR register) / (Fcy)
//  Timer 4 clock_tick = 1.25 mS
//  Timer 4 resolution = 5.12 uS

/************************************************************************************************/
void Timer4_init() {

    T4CONbits.TON = 0; // Stop any 16/32-bit Timer2 operation
    T4CONbits.TCS = 0; // Select internal instruction cycle clock
    T4CONbits.TGATE = 0; // Disable Gated Timer mode
    T4CONbits.TCKPS = t4_prescalar; // Select 1:256 Pre scaler
    TMR4 = 0x00; // Clear 32-bit Timer 

    PR3 = t4_periodvalue; //t3_period value; // Load 16-bit period value
    IPC6bits.T4IP = 1; // Set Timer3 Interrupt Priority Level
    IFS1bits.T4IF = 0; // Clear Timer3 Interrupt Flag
    IEC1bits.T4IE = 1; // Enable Timer3 interrupt
    T4CONbits.TON = 1; // Start 16-bit Timer
}


/*******************************************************************************/
/*                              Interrupt Function                             */
/*                                for timer 4                                  */
/*           resolution = 1.28 uS             overflow = 10mS                  */

/*******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _T4Interrupt(void) {
    cap2_clk_tick++; //check for capture operation clock_tick
    cap3_clk_tick++; //check for capture operation clock_tick 
    IFS1bits.T4IF = 0; // Clear Timer3 Interrupt Flag
}









