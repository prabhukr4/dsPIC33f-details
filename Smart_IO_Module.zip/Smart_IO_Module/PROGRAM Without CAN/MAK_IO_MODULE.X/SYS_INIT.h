#ifndef _STS_INIT_H_
#define _SYS_INIT_H_
#include "DEFINITIONS.h"        // defined All variables constant value
/********************************************************************************************
 *
 *  FILE NAME    :   SYS_INIT.h
 *  PURPOSE      :   System Initializations of MAK IO MODULE Project
 *                  
 ********************************************************************************************/
void System_init(void)
{        
    Oscillator_init();                  // Oscillator, PLL upto 100MHZ setting and Auxiliary Clock for PWM and ADC initializations
    IO_init();                          // Inputs and Outputs Directions initializations
    DataEEInit();                       // Library init function to Use Internal Flash as EEPROM
    Get_SI_BAUD();                      // Get Slave iD and Baud rate from EEPROM
    UART_init();                        // Serial communication functions initializations
    Timer2_init();                      // 10ms Clock tick timer initializations
    ADC_init();                         // ADC related functions initializations
    PWM_init();                         // PWM function and setting initializations
    //I2C_init();                       // For EEPROM
    RCONbits.SWDTEN = 1;                // watch dog timer enable
}
/************************************************************************************************/
//Function Name			: Oscillator_init
//Purpose               : Internal Oscillator Configuration
//Description			: Boost the input clock by PLL upto 100MHz
//Formula               : time per Cycle= 1/100MHz = 10ns, Machine cycle is 1 instruction/2 cycle
//                      : 20ns (i.e) operate at 50MIPS                
/************************************************************************************************/
void Oscillator_init()
{   
    PLLFBD = (MUL_EXT - 2);             //multiplier value
    CLKDIVbits.PLLPOST = (POST - 2);    //divider value
    CLKDIVbits.PLLPRE = (PRE - 2);      //divider value
    while (OSCCONbits.COSC != 0b011);   //wait for clock switch to occur
    ACLKCONbits.ASRCSEL = 1;            // primary oscillator provides input for Auxiliary PLL (x16)
    ACLKCONbits.SELACLK = 1;            // Auxiliary Oscillator provides clock source for PWM & ADC
    ACLKCONbits.APSTSCLR = 6;           // Divide Auxiliary clock by 2
    ACLKCONbits.ENAPLL = 1;             // Enable Auxiliary PLL
    while (ACLKCONbits.APLLCK != 1);    // Wait for Auxiliary PLL to Lock   
}
/************************************************************************************************
 * Function Name		: Get_SI_BAUD
 * Purpose              : Get Slave iD and Baud rate from EEPROM
 * Description			: Read Internal EEPROM
************************************************************************************************/
void Get_SI_BAUD()
{
    if(DataEERead(EEPROM_BAUD_RATE_LOCATION) > 0x0f)
    {
        DataEEWrite(01,EEPROM_SLAVE_ID_LOCATION);      // Write Slave ID to EEPROM
        DataEEWrite(07,EEPROM_BAUD_RATE_LOCATION);     // Write Baud value to EEPROM  
        DataEEWrite(01,EEPROM_SLAVE_ID_LOCATION);      // Write Slave ID to EEPROM
        DataEEWrite(07,EEPROM_BAUD_RATE_LOCATION);     // Write Baud value to EEPROM
    }
    MOD_SLAVE_ID = DataEERead(EEPROM_SLAVE_ID_LOCATION);                // Get Slave ID from EEPROM
    MOD_BAUDRATE = Get_Baud(DataEERead(EEPROM_BAUD_RATE_LOCATION));     // Get Baudrate from EEPROM
}
/************************************************************************************************
 * Function Name		: IO_init
 * Purpose              : Input and Output Configurations
 * Description			: Get the input state and Number of upward and downward counts
************************************************************************************************/
void IO_init()
{
/****************** INPUT AND OUTPUT DIRECTION *********************/     
    PA0_INPUT_DIR   =   1;      // Pin as Digital input 5/3.3V TTL
    PA1_INPUT_DIR   =   1;      // Pin as Digital input 5/3.3V TTL
    PA2_INPUT_DIR   =   1;      // Pin as Digital input 5/3.3V TTL
    PA3_INPUT_DIR   =   1;      // Pin as Digital input 5/3.3V TTL
    PA4_INPUT_DIR   =   1;      // Pin as Digital input 5/3.3V TTL
    PA5_INPUT_DIR   =   1;      // Pin as Digital input 5/3.3V TTL
    PA6_INPUT_DIR   =   1;      // Pin as Digital input 5/3.3V TTL
    PA7_INPUT_DIR   =   1;      // Pin as Digital input 5/3.3V TTL
    
    PB0_INPUT_DIR   =   1;      // Pin as Digital input 24V TTL
    PB1_INPUT_DIR   =   1;      // Pin as Digital input 24V TTL
    PB2_INPUT_DIR   =   1;      // Pin as Digital input 24V TTL
    PB3_INPUT_DIR   =   1;      // Pin as Digital input 24V TTL
    PB4_INPUT_DIR   =   1;      // Pin as Digital input 24V TTL
    PB5_INPUT_DIR   =   1;      // Pin as Digital input 24V TTL
    PB6_INPUT_DIR   =   1;      // Pin as Digital input 24V TTL
    PB7_INPUT_DIR   =   1;      // Digital input 24V TTL Input Pin
    // Output
    PD0_OUT_DIR     =   0;      // Pin as Digital OUTPUT
    PD1_OUT_DIR     =   0;      // Pin as Digital OUTPUT
    PD2_OUT_DIR     =   0;      // Pin as Digital OUTPUT
    PD3_OUT_DIR     =   0;      // Pin as Digital OUTPUT
    PD4_OUT_DIR     =   0;      // Pin as Digital OUTPUT
    PD5_OUT_DIR     =   0;      // Pin as Digital OUTPUT
    PD6_OUT_DIR     =   0;      // Pin as Digital OUTPUT
    PD7_OUT_DIR     =   0;      // Pin as Digital OUTPUT
    
    // RS485 Enable and Status LED pins
    STATUS_LED_DIR  =   0;      // PIN as Digital OUTPUT    
    
}
/************************************************************************************************
 * Function Name		: Timer2_init
 * Purpose              : timer initialization
 * Description			: To initialize timer registers to set the desired period
 *                        Tcy = (pre-scalar * TMR register) / (Fcy) = (64 * 7813)/50000000=10 mS
 *                        Timer 2 clock_tick = 10 mS
 *                        Timer 2 resolution = 1.28 uS
************************************************************************************************/
void Timer2_init() 
{
    T2CONbits.TON = 0;                      // Stop any 16/32-bit Timer2 operation
    T2CONbits.TCS = 0;                      // Select internal instruction cycle clock
    T2CONbits.TGATE = 0;                    // Disable Gated Timer mode
    T2CONbits.TCKPS = Timer2_Prescallar;    // Select 1:64 Pre scaler
    TMR2 = 0x00;                            // Clear 16-bit Timer 
    PR2 = Timer2_Period;                    // Load 16-bit period value 
    IPC1bits.T2IP = Timer2_Interrupt_Priority; // Set Timer2 Interrupt Priority Level
    IFS0bits.T2IF = 0;                      // Clear Timer2 Interrupt Flag
    IEC0bits.T2IE = 1;                      // Enable Timer2 interrupt
    T2CONbits.TON = 1;                      // Start 16-bit Timer
}
#endif