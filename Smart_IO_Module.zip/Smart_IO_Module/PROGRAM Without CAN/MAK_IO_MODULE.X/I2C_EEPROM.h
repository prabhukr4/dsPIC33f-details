/********************************************************************************************
 *
 *  FILE NAME    :   I2C_EEPROM.h
 *  PURPOSE      :   I2C with EEPROM communications and related function definitions
 *                  
 ********************************************************************************************/
#ifndef _I2C_EEPROM_H_
#define _I2C_EEPROM_H_

/**********************************************************************************************
 * FUNCTION NAME:   i2c_init();
 * DESCRIPTION  :   Initialization for I2C and Fixed baud rate for EEPROM communication
 * Formula      :   Baud Rate Register I2CxBRG    =   [(1/FSCL - Delay)* FCY/2]-2 ---> Delay is nominal from 110ns to 130ns
 *                                                      =   [(1/400KHZ - 120ns) * (50MHZ/2)]-2
 *                                                      =   57...
**********************************************************************************************/ 
void i2c_init()
{
    I2C1CONbits.I2CEN   =   0;          // Disables the I2C1 module
    I2C1CONbits.I2CSIDL =   0;          // Continues the module operation in the Idle mode
    I2C1CONbits.A10M    =   0;          // I2CxADD register is a 7-bit slave address
    I2C1CONbits.DISSLW  =   0;          // Slew rate control is enabled
    I2C1CONbits.SMEN    =   0;          // Disables the SMBus input thresholds
    I2C1CONbits.STREN   =   1;          // Enables the user software or the receive clock stretching
    I2C1CONbits.ACKEN   =   1;          // Acknowledge Sequence Enable bit (I2C Master mode receive operation)
    I2C1BRG             =   57;         // Baud rate Register 400KHz for EEPROM Communication
    I2C1CONbits.I2CEN   =   1;          // Enables the I2C1 module
}


/*******************************************************************************************************
 * Function Name    : i2c_write();
 * Description      : Write the data to corresponding EEPROM memory address
*******************************************************************************************************/
void i2c_write(unsigned char EE_addr,unsigned char EE_data)
{
    I2C1CONbits.SEN = 1;            // Start bit
	while(I2C1CONbits.SEN);         // Wait till the Start bit is completed  
	i2c_send(EEPROM_WRITE);			// Address with WRITE of the slave module
    i2c_send(EE_addr);				// Address or location, where u want right
	i2c_send(EE_data);				// Mention the location u have to put the data
	I2C1CONbits.PEN = 1;			// Stop Bit
	while(I2C1CONbits.PEN);         // Wait till the Stop bit is completed
}

/*******************************************************************************************************
 * Function Name    : i2c_wait();
 * Description      : Whether the data is transmitted or Not
 *                    TRSTAT: Transmit Status bit (when operating as I2C master, applicable to master transmit operation)
 *                    1 = Master transmit is in progress (8 bits + ACK)
 *                    0 = Master transmit is not in progress
*******************************************************************************************************/
void i2c_wait()
{
    while(!I2C1STATbits.TRSTAT);        // Transmit Status bit
    I2C1STATbits.TRSTAT = 0;            // Clear Transmit Status
    __delay32(1000);                    // Delay
}


/*******************************************************************************************************
 * Function Name    : i2c_Send();
 * Description      : Put the data to Master Transmitting and check status and Ack from slave
 *                    ACKSTAT: Acknowledge Status bit (when operating as I2C? master, applicable to master transmit operation)
 *                    1 = NACK received from slave
 *                    0 = ACK received from slave
*******************************************************************************************************/
void i2c_send(unsigned char i2c_data)
{
    I2C1TRN = i2c_data;             // Load the data to corresponding TX register
    i2c_wait();                     // Wait the Tx complete 
    while(1) 
    {
        if(!I2C1STATbits.ACKSTAT)   // Check the ACK Receives or Not
        {break;}
    } 
}

/*******************************************************************************************************
 * Function Name    : i2c_read()
 * Description      : Get the data from EEPROM and Return type function
 * 
*******************************************************************************************************/
unsigned char i2c_read(unsigned char location)
{
   unsigned char RX_EEPROM;
    I2C1CONbits.SEN = 1;			// Start bit
	while(I2C1CONbits.SEN);         // Wait till the Start bit is completed
	i2c_send(EEPROM_WRITE);			// Address with WRITE of the slave module
	i2c_send(location);				// Address or location, where u want right
	I2C1CONbits.RSEN = 1;			// Stop and Restart
	while(I2C1CONbits.RSEN);        // Wait till the ReStart bit is completed -- STOP then START
	i2c_send(EEPROM_READ);			// Address with READ the slave location
	I2C1CONbits.RCEN = 1;			// Receive Enable bit from slave
    while(!I2C1STATbits.RBF);       // Wait till the Receive buffer is full
	RX_EEPROM = I2C1RCV;            // Get the data from corresponding receive buffer
	I2C1CONbits.PEN = 1;			// Stop Bit
	while(I2C1CONbits.PEN);         // Wait till the Stop bit is completed
	return(RX_EEPROM);
}

#endif