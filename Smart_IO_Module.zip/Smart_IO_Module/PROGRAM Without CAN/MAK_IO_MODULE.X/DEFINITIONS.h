/********************************************************************************************
 *
 *  FILE NAME    :   DEFINITIONS.h
 *  PURPOSE      :   MAK IO MODULE Project's all Defined Functions
 *                  
 ********************************************************************************************/
#ifndef _DEFINITIONS_H_
#define _DEFINITIONS_H_
//#define vt100                                 // For vt 100 display
#define LED_Blink_Delay     100                 // (100*10ms = 1000ms = 1sec) led toggle delay
// HIGH and LOW
#define HIGH    1                               // Set HIGH as 1
#define LOW     0                               // Set LOW as 0
// PLL definition
#define MUL_EXT             25                  // Externl Oscillator multiplier for PLL
#define MUL_INT             55                  // Internal Oscillator multiplier for PLL (internal FRC Clock 7.37Mhz)
#define POST                2                   // postscalar for PLL
#define PRE                 2                   // prescalar for PLL
#define Fcy                 50000000            // 50MIPS

// ADC Definitions
#define ADC_SAMPLE          100                 // Sample Count
#define ADC_REF             2500                // Reference Voltage in mV
#define MAX_ADC_VALUE       2500                // ADC maximum value
#define MAX_ADC_COUNT       1023                // ADC maximum counts

//  PWM definitions
#define REF_CLK             120000000               // Reference Clock for PWM
#define CLOCK_SOURCE        16.28222                // (ReferenceClock/7.37Mhz) = (120000000/7370000) 
#define PWM_prescalar       0b110                   // Divide-by-64, maximum PWM timing resolution
#define PWM_CLK_DIV         64                      // PWM Clock divider
#define PWM1_Period         0.001337709             // User input PWM period in Sec(1/Frequency)
#define PWM2_Period         0.00001                 // User input PWM period in Sec(1/Frequency)
#define PWM3_Period         0.00002                 // User input PWM period in Sec(1/Frequency)
#define PWM4_Period         0.00004                 // User input PWM period in Sec(1/Frequency)
       
       
// TIMER 2 Definitions
#define Timer2_Prescallar           0b10        //1:64 prescalar
#define Timer2_Period               7813        // 10ms Clocktick   
#define Timer2_Interrupt_Priority   3           // Priority 3

// MODBUS or RS232
//#define MOD_SLAVE_ID              0x01
#define MOD_READ_FUN_CODE           0x03        // MODBUS Read function code
#define MOD_SINGLE_WRITE_FUN_CODE   0x06        // MODBUS Single Preset regsiter function code
#define MOD_MULTI_WRITE_FUN_CODE    0x10        // MODBUS Multiple Preset regsiter function code
#define MOD_READ_FUN_LENGTH         8           // MODBUS Read function data length
#define MOD_REQ_STATUS_FUN_CODE     0x0C        // MOD Request count read Function code
#define MOD_SINGLE_WRITE_FUN_LENGTH 8           // MODBUS Single Preset function data length
#define MOD_MULTI_WRITE_FUN_LENGTH  9           // MODBUS Multiple Preset function data length Without data bytes
#define MOD_REQ_STATUS_FUN_LENGTH   4           // MOD data length

#define RS232_START_ADDR            0x24        // $    RS232 Start Address
#define RS232_END_ADDR              0x23        // #    RS232 End Address
#define RS232_WRITE_FUN_CODE        0x80        // RS232 Write function code
#define RS232_READ_FUN_CODE         0x81        // RS232 Read Function code
#define RS232_REQ_STATUS_FUN_CODE   0x82        // RS232 Request count read Function code
#define RS232_WRITE_FUN_LENGTH      5           // RS232 data length
#define RS232_READ_FUN_LENGTH       5           // RS232 data length
#define RS232_REQ_STATUS_FUN_LENGTH 5           // RS232 data length

#define UART1_INT_PRIORITY          7           // UART 1 Interrupt prioroty
#define UART2_INT_PRIORITY          6           // UART 2 Interrupt prioroty

// I2C with EEPROM
#define EEPROM_READ                 0b10100001  // 0xA1 -- Slave Address(EEPROM) with Read Operation
#define EEPROM_WRITE                0b10100000  // 0xA0 -- Slave Address(EEPROM) with Write Operation
#define EEPROM_SLAVE_ID_LOCATION    0x04        // Holds the address of Slave ID location
#define EEPROM_BAUD_RATE_LOCATION   0x05        // Holds the address of Baud rate location

// Time Delay for Input status Check
#define INPUT_SURG_TIME_DELAY             10          // 10ms ISR * 10 = 100ms

/*-------------------- ARRAY BUFFER POSITION ---------------------------------*/
// Product Information
#define INFO_STRING            "MAK_IO_MODULE_V1"
#define INFO_BUF_POS           0
// DIGITAL INPUT PA and PB (1Byte)
#define PA_INPUT_BUF_POS       16
#define PB_INPUT_BUF_POS       17
// PA Input's 5/3.3V TTL No.of Input and Output Pulse Counts (1Byte)
#define PA0_UP_BUF_POS         18   
#define PA0_DOWN_BUF_POS       19  
#define PA1_UP_BUF_POS         20
#define PA1_DOWN_BUF_POS       21
#define PA2_UP_BUF_POS         22
#define PA2_DOWN_BUF_POS       23
#define PA3_UP_BUF_POS         24
#define PA3_DOWN_BUF_POS       25
#define PA4_UP_BUF_POS         26
#define PA4_DOWN_BUF_POS       27
#define PA5_UP_BUF_POS         28
#define PA5_DOWN_BUF_POS       29
#define PA6_UP_BUF_POS         30
#define PA6_DOWN_BUF_POS       31
#define PA7_UP_BUF_POS         32
#define PA7_DOWN_BUF_POS       33
// PB Input's 24v TTL No.of Input and Output Pulse Counts (1Byte)
#define PB0_UP_BUF_POS         34
#define PB0_DOWN_BUF_POS       35
#define PB1_UP_BUF_POS         36
#define PB1_DOWN_BUF_POS       37
#define PB2_UP_BUF_POS         38
#define PB2_DOWN_BUF_POS       39
#define PB3_UP_BUF_POS         40
#define PB3_DOWN_BUF_POS       41
#define PB4_UP_BUF_POS         42
#define PB4_DOWN_BUF_POS       43
#define PB5_UP_BUF_POS         44
#define PB5_DOWN_BUF_POS       45
#define PB6_UP_BUF_POS         46
#define PB6_DOWN_BUF_POS       47
#define PB7_UP_BUF_POS         48
#define PB7_DOWN_BUF_POS       49
// ADC INPUT Result (2Bytes)
#define P0_ADC_BUF_POS         50
#define P1_ADC_BUF_POS         52
#define P2_ADC_BUF_POS         54
#define P3_ADC_BUF_POS         56

// PWM OUTPUT in HZ (2Bytes
#define C0_PWM_BUF_POS         58
#define C1_PWM_BUF_POS         60
#define C2_PWM_BUF_POS         62
#define C3_PWM_BUF_POS         64

// DIGITAL OUTPUT (1Byte
#define PD_OUTPUT_BUF_POS      66
#define RESERVED               67                     // Not used


/**********DIGITAL INPUT DEFINITIONS **************/
// PA0-7 Directions
#define PA0_INPUT_DIR           TRISEbits.TRISE5
#define PA1_INPUT_DIR           TRISEbits.TRISE6
#define PA2_INPUT_DIR           TRISEbits.TRISE7
#define PA3_INPUT_DIR           TRISGbits.TRISG6
#define PA4_INPUT_DIR           TRISGbits.TRISG7
#define PA5_INPUT_DIR           TRISGbits.TRISG8
#define PA6_INPUT_DIR           TRISGbits.TRISG9
#define PA7_INPUT_DIR           TRISBbits.TRISB8
// PB0-7 Directions
#define PB0_INPUT_DIR           TRISBbits.TRISB15       //8
#define PB1_INPUT_DIR           TRISBbits.TRISB14       //9
#define PB2_INPUT_DIR           TRISBbits.TRISB13       //10
#define PB3_INPUT_DIR           TRISBbits.TRISB12       //11
#define PB4_INPUT_DIR           TRISDbits.TRISD0        //12
#define PB5_INPUT_DIR           TRISDbits.TRISD11       //13
#define PB6_INPUT_DIR           TRISDbits.TRISD10       //14
#define PB7_INPUT_DIR           TRISDbits.TRISD9        //15

// PA0-7 Inputs
#define PA0_INPUT_PIN           PORTEbits.RE5
#define PA1_INPUT_PIN           PORTEbits.RE6
#define PA2_INPUT_PIN           PORTEbits.RE7
#define PA3_INPUT_PIN           PORTGbits.RG6
#define PA4_INPUT_PIN           PORTGbits.RG7
#define PA5_INPUT_PIN           PORTGbits.RG8
#define PA6_INPUT_PIN           PORTGbits.RG9
#define PA7_INPUT_PIN           PORTBbits.RB8
// PB0-7 Inputs
#define PB0_INPUT_PIN           PORTBbits.RB15
#define PB1_INPUT_PIN           PORTBbits.RB14
#define PB2_INPUT_PIN           PORTBbits.RB13
#define PB3_INPUT_PIN           PORTBbits.RB12
#define PB4_INPUT_PIN           PORTDbits.RD0
#define PB5_INPUT_PIN           PORTDbits.RD11
#define PB6_INPUT_PIN           PORTDbits.RD10
#define PB7_INPUT_PIN           PORTDbits.RD9

/**********DIGITAL OUTPUT DEFINITIONS **************/
// PD0-7 Directions
#define PD0_OUT_DIR           TRISCbits.TRISC14
#define PD1_OUT_DIR           TRISDbits.TRISD1
#define PD2_OUT_DIR           TRISDbits.TRISD2
#define PD3_OUT_DIR           TRISDbits.TRISD3
#define PD4_OUT_DIR           TRISDbits.TRISD4
#define PD5_OUT_DIR           TRISDbits.TRISD5
#define PD6_OUT_DIR           TRISDbits.TRISD6
#define PD7_OUT_DIR           TRISDbits.TRISD7

// PD0-7 Outputs
#define PD0_OUT_PIN           PORTCbits.RC14
#define PD1_OUT_PIN           PORTDbits.RD1
#define PD2_OUT_PIN           PORTDbits.RD2
#define PD3_OUT_PIN           PORTDbits.RD3
#define PD4_OUT_PIN           PORTDbits.RD4
#define PD5_OUT_PIN           PORTDbits.RD5
#define PD6_OUT_PIN           PORTDbits.RD6
#define PD7_OUT_PIN           PORTDbits.RD7

                 

/*************** Status LED and RS485 *******************/
// Directions
#define STATUS_LED_DIR        TRISCbits.TRISC13 
// Pins
#define STATUS_LED            PORTCbits.RC13

#endif