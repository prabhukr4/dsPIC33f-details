/********************************************************************************************
 *
 *  FILE NAME    :   PWM.h
 *  PURPOSE      :   PWM generation with fixed frequency and variable duty cycle
 *                
 ********************************************************************************************/
#ifndef _PWM_H_
#define _PWM_H_

#include "DEFINITIONS.h"
/************************************************************************************************
Function Name		  : PWM_init
Purpose               : To configure PWM
Description			  : configure PWM registers to get the desired pulse output
PWM formula           : phase2, s-phase2 = Ref-clk*desired PWM period / 7.37MHZ*1.04nS*pre-scalar
                      : PHASEx/SPHASEx(Period) = ((120000000 * 8 * Period/Prescalar)-8)/2;
                      : PDCx/SDCx(duty) = (Ref.Clock * desired_period*duty(in %)/1.04ns* Prescallar*100
                      : PWM duty cycle is defined by, ex. PWM period/2 = 50% duty, PWM period / 3 = 25% duty   
PINS ARE (PWMxH)      : PHASEx and PDCx controls PWMxH pin
PINS ARE (PWMxL)      : SPHASEx and SDCx controls PWMxL pin
Variables used        : PWM1_Period, PWM2_Period, PWWM3_Period, PWM4_Period, PWM1_duty, PWM2_duty, PWM3_duty, PWM4_duty
************************************************************************************************/
void PWM_init() 
{
    PTCONbits.PTEN  = 0;                    // PWM module is disabled
    PTCON2bits.PCLKDIV = PWM_prescalar;     // Primary -- 1:64 Pre scalar 
    STCON2bits.PCLKDIV = PWM_prescalar;     // Secondary -- 1:64 Pre scalar 
    //PTCONbits.EIPU     = 1;               // Active Period register is updated immediately
    //STCONbits.EIPU     = 1;               // Active Secondary Period register is updated immediately.
    // PWM 1H and PWM 1L Configuration
    PWMCON1bits.ITB = 1;                    // PHASEx/SPHASEx provides the PWM time period value
    PWMCON1bits.MDCS = 0;                   // PDC1 and SDC1 provides duty cycle value
    PWMCON1bits.DTC = 0b10;                 //Dead-time function is disabled
    IOCON1bits.PENH = 1;                    // PWM Output pin control assigned to PWM generator
    IOCON1bits.PENL = 1;                    // PWM Output pin control assigned to PWM generator 
    IOCON1bits.POLH = 0;                    // PWM O/P active high
    IOCON1bits.POLL = 0;                    // PWM O/P active high 
    IOCON1bits.PMOD = 0b11;                 // PWM I/O pin pair is in the True Independent Output mode
    // PWM 2H and PWM 2L Configuration
    PWMCON2bits.ITB = 1;                    // PHASEx/SPHASEx provides the PWM time period value
    PWMCON2bits.MDCS = 0;                   // PDC2 and SDC2 provides duty cycle value
    PWMCON2bits.DTC = 0b10;                 // Dead-time function is disabled
    IOCON2bits.PENH = 1;                    // PWM Output pin control assigned to PWM generator 
    IOCON2bits.PENL = 1;                    // PWM Output pin control assigned to PWM generator 
    IOCON2bits.POLH = 0;                    // PWM O/P active high 
    IOCON2bits.POLL = 0;                    // PWM O/P active high 
    IOCON2bits.PMOD = 0b11;                 // PWM I/O pin pair is in the True Independent Output mode
    PTCONbits.PTEN  = 1;
    // PWM 1&2- H and L with Individual Period(PHASEx and SPHASEx Register) and Duty cycle(PDCx and SDCx Register)
    PERIOD  =   ((((REF_CLK * 8 * PWM1_Period)/PWM_CLK_DIV)-8)/2);      // Period of the PWM pulse
    PHASE1  =   PERIOD;                     // Load the PWM Period value to Corresponding Register
    SPHASE1 =   PERIOD;                     // Load the PWM Period value to Corresponding Register
    PHASE2  =   PERIOD;                     // Load the PWM Period value to Corresponding Register
    SPHASE2 =   PERIOD;                     // Load the PWM Period value to Corresponding Register
    PDC1    =   0;                          // Initial value for Duty
    SDC1    =   0;                          // Initial value for Duty 
    PDC2    =   0;                          // Initial value for Duty
    SDC2    =   0;                          // Initial value for Duty 
}


/************************************************************************************************
 * Function Name		: Update_PWM_duty_cycle
 * Purpose              : To update each PWM duty cycle (in percentage) 
 *                      : PWM 1 have 30% duty cycle--> Update_PWM_duty_cycle(1,30);
 * Description			: PHASE1 is PWM1's 1HIGH, SPHASE1 PWM1's 1LOW and PHASE2 is PWM2's 2HIGH, SPHASE2 PWM2's 2LOW
 *                      : PDCx/SDCx = (PERIOD * PWM_Duty)/100;
**************************************************************************************************/
void Update_PWM_duty_cycle()
{
    unsigned char duty1,duty2,duty3,duty4;
    duty1 = DATA_ARRAY[C0_PWM_BUF_POS+1];               // Load the duty percentage to variable
    duty2 = DATA_ARRAY[C1_PWM_BUF_POS+1];               // Load the duty percentage to variable
    duty3 = DATA_ARRAY[C2_PWM_BUF_POS+1];               // Load the duty percentage to variable
    duty4 = DATA_ARRAY[C3_PWM_BUF_POS+1];               // Load the duty percentage to variable
    //printf("%c[1;10HPER-%d  P1-%d  P2-%d  P3-%d  p4-%d",27,PERIOD,duty1,duty2,duty3,duty4);
    PWM1_duty = (PERIOD/100)*duty1;                     // Get the duty percentage value
    PWM2_duty = (PERIOD/100)*duty2;                     // Get the duty percentage value 
    PWM3_duty = (PERIOD/100)*duty3;                     // Get the duty percentage value 
    PWM4_duty = (PERIOD/100)*duty4;                     // Get the duty percentage value 
    //printf("%c[3;10HP1-%ld  P2-%ld  P3-%ld  p4-%ld",27,PWM1_duty,PWM2_duty,PWM3_duty,PWM4_duty);
    PDC1    =   (unsigned int)PWM2_duty;          // H    2     Load to Corresponding register
    SDC1    =   (unsigned int)PWM1_duty;          // L    1     Load to Corresponding register
    PDC2    =   (unsigned int)PWM4_duty;          // H    4     Load to Corresponding register
    SDC2    =   (unsigned int)PWM3_duty;          // L    3     Load to Corresponding register
}
#endif