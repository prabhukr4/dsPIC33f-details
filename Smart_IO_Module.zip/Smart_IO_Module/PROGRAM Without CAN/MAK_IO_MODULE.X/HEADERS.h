
/********************************************************************************************
 *
 *  FILE NAME    :   HEADERS.h
 *  PURPOSE      :   MAK IO MODULE Project's Header files declarations
 *                  
 ********************************************************************************************/
#ifndef _HEADERS_H_
#define _HEADERS_H_
// System Headers
#include "xc.h"
#include<libpic30.h>            //to include delay header and c30 UART header
#include<stdbool.h>             //to include boolean operation
#include<stdint.h>              //to include standard integer types per ISO/IEC 9899:1999
#include<string.h>              //to include Strings operations
#include<math.h>                //to include mathematical operations
#include<stdio.h>               //to include standard i/o function header
//User defined Headers
#include "DEE Emulation 16-bit.h" // Library for Use internal Flash as EEPROM
#include "DEFINITIONS.h"        // defined All variables constant value
#include "GLOBEL.h"             // variable Globel declarations
#include "FUNCTIONS.h"          // Function declarion 
#include "ADC.h"                // Analog to digital convertion process function definitions
#include "UART.h"               // Both uart 1 and 2 initialization and function definitions
#include "PWM.h"                // PWM time period and Duty cycle configuration and function definitions
#include "MAIN_FUNCTION.h"      // Main function's elabrate description 
#include "MODBUS.h"             // Modbus protocol format description and function definitions
#include "RS232_CONFIG.h"       // RS285 baudrate and Slave id selection configuration and its function definitions
#include "I2C_EEPROM.h"         // I2C Functions Read/Write functions
#include "VT_100.h"             // Terminal view purpose
#include "CRC_CALC.H"           // Code Redundancy Check functions for MODbus Protocol
#include "ISR.h"                // Project all Interrupt Service Routine function definitions
#include "SYS_INIT.h"           // Module initializations 

#endif

