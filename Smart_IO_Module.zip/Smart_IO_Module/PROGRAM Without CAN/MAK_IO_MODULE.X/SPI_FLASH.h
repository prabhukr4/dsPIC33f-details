/********************************************************************************************
 *
 *  FILE NAME    :   SPI_FLASH.h
 *  PURPOSE      :   Store and get data from FLASH by SPI communication
 *                  
 ********************************************************************************************/
/************************************************************************************************
 * Function Name	: SPI_init
 * Purpose          : SPI synchronous configuration
 * Description		: 
 * Formula          : SPI CLK FREQ = Fcy/(Primary Pre scalar x Secondary Pre scalar)
************************************************************************************************/
// SPI
#define SPI2_PRIMARY_PRESCALLAR     0b11        // Prescallar is 1
#define SPI2_SECONDARY_PRESCALLAR   0b111
#define SPI2_INTERRUPT_PRIORITY     0b111       // Highest interrupt Priority
void SPI_init()
{
    /* The following code sequence shows SPI register configuration for Master mode */
    
    // SPI1CON1 Register Settings
    SPI1CON1bits.DISSCK = 0;                        //  serial clock is enabled
    SPI1CON1bits.DISSDO = 0;                        // SDOx pin is controlled by the module
    SPI1CON1bits.MODE16 = 1;                        // Communication is word-wide (16 bits)
    SPI1CON1bits.MSTEN = 1;                         // Master mode enabled
    SPI1CON1bits.SMP = 0;                           // Input data is sampled at the middle of data output time
    SPI1CON1bits.CKE = 0;                           // Serial output data changes on transition from
    // Idle clock state to active clock state
    SPI1CON1bits.CKP = 0;                           // Idle state for clock is a low level;
    // Pre scalar  
    SPI1CON1bits.PPRE = SPI2_PRIMARY_PRESCALLAR;    // Pre scalar  primary and secondary is 1:1
    SPI1CON1bits.SPRE = SPI2_SECONDARY_PRESCALLAR;
    // Interrupt Controller Settings
    IPC8bits.SPI2IP = SPI2_INTERRUPT_PRIORITY;      // Highest Interrupt Priority
    IFS0bits.SPI1IF = 0;                            // Clear the Interrupt flag
    IEC0bits.SPI1IE = 1;                            // Enable the interrupt
    // SPI Enable
    SPI1STATbits.SPIEN = 1;                         // Enable SPI module
}