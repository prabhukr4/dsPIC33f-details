/*****************************************************************************/
/********************************************************************************************
 *
 *  FILE NAME    :   ISR.h
 *  PURPOSE      :   MAK IO MODULE Project's all Interrupt Service Routines are Monitoring
 *                  
 ********************************************************************************************/
#ifndef _ISR_H_
#define _ISR_H_

/*********************************************************************************************
 * 
 *                              Interrupt Function                             
 *                for UART1 receive  RS232 Receiver Interrupt
 * 
 ********************************************************************************************/
void __attribute__((__interrupt__, __no_auto_psv__)) _U1RXInterrupt(void) 
{
    RS232.Receive_data = U1RXREG;                                               // Receive the Serial data   
    
    if(!RS232.Buff_full)                                                        // Buffer full or Not Status update
     {
        if(!RS232.SI_FC_Entry)                                                  // if the Start ID and Function entry is zero(avoid re entry to ID and code checking)
        {
            if(RS232.Receive_data == RS232_START_ADDR )                          // Check the Slave ID
            {
                RS232.Array[RS232.count] = RS232.Receive_data;                  // Store the 0th byte in array              
                goto last;                                                      // If the right data is received and stored then goto End of the loop, for avoid reload the data                          
            }
       
           else if(RS232.Receive_data == RS232_READ_FUN_CODE && RS232.Array[0] == RS232_START_ADDR)    // Checking the 1st byte is read function
           {
               RS232.Array[++RS232.count] = RS232.Receive_data;                 // Store the 1st position to Read Function Code
               goto last;                                                       // If the right data is received and stored then goto End of the loop, for avoid reload the data                          
           }
          
           else if(RS232.Receive_data == RS232_WRITE_FUN_CODE && RS232.Array[0] == RS232_START_ADDR)    // Checking the 1st byte is Single Write function
           {
               RS232.Array[++RS232.count] = RS232.Receive_data;                 // Store the 1st position to Write Function Code
               goto last;                                                       // If the right data is received and stored then goto End of the loop, for avoid reload the data                         
           }
            else if(RS232.Receive_data == RS232_REQ_STATUS_FUN_CODE && RS232.Array[0] == RS232_START_ADDR)    // Checking the 1st byte is Single Write function
           {
               RS232.Array[++RS232.count] = RS232.Receive_data;                 // Store the 1st position to Write Function Code
               goto last;                                                       // If the right data is received and stored then goto End of the loop, for avoid reload the data                        
           }
           
           else{} 
        }    
        if(RS232.Array[1] == RS232_READ_FUN_CODE)                               // Read Function get data continously
         {                  
             RS232.Array[++RS232.count] = RS232.Receive_data;                   // Receive data
             RS232.SI_FC_Entry = true;                                          // Once Start address ID and Function code is received, the Entry loop is disabled till receive full data
             if(RS232.count == RS232_READ_FUN_LENGTH-1)                         // limiting maximum number of data
             {           
                 RS232.SI_FC_Entry = false;                                     // Once the full data is received Slave Address ID and Function Entry loop is enabled
                 RS232.Buff_full = true;                                        // Read Buffer is full
                 RS232.Read_flag = true;                                        // Read flag is enable for process data
                 RS232.Data_length = RS232_READ_FUN_LENGTH;                     // data length of read function              
             }
         }
         if(RS232.Array[1] == RS232_WRITE_FUN_CODE)                             // Write Function get data continously
         {
             RS232.Array[++RS232.count] = RS232.Receive_data;                   // Receive data
             RS232.SI_FC_Entry = true;                                          // Once Start address ID and Function code is received, the Entry loop is disabled till receive full data
             if(RS232.count == RS232_WRITE_FUN_LENGTH-1)                        // limiting maximum number of data
             { 
                 RS232.SI_FC_Entry = false;                                     // Once the full data is received Slave Address ID and Function Entry loop is enabled
                 RS232.Buff_full = true;                                        // Write buffer is full
                 RS232.Write_flag = true;                                       // Write flag is enable for process data
                 RS232.Data_length = RS232_WRITE_FUN_LENGTH;                    // data length of write function
             }
         }
         if(RS232.Array[1] == RS232_REQ_STATUS_FUN_CODE)                        // Status Request Function get data continously
         {
             RS232.Array[++RS232.count] = RS232.Receive_data;                   // Receive data
             RS232.SI_FC_Entry = true;                                          // Once Start address ID and Function code is received, the Entry loop is disabled till receive full data                
             if(RS232.count == RS232_REQ_STATUS_FUN_LENGTH-1)                   // limiting maximum number of data
             { 
                 RS232.SI_FC_Entry = false;                                     // Once the full data is received Slave Address ID and Function Entry loop is enabled
                 RS232.Buff_full = true;                                        // Write buffer is full
                 RS232.Req_Status_flag = true;                                  // Write flag is enable for process data
                 RS232.Data_length = RS232_REQ_STATUS_FUN_LENGTH;               // data length of write function
             }
         }                  
         last:;           
     }
     IFS0bits.U1RXIF = 0;                                                       // Clear TX Interrupt flag    
}

/*********************************************************************************************
 * 
 *                              Interrupt Function                             
 *                for UART2 receive  MODBUS Receiver Interrupt
 * 
 ********************************************************************************************/

void __attribute__((__interrupt__, __no_auto_psv__)) _U2RXInterrupt(void)  
{    
     MODrx.Receive_data = U2RXREG;                                    // Receive the Serial data 
     if(!MODrx.Buff_full)                                                       // Buffer full or Not Status update
     {
        if(!MODrx.SI_FC_Entry)                                                  // if the Slave id and Function entry is zero(avoid re entry to ID and code checking)
        {
            if(MODrx.Receive_data == MOD_SLAVE_ID)                              // Check the Slave ID
            {           
               MODrx.Array[MODrx.count] = MODrx.Receive_data;                   // Store the 0th byte in array               
               goto last_mod;                                                   // If the right data is received and stored then goto End of the loop, for avoid reload the data
            }

           else if(MODrx.Receive_data == MOD_READ_FUN_CODE && MODrx.Array[0] == MOD_SLAVE_ID)    // Checking the 1st byte is read function
           {
               MODrx.Array[++MODrx.count] = MODrx.Receive_data;                 // Count = 1;
               goto last_mod;                                                   // If the right data is received and stored then goto End of the loop, for avoid reload the data 
           }

           else if(MODrx.Receive_data == MOD_SINGLE_WRITE_FUN_CODE && MODrx.Array[0] == MOD_SLAVE_ID)    // Checking the 1st byte is Single Write function
           {
               MODrx.Array[++MODrx.count] = MODrx.Receive_data;                 // Count = 1
               goto last_mod;                                                   // If the right data is received and stored then goto End of the loop, for avoid reload the data
           }

           else if(MODrx.Receive_data == MOD_MULTI_WRITE_FUN_CODE && MODrx.Array[0] == MOD_SLAVE_ID)    // Checking the 1st byte is Single Write function
           {
               MODrx.Array[++MODrx.count] = MODrx.Receive_data;                 // Count = 1;
               goto last_mod;                                                   // If the right data is received and stored then goto End of the loop, for avoid reload the data
           }
           else if(MODrx.Receive_data == MOD_REQ_STATUS_FUN_CODE && MODrx.Array[0] == MOD_SLAVE_ID)    // Checking the 1st byte is Single Write function
           {
               MODrx.Array[++MODrx.count] = MODrx.Receive_data;                 // Count = 1;
               goto last_mod;                                                   // If the right data is received and stored then goto End of the loop, for avoid reload the data
           }
           else{}
        } 
        if(MODrx.Array[1] == MOD_READ_FUN_CODE)                                 // Read Function    
        {
            MODrx.SI_FC_Entry = true;                                           // Once Slave ID and Function code is received, the Entry loop is disabled till receive full data
            MODrx.Array[++MODrx.count] = MODrx.Receive_data;                    // Receive data
            if(MODrx.count == MOD_READ_FUN_LENGTH-1)                            // if the read function length maximum, the Receiving data is stopped
            {
                MODrx.SI_FC_Entry = false;                                      // Once the full data is received Slave ID and Function Entry loop is enabled
                MODrx.Buff_full = true;                                         // Once receives the data, the buffer full flag is enabled till the end of data processing 
                MODrx.Read_flag = true;                                         // Flag for status of Read Function 
                MODrx.Data_length = MOD_READ_FUN_LENGTH;                        // Received data length status
            }
        }

        if(MODrx.Array[1] == MOD_SINGLE_WRITE_FUN_CODE)
        {
            MODrx.SI_FC_Entry = true;                                           // Once Slave ID and Function code is received, the Entry loop is disabled till receive full data
            MODrx.Array[++MODrx.count] = MODrx.Receive_data;                    // Receive data
            if(MODrx.count == MOD_SINGLE_WRITE_FUN_LENGTH-1)                    // if the read function length maximum, the Receiving data is stopped
            {
                MODrx.SI_FC_Entry = false;                                      // Once the full data is received Slave ID and Function Entry loop is enabled
                MODrx.Buff_full = true;                                         // Once receives the data, the buffer full flag is enabled till the end of data processing
                MODrx.Single_Write_flag = true;                                 // Flag for status of Write Function
                MODrx.Data_length = MOD_SINGLE_WRITE_FUN_LENGTH;                // Received data length status           
            }
        }
        if(MODrx.Array[1] == MOD_MULTI_WRITE_FUN_CODE)
        {
            MODrx.SI_FC_Entry = true;                                           // Once Slave ID and Function code is received, the Entry loop is disabled till receive full data
            MODrx.Array[++MODrx.count] = MODrx.Receive_data;                    // Receive data
            if(MODrx.count==7)      
            {
                temp_length = MODrx.Array[6];                                   // Get the byte counts               
            }
            if(MODrx.count == (MOD_MULTI_WRITE_FUN_LENGTH+temp_length-1))       // user knew the full bytes length except byte count length
            {
                MODrx.SI_FC_Entry = false;                                      // Once the full data is received Slave ID and Function Entry loop is enabled
                MODrx.Buff_full = true;                                         // Once receives the data, the buffer full flag is enabled till the end of data processing 
                MODrx.Multi_Write_flag = true;                                  // Flag for status of Write Function
                MODrx.Data_length = MOD_MULTI_WRITE_FUN_LENGTH+temp_length;     // Received data length status
            }
        }
        if(MODrx.Array[1] == MOD_REQ_STATUS_FUN_CODE)
        {
            MODrx.SI_FC_Entry = true;                                           // Once Slave ID and Function code is received, the Entry loop is disabled till receive full data
            MODrx.Array[++MODrx.count] = MODrx.Receive_data;                    // Receive data
            if(MODrx.count == MOD_REQ_STATUS_FUN_LENGTH-1)                      // if the read function length maximum, the Receiving data is stopped
            {
                MODrx.SI_FC_Entry = false;                                      // Once the full data is received Slave ID and Function Entry loop is enabled
                MODrx.Buff_full = true;                                         // Once receives the data, the buffer full flag is enabled till the end of data processing 
                MODrx.Req_Status_flag = true;                                   // Flag for status of Write Function
                MODrx.Data_length = MOD_REQ_STATUS_FUN_LENGTH;                  // Received data length status
            }
        }
              
      last_mod:;      
     }
    IFS1bits.U2RXIF = 0;  // Clear RX Interrupt flag
}

/*******************************************************************************
 *                          Interrupt Function                             
 *                             for timer 2                                  
 *                          time_duration  = 10mS                            
 *                         resolution = 1.28 uS

*******************************************************************************/

void __attribute__((__interrupt__, __no_auto_psv__)) _T2Interrupt(void) 
{
    LEDBlink++; 
    if(PA0_Surg_Flag==true)
        PA0_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PA1_Surg_Flag==true)
        PA1_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PA2_Surg_Flag==true)
        PA2_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PA3_Surg_Flag==true)
        PA3_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PA4_Surg_Flag==true)
        PA4_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PA5_Surg_Flag==true)
        PA5_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PA6_Surg_Flag==true)
        PA6_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PA7_Surg_Flag==true)
        PA7_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    
    if(PB0_Surg_Flag==true)
        PB0_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PB1_Surg_Flag==true)
        PB1_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PB2_Surg_Flag==true)
        PB2_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PB3_Surg_Flag==true)
        PB3_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PB4_Surg_Flag==true)
        PB4_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PB5_Surg_Flag==true)
        PB5_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
    if(PB6_Surg_Flag==true)
        PB6_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay)  
    if(PB7_Surg_Flag==true)
        PB7_Surg_Tick++;                    // increment if any surg is detected (Check for respective time delay) 
      
    IFS0bits.T2IF = 0;                      // Clear Timer2 Interrupt Flag
}


#endif