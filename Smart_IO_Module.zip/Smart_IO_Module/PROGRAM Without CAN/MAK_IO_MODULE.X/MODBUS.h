#ifndef _MODBUS_H_
#define _MODBUS_H_
#include "DEFINITIONS.h"        // defined All variables constant value

/********************************************************************************************
 * FILE NAME    :   MODBUS.h
 * PURPOSE      :   MODBUS protocol related functions are defined Here.
 * FUNCTIONS ARE:   Collect_MOD_Query()
 *                  MOD_Read_Holding_Register()
 *                  MOD_Write_Multi_Register()
 ********************************************************************************************/
void Collect_MOD_Query()
{  
    if(MODrx.Buff_full == true)
    {
        MODrx.Req_Count++;                                                     // Serial Request commands counts
        CRC_Value = crc(MODrx.Array,MODrx.Data_length);                         // if the result is 0, CRC is matched
        if(!CRC_Value)                                                          // ex. CRC--> 0203 0010 0005  = 843F, So, CRC ALL VALUE INCLUDE CRC--> 0203 0010 0005 843F = 0; get ZERO.
        {           
            if(MODrx.Read_flag == true)                                         // Read Holding Register Function code
            {
                MODrx.Start_Reg_addr = MODrx.Array[3];                          // Ex.16
                MODrx.No_of_Reg_addr = MODrx.Array[5];                          // No.of Register to be red is 9(16bit)
                MOD_Read_Holding_Register(MODrx.Start_Reg_addr, MODrx.No_of_Reg_addr);  // 16,9                                 
                MODrx.count = 0;
                MODtx.Req_Response_Count++;
                memset(MODtx.Array, 0, sizeof(MODtx.Array));                    // Clear the buffer MOD tx and rx                  
                memset(MODrx.Array, 0, sizeof(MODrx.Array));                    // Clear the buffer MOD tx and rx
                MODrx.Buff_full = false;
                MODrx.Read_flag = false;
            }
            else if(MODrx.Single_Write_flag == true)                            // Preset Single Register Function code (SINGLE REGISTER WRITE)
            {
                
                MODrx.Start_Reg_addr  = MODrx.Array[3];                         // Ex. 58
                MODrx.No_of_Byte_addr = 2;                                      // Number of bytes, ex-10
                MODrx.Start_Data_addr = 4;                                      //  data address of mod array is 4
                MOD_Write_Multi_Register(MODrx.Start_Reg_addr, MODrx.No_of_Byte_addr, MODrx.Start_Data_addr); // 58,2,4                
                MOD_Response_Write_Single_Register();                           // Response to MASTER. For single write function Command is resend as Response   
                MODrx.count = 0;
                memset(MODtx.Array, 0, sizeof(MODtx.Array));                    // Clear the buffer MOD tx and rx                  
                memset(MODrx.Array, 0, sizeof(MODrx.Array));                    // Clear the buffer MOD tx and rx
                MODtx.Req_Response_Count++;
                MODrx.Buff_full = false;
                MODrx.Single_Write_flag = false;
            }
            else if(MODrx.Multi_Write_flag == true)                             // Preset Multiple Register Function code (MULTI REGISTER WRITE)
            {
                
                MODrx.Start_Reg_addr = MODrx.Array[3];                          // Ex. 58
                MODrx.No_of_Reg_addr = MODrx.Array[5];                          // No.of Register to be red is 9(16bit)
                MODrx.No_of_Byte_addr = MODrx.Array[6];                         // Number of bytes, ex-10
                MODrx.Start_Data_addr = 7;                                      // Data bytes starting address in MODtx.array Ex. 7th byte
                MOD_Write_Multi_Register(MODrx.Start_Reg_addr, MODrx.No_of_Byte_addr, MODrx.Start_Data_addr); // 58,10,7                 
                MOD_Response_Write_Multi_Register(MODrx.Start_Reg_addr, MODrx.No_of_Reg_addr);
                memset(MODtx.Array, 0, sizeof(MODtx.Array));                    // Clear the buffer MOD tx and rx                  
                memset(MODrx.Array, 0, sizeof(MODrx.Array));                    // Clear the buffer MOD tx and rx
                MODrx.count = 0;
                memset(MODtx.Array, 0, sizeof(MODtx.Array));                    // Clear the buffer MOD tx and rx                  
                memset(MODrx.Array, 0, sizeof(MODrx.Array));                    // Clear the buffer MOD tx and rx
                MODtx.Req_Response_Count++;
                MODrx.Buff_full = false;
                MODrx.Multi_Write_flag = false;
            }
            else if(MODrx.Req_Status_flag == true)                             // Preset Multiple Register Function code (MULTI REGISTER WRITE)
            {
                MODtx.Req_Response_Count++;
                MODtx.count=0;
                MODtx.Array[MODtx.count] = MOD_SLAVE_ID;
                MODtx.Array[++MODtx.count] = MOD_REQ_STATUS_FUN_CODE;
                MODtx.Array[++MODtx.count] = 6;
                MODtx.Array[++MODtx.count] = (unsigned char)(MODrx.Req_Count>>8);
                MODtx.Array[++MODtx.count] = (unsigned char)(MODrx.Req_Count);
                MODtx.Array[++MODtx.count] = (unsigned char)(MODtx.Req_Response_Count>>8);
                MODtx.Array[++MODtx.count] = (unsigned char)(MODtx.Req_Response_Count);
                MODtx.Array[++MODtx.count] = (unsigned char)(MODrx.Req_Reject_Count>>8);
                MODtx.Array[++MODtx.count] = (unsigned char)(MODrx.Req_Reject_Count);
                CRC_Value = crc(MODtx.Array, MODtx.count);
                MODtx.Array[++MODtx.count] = (CRC_Value >> 8);                  // MODtx.count = 34        
                MODtx.Array[++MODtx.count] = CRC_Value;                         // MODtx.count = 35    
                Serial2_write_array(MODtx.Array,MODtx.count);
                memset(MODtx.Array, 0, sizeof(MODtx.Array));                    // Clear the buffer MOD tx and rx                  
                memset(MODrx.Array, 0, sizeof(MODrx.Array));                    // Clear the buffer MOD tx and rx
                MODrx.count = 0;
                MODrx.Req_Status_flag = false;
                MODrx.Buff_full = false;                
            }
       }
        else
        {          
            memset(MODtx.Array, 0, sizeof(MODtx.Array));                    // Clear the buffer MOD tx and rx                  
            memset(MODrx.Array, 0, sizeof(MODrx.Array));                    // Clear the buffer MOD tx and rx
            MODrx.Req_Reject_Count++;                                      // Serial Request Reject by error(CRC)
            MODrx.Read_flag = false;
            MODrx.Single_Write_flag = false;
            MODrx.Multi_Write_flag = false;  
            MODrx.Req_Status_flag = false;
            MODrx.count = 0; 
            MODrx.Buff_full = false; 
        }
    }
}

/******************************************************************************************************************
 * Function Name    : MOD_Read_Holding_Register(unsigned int Start_addr, unsigned int Count_addr)
 * Purpose          : From query request, form the response array
 * Description      : Start_addr is Starting address of Our dataspace buffer
 *                    Count_addr means number of Registers(16bit) to be read
 *                    Count_addr = (Start_addr + (Count_addr*2)-1), here
 *                    Count_addr = (16 + (9*2) -1) = 33... Collect data from 16th byte to 33rd byte in DATA_ARRAY
******************************************************************************************************************/
void MOD_Read_Holding_Register(unsigned int Start_addr, unsigned int Count_addr)    // 16, 9
{
    int y;
    MODtx.count = 0;
    MODtx.Array[MODtx.count]    = MOD_SLAVE_ID;                                 // First byte is Slave ID
    MODtx.Array[++MODtx.count]  = MOD_READ_FUN_CODE;                            // Function code for Read Holding Register and Count = 1
    MODtx.Array[++MODtx.count]  = (Count_addr*2);                               // Number of data bytes (9registers * 2 = 18 )
    Count_addr = (Start_addr + (Count_addr*2)-1);                               // Count_addr = (16 + (9*2)-1) = 33
    for(y=Start_addr; y<=Count_addr; y++)                                       // y = 16; y<=33; y++
    {
        MODtx.Array[++MODtx.count] = DATA_ARRAY[y];
    }
    CRC_Value = crc(MODtx.Array, MODtx.count);
    MODtx.Array[++MODtx.count] = (CRC_Value >> 8);                  // MODtx.count = 34        
    MODtx.Array[++MODtx.count] = CRC_Value;                         // MODtx.count = 35    
    Serial2_write_array(MODtx.Array,MODtx.count);
}
/******************************************************************************************************************************
 * Function Name    : MOD_Write_Multi_Register(unsigned int Start_addr_wr, unsigned int Byte_count_wr, unsigned int Data_addr)
 * Purpose          : From query request, form the response array
 * Description      : Start_addr is Starting address of Our dataspace buffer
 *                    Byte_count_wr means number of bytes need to Copy from MOD bus to DATA_ARRAY
 *                    Data_addr is hold the MOD array data byte starting address.
 *                    for Ex. Start_addr = 58, Byte_count = 10, Data_addr in MOD array = 7
 *                    Start_addr_Wr + Byte_count_wr = 50+10 = 60, (50-59)=10byte
********************************************************************************************************************************/
void MOD_Write_Multi_Register(unsigned int Start_addr_wr, unsigned int Byte_count_wr, unsigned int Data_addr)    // 58,10,7
{
    int y;
    for(y=Start_addr_wr; y<(Start_addr_wr+Byte_count_wr); y++)
    {
        DATA_ARRAY[y] = MODrx.Array[Data_addr];
        Data_addr++;
    }
    
}

/******************************************************************************************************************************
 * Function Name    : MOD_Response_Write_Multi_Register(unsigned char Reg_Start_addr, unsigned char No_of_Reg)
 * Purpose          : Response array for Multi Write Register function
 * Description      : Reg_Start_addr is Starting address of Our dataspace buffer
 *                    No_of_Reg means number of Register to be write
********************************************************************************************************************************/
void MOD_Response_Write_Multi_Register(unsigned char Reg_Start_addr, unsigned char No_of_Reg)
{
    MODtx.count = 0;
    MODtx.Array[MODtx.count]    = MOD_SLAVE_ID;                                 // First byte is Slave ID
    MODtx.Array[++MODtx.count]  = MOD_MULTI_WRITE_FUN_CODE;                     // Function code for Read Holding Register and Count = 1
    MODtx.Array[++MODtx.count]  = 0;                                            // Starting Register address High
    MODtx.Array[++MODtx.count]  = Reg_Start_addr;                               // Stating Register address Low byte
    MODtx.Array[++MODtx.count]  = 0;                                            // Number of Register High byte    
    MODtx.Array[++MODtx.count]  = No_of_Reg;                                    // Number of Register Low byte    
    CRC_Value = crc(MODtx.Array, MODtx.count);
    MODtx.Array[++MODtx.count] = (CRC_Value >> 8);                  // MODtx.count = 34        
    MODtx.Array[++MODtx.count] = CRC_Value;                         // MODtx.count = 35 
    Serial2_write_array(MODtx.Array,MODtx.count);        
}

/******************************************************************************************************************************
 * Function Name    : MOD_Response_Write_Single_Register(unsigned char Reg_Start_addr, unsigned char No_of_Reg)
 * Purpose          : Response array for Multi Write Register function
 * Description      : Reg_Start_addr is Starting address of Our dataspace buffer
 *                    No_of_Reg means number of Register to be write
********************************************************************************************************************************/
void MOD_Response_Write_Single_Register()
{
    int i;
    MODtx.count=0;
    for(i=0; i<MODrx.Data_length-2; i++)
    {
        MODtx.Array[MODtx.count] = MODrx.Array[MODtx.count]; 
        MODtx.count++;
    }
    CRC_Value = crc(MODtx.Array, 5);
    MODtx.Array[MODtx.count] = (CRC_Value >> 8);                  // MODtx.count = 34        
    MODtx.Array[++MODtx.count] = CRC_Value;                         // MODtx.count = 35 
    Serial2_write_array(MODtx.Array,MODtx.count);      
    //printf("%c",DATA_ARRAY[PD_OUTPUT_BUF_POS]);
}
#endif



/*
 void Collect_MOD_Query()
{  
    if(MODrx.Buff_full == true)
    {
        MODrx.Req_Count++;                                                     // Serial Request commands counts
        CRC_Value = crc(MODrx.Array,MODrx.Data_length);                         // if the result is 0, CRC is matched
        if(!CRC_Value)                                                          // ex. CRC--> 0203 0010 0005  = 843F, So, CRC ALL VALUE INCLUDE CRC--> 0203 0010 0005 843F = 0; get ZERO.
        {
            if(MODrx.Read_flag == true)                                         // Read Holding Register Function code
            {
                MODrx.Start_Reg_addr = MODrx.Array[3];                          // Ex.16
                MODrx.No_of_Reg_addr = MODrx.Array[5];                          // No.of Register to be red is 9(16bit)
                MOD_Read_Holding_Register(MODrx.Start_Reg_addr, MODrx.No_of_Reg_addr);  // 16,9
                memset(MODtx.Array, 0, sizeof(MODtx.Array));                    // Clear the buffer MOD tx and rx                  
                memset(MODrx.Array, 0, sizeof(MODrx.Array));                    // Clear the buffer MOD tx and rx                                  
                MODrx.count = 0;                                                // Clear the MOD Receive Counts
                MODtx.Req_Response_Count++;                                     // Increment the response count
                MODrx.Buff_full = false;                                        // Clear the Buffer Full, for New Entry
                MODrx.Read_flag = false;                                        // Clear the Read flag status for Re-entry
            }
            else if(MODrx.Single_Write_flag == true)                            // Preset Single Register Function code (SINGLE REGISTER WRITE)
            {
                MODrx.Start_Reg_addr  = MODrx.Array[3];                         // Ex. 58
                MODrx.No_of_Byte_addr = 2;                                      // Number of bytes, ex-10
                MODrx.Start_Data_addr = 4;                                      //  data address of mod array is 4
                MOD_Write_Multi_Register(MODrx.Start_Reg_addr, MODrx.No_of_Byte_addr, MODrx.Start_Data_addr); // 58,2,4                
                MOD_Response_Write_Single_Register();                           // Response to MASTER. For single write function Command is resend as Response                 
                memset(MODtx.Array, 0, sizeof(MODtx.Array));                    // Clear the buffer MOD tx and rx                  
                memset(MODrx.Array, 0, sizeof(MODrx.Array));                    // Clear the buffer MOD tx and rx
                MODrx.count = 0;                                                // Clear the MOD Receive Counts
                MODtx.Req_Response_Count++;                                     // Increment the response count
                MODrx.Buff_full = false;                                        // Clear the Buffer Full, for New Entry
                MODrx.Single_Write_flag = false;                                // Clear the Write flag status for Re-entry
            }
            else if(MODrx.Multi_Write_flag == true)                             // Preset Multiple Register Function code (MULTI REGISTER WRITE)
            {
                MODrx.Start_Reg_addr = MODrx.Array[3];                          // Ex. 58
                MODrx.No_of_Reg_addr = MODrx.Array[5];                          // No.of Register to be red is 9(16bit)
                MODrx.No_of_Byte_addr = MODrx.Array[6];                         // Number of bytes, ex-10
                MODrx.Start_Data_addr = 7;                                      // Data bytes starting address in MODtx.array Ex. 7th byte
                MOD_Write_Multi_Register(MODrx.Start_Reg_addr, MODrx.No_of_Byte_addr, MODrx.Start_Data_addr); // 58,10,7                 
                MOD_Response_Write_Multi_Register(MODrx.Start_Reg_addr, MODrx.No_of_Reg_addr);
                memset(MODtx.Array, 0, sizeof(MODtx.Array));                    // Clear the buffer MOD tx and rx                  
                memset(MODrx.Array, 0, sizeof(MODrx.Array));                    // Clear the buffer MOD tx and rx
                MODrx.count = 0;                                                // Clear the MOD Receive Counts
                MODtx.Req_Response_Count++;                                     // Increment the response count
                MODrx.Buff_full = false;                                        // Clear the Buffer Full, for New Entry
                MODrx.Multi_Write_flag = false;                                 // Clear the Write flag status for Re-entry
            }
            else if(MODrx.Req_Status_flag == true)                              // Preset Multiple Register Function code (MULTI REGISTER WRITE)
            {
                MODtx.Req_Response_Count++;                                     // Increment the response count
                MODtx.count=0;                                                  // Clear the MOD transmit buffer Array count
                MODtx.Array[MODtx.count] = MOD_SLAVE_ID;                        // Load the Slave ID
                MODtx.Array[++MODtx.count] = MOD_REQ_STATUS_FUN_CODE;           // Load the Function code
                MODtx.Array[++MODtx.count] = 6;                                             // load the number of bytes of data
                MODtx.Array[++MODtx.count] = (unsigned char)(MODrx.Req_Count>>8);           // Load the data HI byte
                MODtx.Array[++MODtx.count] = (unsigned char)(MODrx.Req_Count);              // Load the data LO byte
                MODtx.Array[++MODtx.count] = (unsigned char)(MODtx.Req_Response_Count>>8);  // Load the data HI byte
                MODtx.Array[++MODtx.count] = (unsigned char)(MODtx.Req_Response_Count);     // Load the data LO byte    
                MODtx.Array[++MODtx.count] = (unsigned char)(MODrx.Req_Reject_Count>>8);    // Load the data HI byte
                MODtx.Array[++MODtx.count] = (unsigned char)(MODrx.Req_Reject_Count);       // Load the data LO byte
                CRC_Value = crc(MODtx.Array, MODtx.count);                                  // Getting the Response CRC
                MODtx.Array[++MODtx.count] = (CRC_Value >> 8);                  // MODtx.count = 34        
                MODtx.Array[++MODtx.count] = CRC_Value;                         // MODtx.count = 35    
                Serial2_write_array(MODtx.Array,MODtx.count);                   // Send the Response array
                memset(MODtx.Array, 0, sizeof(MODtx.Array));                    // Clear the buffer MOD tx and rx                  
                memset(MODrx.Array, 0, sizeof(MODrx.Array));                    // Clear the buffer MOD tx and rx
                MODrx.count = 0;                                                // Clear the MOD Receive Counts
                MODrx.Req_Status_flag = false;                                  // Clear the Status Request flag status for Re-entry
                MODrx.Buff_full = false;                                        // Clear the Buffer Full, for New Entry                
            }
       }
        else
        {          
            memset(MODtx.Array, 0, sizeof(MODtx.Array));                        // Clear the buffer MOD tx and rx                  
            memset(MODrx.Array, 0, sizeof(MODrx.Array));                        // Clear the buffer MOD tx and rx
            MODrx.Req_Reject_Count++;                                           // Serial Request Reject by error(CRC)
            MODrx.Read_flag = false;                                            // Clear the Read flag status for Re-entry
            MODrx.Single_Write_flag = false;                                    // Clear the Write flag status for Re-entry
            MODrx.Multi_Write_flag = false;                                     // Clear the Write flag status for Re-entry
            MODrx.Req_Status_flag = false;                                      // Clear the Status Request flag status for Re-entry
            MODrx.count = 0;                                                    // Clear the MOD Receive Counts 
            MODrx.Buff_full = false;                                            // Clear the Buffer Full, for New Entry                 
        }
    }
}

******************************************************************************************************************
 * Function Name    : MOD_Read_Holding_Register(unsigned int Start_addr, unsigned int Count_addr)
 * Purpose          : From query request, form the response array
 * Description      : Start_addr is Starting address of Our dataspace buffer
 *                    Count_addr means number of Registers(16bit) to be read
 *                    Count_addr = (Start_addr + (Count_addr*2)-1), here
 *                    Count_addr = (16 + (9*2) -1) = 33... Collect data from 16th byte to 33rd byte in DATA_ARRAY
******************************************************************************************************************
void MOD_Read_Holding_Register(unsigned int Start_addr, unsigned int Count_addr)    // 16, 9
{
    int y;
    memset(MODtx.Array, 0, sizeof(MODtx.Array));                                // Clear the buffer MOD tx and rx
    MODtx.count = 0;                                                            // Clear the MOD transmit buffer Array count
    MODtx.Array[MODtx.count]    = MOD_SLAVE_ID;                                 // First byte is Slave ID
    MODtx.Array[++MODtx.count]  = MOD_READ_FUN_CODE;                            // Function code for Read Holding Register and Count = 1
    MODtx.Array[++MODtx.count]  = (Count_addr*2);                               // Number of data bytes (9registers * 2 = 18 )
    Count_addr = (Start_addr + (Count_addr*2)-1);                               // Count_addr = (16 + (9*2)-1) = 33
    for(y=Start_addr; y<=Count_addr; y++)                                       // y = 16; y<=33; y++
    {
        MODtx.Array[++MODtx.count] = DATA_ARRAY[y];                             // Load the DATA array to MOD Response Array buffer
    }
    CRC_Value = crc(MODtx.Array, MODtx.count);                                  // Getting CRC
    MODtx.Array[++MODtx.count] = (CRC_Value >> 8);                              // MODtx.count = 34        
    MODtx.Array[++MODtx.count] = CRC_Value;                                     // MODtx.count = 35    
    Serial2_write_array(MODtx.Array,MODtx.count);                               // Send the Response array
}
******************************************************************************************************************************
 * Function Name    : MOD_Write_Multi_Register(unsigned int Start_addr_wr, unsigned int Byte_count_wr, unsigned int Data_addr)
 * Purpose          : From query request, form the response array
 * Description      : Start_addr is Starting address of Our dataspace buffer
 *                    Byte_count_wr means number of bytes need to Copy from MOD bus to DATA_ARRAY
 *                    Data_addr is hold the MOD array data byte starting address.
 *                    for Ex. Start_addr = 58, Byte_count = 10, Data_addr in MOD array = 7
 *                    Start_addr_Wr + Byte_count_wr = 50+10 = 60, (50-59)=10byte
********************************************************************************************************************************
void MOD_Write_Multi_Register(unsigned int Start_addr_wr, unsigned int Byte_count_wr, unsigned int Data_addr)    // 58,10,7
{
    int y;
    for(y=Start_addr_wr; y<(Start_addr_wr+Byte_count_wr); y++)
    {
        DATA_ARRAY[y] = MODrx.Array[Data_addr];                                 // Load the Receiving array to Data space array
        Data_addr++;                                                            // Increment the variable
    }
}

******************************************************************************************************************************
 * Function Name    : MOD_Response_Write_Multi_Register(unsigned char Reg_Start_addr, unsigned char No_of_Reg)
 * Purpose          : Response array for Multi Write Register function
 * Description      : Reg_Start_addr is Starting address of Our dataspace buffer
 *                    No_of_Reg means number of Register to be write
********************************************************************************************************************************
void MOD_Response_Write_Multi_Register(unsigned char Reg_Start_addr, unsigned char No_of_Reg)
{
    MODtx.count = 0;                                                            // Clear the MOD transmit buffer Array count
    MODtx.Array[MODtx.count]    = MOD_SLAVE_ID;                                 // First byte is Slave ID
    MODtx.Array[++MODtx.count]  = MOD_MULTI_WRITE_FUN_CODE;                     // Function code for Read Holding Register and Count = 1
    MODtx.Array[++MODtx.count]  = 0;                                            // Starting Register address High
    MODtx.Array[++MODtx.count]  = Reg_Start_addr;                               // Stating Register address Low byte
    MODtx.Array[++MODtx.count]  = 0;                                            // Number of Register High byte    
    MODtx.Array[++MODtx.count]  = No_of_Reg;                                    // Number of Register Low byte    
    CRC_Value = crc(MODtx.Array, MODtx.count);                                  // Getting CRC for Response array
    MODtx.Array[++MODtx.count] = (CRC_Value >> 8);                              // MODtx.count = 34        
    MODtx.Array[++MODtx.count] = CRC_Value;                                     // MODtx.count = 35 
    Serial2_write_array(MODtx.Array,MODtx.count);                               // Send the response array     
}

******************************************************************************************************************************
 * Function Name    : MOD_Response_Write_Single_Register(unsigned char Reg_Start_addr, unsigned char No_of_Reg)
 * Purpose          : Response array for Multi Write Register function
 * Description      : Reg_Start_addr is Starting address of Our dataspace buffer
 *                    No_of_Reg means number of Register to be write
********************************************************************************************************************************
void MOD_Response_Write_Single_Register()
{
    int i;
    MODtx.count=0;                                                              // Clear the MOD transmit buffer Array count
    for(i=0; i<MODrx.Data_length-2; i++)
    {
        MODtx.Array[MODtx.count] = MODrx.Array[MODtx.count];                    // Response Array  
        MODtx.count++;
    }
    CRC_Value = crc(MODtx.Array, 5);                                            // Getting the CRC for Response array
    MODtx.Array[MODtx.count] = (CRC_Value >> 8);                                // MODtx.count = 34        
    MODtx.Array[++MODtx.count] = CRC_Value;                                     // MODtx.count = 35 
    Serial2_write_array(MODtx.Array,MODtx.count);                               // Send the Response array
    //printf("%c",DATA_ARRAY[PD_OUTPUT_BUF_POS]);
}
 */