#ifndef _UART_H_
#define _UART_H_

/***************************************************************************************
Function Name	:	UART_init
Purpose			:	UART register initialization for both 2 uarts
Formulas used	:	UxBRG = (Fcy/16*Baudrate)-1
***************************************************************************************/

#define Fcy 50000000 //system clock 1 instruction cycle = 2 clock cycle i.e., Fcy=fosc/2 , 50MIPS
#define	RS232_BAUDRATE	115200
#define	MOD_BAUDRATE2	115200
#define BRG_RS232       (Fcy/(16*RS232_BAUDRATE))-1    //baudrate formula setting for UART 1
#define BRG_MOD         (Fcy/(16*MOD_BAUDRATE))-1    //baudrate formula setting for UART 1
//#define BRG_MOD 26      // 115200


void Serial1_write_byte(unsigned char );
void Serial1_write_string(unsigned char *);
void Serial2_write_byte(unsigned char );
void Serial2_write_string(unsigned char *);
void Serial1_write_array(unsigned char *, unsigned int);
void Serial2_write_array(unsigned char *, unsigned int);
void UART_init(void)
{
    // UART1 initialization
	U1MODEbits.STSEL = 0;           // 1-Stop bit
    U1MODEbits.PDSEL = 0;           // No Parity, 8-Data bits
    U1MODEbits.ABAUD = 0;           // Auto-Baud disabled
    U1MODEbits.BRGH = 0;            // Standard-Speed mode
    U1BRG = BRG_RS232;              // Baud Rate setting														 
    U1STAbits.UTXISEL0 = 0;         // Interrupt after one TX character is transmitted
    U1STAbits.UTXISEL1 = 0;         //Interrupt when a character is transferred to the Transmit Shift Register
    U1STAbits.URXISEL = 0;          // Interrupt after one RX character is received;    
    IEC0bits.U1RXIE = 1;            // Enable UART 1 RX interrupt
    IPC2bits.U1RXIP = UART1_INT_PRIORITY; //UART1 interrupt priority
    U1MODEbits.UARTEN = 1;          // Enable UART
    U1STAbits.UTXEN = 1;            // Enable 1 UART TX
    // UART2 initialization
    U2MODEbits.STSEL = 0;           // 1-Stop bit
    U2MODEbits.PDSEL = 0;           // No Parity, 8-Data bits
    U2MODEbits.ABAUD = 0;           // Auto-Baud disabled
    U2MODEbits.BRGH = 0;            // Standard-Speed mode
    U2BRG = BRG_MOD;                // Baud Rate setting 
    U2STAbits.UTXISEL0 = 0;         // Interrupt after one TX character is transmitted
    U2STAbits.UTXISEL1 = 0;         //Interrupt when a character is transferred to the Transmit Shift Register
    U2STAbits.URXISEL = 0;          // Interrupt after one RX character is received;    
    IEC1bits.U2RXIE = 1;            // Enable UART 2 RX interrupt
    IPC7bits.U2RXIP = UART2_INT_PRIORITY; //UART2 interrupt priority
    U2MODEbits.UARTEN = 1;          // Enable UART
    U2STAbits.UTXEN = 1;            // Enable 2 UART TX
    
}
void putch(uint8_t byt) //for transmitting the char from standard printf function
{
    while (!U1STAbits.TRMT);
    U1TXREG = byt;
}
/************************************************************************************************/
//Function Name			: Serial1_write_byte
//Purpose                :write UART1 byte
//Description			:To write UART1 bytes in UART1 buffer

/************************************************************************************************/
void Serial1_write_byte(unsigned char byte1) //for transmitting one single byte definition
{
    while (!U1STAbits.TRMT); //waiting for last transmitted char
    U1TXREG = byte1; //transmit a char in UART buffer
}
/************************************************************************************************/
//Function Name			: Serial1_write_string
//Purpose                :write UART string
//Description			:To write UART1 strings in UART1 buffer by splitting it in to bytes

/************************************************************************************************/
void Serial1_write_string(unsigned char *str1) //for transmitting entire string definition
{
    while (*str1) {
        Serial1_write_byte(*str1++); //string to byte
    }
}

/************************************************************************************************
Function Name			: Serial2_write_byte
Purpose                :write UART byte
Description			:To write UART2 bytes in UART2 buffer
************************************************************************************************/
void Serial2_write_byte(unsigned char byte2) { //for transmitting one single byte definition
    while (!U2STAbits.TRMT); //waiting for last transmitted char
    U2TXREG = byte2; //transmit a char in UART buffer
}

/************************************************************************************************
Function Name			: Serial2_write_string
Purpose                :write UART string
Description			:To write UART2 strings in UART2 buffer by splitting it in to bytes
************************************************************************************************/
void Serial2_write_string(unsigned char *str2) { //to transmit a number by converting it to string
    while (*str2) {
        Serial2_write_byte(*str2++); //string to byte
    }
}
/************************************************************************************************
Function Name			: Serial1_write_array
Purpose                :write UART string
Description			:To write UART1 strings in UART1 buffer by splitting it in to bytes
************************************************************************************************/
void Serial1_write_array(unsigned char *Array_Ser1, unsigned int Array_Count1)
{
    int cnt=0;
    for(cnt = 0; cnt<=Array_Count1; cnt++)
    {
        Serial1_write_byte(*Array_Ser1++);
    }
}
/************************************************************************************************
Function Name			: Serial2_write_array
Purpose                :write UART string
Description			:To write UART2 strings in UART2 buffer by splitting it in to bytes
************************************************************************************************/
void Serial2_write_array(unsigned char *Array_Ser2, unsigned int Array_Count2)
{
    int cnt=0;
    for(cnt = 0; cnt<=Array_Count2; cnt++)
    {
        Serial2_write_byte(*Array_Ser2++);
    }
}

/*******************************************************************************
                              Interrupt Function                             
                               for UART1 receive                             
                                using FIFO method                            
*******************************************************************************
void __attribute__((__interrupt__, __no_auto_psv__)) _U1RXInterrupt(void) {
    char rx1_data = U1RXREG; // if the que is not full insert the data into the array
    IFS0bits.U1RXIF = 0; // Clear TX Interrupt flag
}
  */
/*******************************************************************************
                              Interrupt Function                             
                               for UART2 receive                             
                                using FIFO method                            
*******************************************************************************
void __attribute__((__interrupt__, __no_auto_psv__)) _U2RXInterrupt(void) {
 
    char rx2_data = U2RXREG; // if the que is not full insert the data into the array
    IFS1bits.U2RXIF = 0; // Clear TX Interrupt flag
}

*/






/************************************************************************************************
Function Name			: Serial1_write_number
Purpose                :write UART number
Description			:To write UART1 numbers in UART1 buffer by converting it in to strings
************************************************************************************************
void Serial1_write_number(unsigned int num) //to transmit a number by converting it to string
{
    unsigned char num_count = 0, divd;
    char num_str[7]; //array for converted number
    unsigned int dividend;
    for (divd = 4; divd >= 1; divd--) { //size of number
        if (num / pow(10, divd) || num_count) { //getting MSW of number
            dividend = pow(10, divd); //getting the dividend
            num_str[num_count++] = (num / dividend) | 0x30; //storing the numbers in arrays position     
            num = num % dividend; //eliminating the last number
        }
    }
    num_str[num_count++] = num | 0x30; //converting decimal number to asci value
    num_str[num_count] = '\0'; //adding null char to last byte
    Serial1_write_string(num_str); //passing the converted number in string format
}
*/
/************************************************************************************************
Function Name			: Serial2_write_number
Purpose                :write UART number
Description			:To write UART2 numbers in UART2 buffer by converting it in to strings
************************************************************************************************
void Serial2_write_number(unsigned int num) { //to transmit a number by converting it to string
    unsigned char num_count = 0, divd;
    char num_str[7]; //array for converted number
    unsigned int dividend;
    for (divd = 4; divd >= 1; divd--) { //size of number
        if (num / pow(10, divd) || num_count) { //getting MSW of number
            dividend = pow(10, divd); //getting the dividend
            num_str[num_count++] = (num / dividend) | 0x30; //storing the numbers in arrays position        
            num = num % dividend; //eliminating the last number
        }
    }
    num_str[num_count++] = num | 0x30; //converting decimal number to asci value
    num_str[num_count] = '\0'; //adding null char to last byte
    Serial2_write_string(num_str); //passing the converted number in string format
}

*/

#endif