/********************************************************************************************
 * FILE NAME    :   MAIN_FUNCTION.h
 * PURPOSE      :   Sub function of MAIN. here all the main function definitions  are defined
 * FUNCTIONS ARE:   Collect_data()
 *                  Collect_Digital_data()
 *                  Process_Control_Output()
 *                  Digital_Output_Process()
 ********************************************************************************************/
#ifndef _MAIN_FUNCTION_H_
#define _MAIN_FUNCTION_H_


/************************************************************************************************/
//Function Name			: Collect_data
//Purpose               : Collect all input data of MAK IO module
//Description			: Analog, Digital and PWM inputs
/************************************************************************************************/
void Collect_data() 
{
    Collect_ADC_data();                         // Collect Analog data
    Collect_Digital_data();                     // Collect digital data
    Collect_RS232_Query();                      // Collect RS232 Query and Commands
    Collect_MOD_Query();                        // Collect MODBUS Query and Commands    
}
/************************************************************************************************/
//Function Name			: Process_Control_Output
//Purpose               : Controlled Output data
//Description			: PWM, Digital Output
/************************************************************************************************/
void Process_Control_Output()
{
    Digital_Output_Process();                   // Digital Output Processing
    Update_PWM_duty_cycle();                    // Update the PWM duty in period  
}

/************************************************************************************************/
//Function Name			: LED_Blink
//Purpose               : LED Toggle for selected time delay
//Description			: 
/************************************************************************************************/
void LED_Blink()
{
    if(LEDBlink >= LED_Blink_Delay)
    {
        Toggle = ~Toggle;
        STATUS_LED = Toggle;
        LEDBlink = 0;
    }
}
void LED_Toggle()
{
    Toggle = ~Toggle;
    STATUS_LED = Toggle;
}
/************************************************************************************************/
//Function Name			: Collect_Digital_data
//Purpose               : Collect digital data from two ports
//Description			: Get the input state and Number of upward and downward counts
//Formula               : Set one flag before and after pulse for counting
/************************************************************************************************/
void Collect_Digital_data()
{
 /********* PA0-PA7 5v/3.3V Digital inputs ***************/
    // Check the Input State of PA0
    if(PA0_INPUT_PIN == LOW)                            // Check the PA0 input is High 
    {
        PA0_Surg_Flag = true;                           // Flag for wait state count(100ms)
        if(PA0_INPUT_PIN == LOW && (PA0_Surg_Tick >= INPUT_SURG_TIME_DELAY))    // Input Surg delay
        {
            PA_INPUT_BUF |= 0b00000001;                 // Update the PA_INPUT_BUF 0th value as PA0 pin
            if(PA0_FLAG == false)                       // Here the reason for flag is need to count how many high pulses will come..
            {
                UP_COUNT.PA0++;                         // initial time inly the Count will increment, next increment will happens after LOW to HIGH Pulse
                PA0_FLAG = true;                        // Update the input pin status
            }
            PA0_Surg_Flag = false; PA0_Surg_Tick = 0;
        }
    }
    else
    {
        PA_INPUT_BUF &= ~(0b00000001);
        if(PA0_FLAG == true)                        // Here the reason for flag is need to count how many LOW pulses will come..
        {                                           
            DOWN_COUNT.PA0++;                       // initial time inly the Count will increment, next increment will happens after HIGH to LOW Pulse
            PA0_FLAG = false;                       // Update the Input state
        }
    }
    // Check the Input State of PA1
    if(PA1_INPUT_PIN == LOW)
    {
        PA1_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PA1_INPUT_PIN == LOW && (PA1_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PA_INPUT_BUF |= 0b00000010; if(PA1_FLAG == false){UP_COUNT.PA1++; PA1_FLAG = true;}
            PA1_Surg_Flag = false; PA1_Surg_Tick = 0;
        }
    }
    else{PA_INPUT_BUF &= ~(0b00000010);if(PA1_FLAG == true){DOWN_COUNT.PA1++;PA1_FLAG = false;}}   
    // Check the Input State of PA2
    if(PA2_INPUT_PIN == LOW)
    {
        PA2_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PA2_INPUT_PIN == LOW && (PA2_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PA_INPUT_BUF |= 0b00000100; if(PA2_FLAG == false){UP_COUNT.PA2++; PA2_FLAG = true;}
            PA2_Surg_Flag = false; PA2_Surg_Tick = 0;
        }        
    }
    else{PA_INPUT_BUF &= ~(0b00000100);if(PA2_FLAG == true){DOWN_COUNT.PA2++;PA2_FLAG = false;}}   
    // Check the Input State of PA3
    if(PA3_INPUT_PIN == LOW)
    {
        PA3_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PA3_INPUT_PIN == LOW && (PA3_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PA_INPUT_BUF |= 0b00001000; if(PA3_FLAG == false){UP_COUNT.PA3++; PA3_FLAG = true;}
            PA3_Surg_Flag = false; PA3_Surg_Tick = 0;
        }        
    }
    else{PA_INPUT_BUF &= ~(0b00001000);if(PA3_FLAG == true){DOWN_COUNT.PA3++;PA3_FLAG = false;}}   
    // Check the Input State of PA4
    if(PA4_INPUT_PIN == LOW)
    {
        PA4_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PA4_INPUT_PIN == LOW && (PA4_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PA_INPUT_BUF |= 0b00010000; if(PA4_FLAG == false){UP_COUNT.PA4++; PA4_FLAG = true;}
            PA4_Surg_Flag = false; PA4_Surg_Tick = 0;
        }        
    }
    else{PA_INPUT_BUF &= ~(0b00010000);if(PA4_FLAG == true){DOWN_COUNT.PA4++;PA4_FLAG = false;}}   
    // Check the Input State of PA5
    if(PA5_INPUT_PIN == LOW)
    {
        PA5_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PA5_INPUT_PIN == LOW && (PA5_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PA_INPUT_BUF |= 0b00100000; if(PA5_FLAG == false){UP_COUNT.PA5++; PA5_FLAG = true;}
            PA5_Surg_Flag = false; PA5_Surg_Tick = 0;
        }        
    }
    else{PA_INPUT_BUF &= ~(0b00100000);if(PA5_FLAG == true){DOWN_COUNT.PA5++;PA5_FLAG = false;}}
    
    // Check the Input State of PA6
    if(PA6_INPUT_PIN == LOW)
    {
        PA6_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PA6_INPUT_PIN == LOW && (PA6_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PA_INPUT_BUF |= 0b01000000; if(PA6_FLAG == false){UP_COUNT.PA6++; PA6_FLAG = true;}
            PA6_Surg_Flag = false; PA6_Surg_Tick = 0;
        }
    }
    else{PA_INPUT_BUF &= ~(0b01000000);if(PA6_FLAG == true){DOWN_COUNT.PA6++;PA6_FLAG = false;}}  
    // Check the Input State of PA7
    if(PA7_INPUT_PIN == LOW)
    {
        PA7_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PA7_INPUT_PIN == LOW && (PA7_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PA_INPUT_BUF |= 0b10000000; if(PA7_FLAG == false){UP_COUNT.PA7++; PA7_FLAG = true;}
            PA7_Surg_Flag = false; PA7_Surg_Tick = 0;
        }
    }
    else{PA_INPUT_BUF &= ~(0b10000000);if(PA7_FLAG == true){DOWN_COUNT.PA7++;PA7_FLAG = false;}}
    
/************************** PB0-PB7 24V Digital inputs *******************************/
    if(PB0_INPUT_PIN == LOW)
    {
        PB0_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PB0_INPUT_PIN == LOW && (PB0_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PB_INPUT_BUF |= 0b00000001;
            if(PB0_FLAG == false)
            {
                UP_COUNT.PB0++;
                PB0_FLAG = true;
            }
            PB0_Surg_Flag = false; PB0_Surg_Tick = 0;
        }        
    }
    else
    {
        PB_INPUT_BUF &= ~(0b00000001);
        if(PB0_FLAG == true)
        {
            DOWN_COUNT.PB0++;
            PB0_FLAG = false;
        }
    }
    // Check the Input State of PB1
    if(PB1_INPUT_PIN == LOW)
    {
        PB1_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PB1_INPUT_PIN == LOW && (PB1_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PB_INPUT_BUF |= 0b00000010; if(PB1_FLAG == false){UP_COUNT.PB1++; PB1_FLAG = true;}
            PB1_Surg_Flag = false; PB1_Surg_Tick = 0;
        }
    }   
    else{PB_INPUT_BUF &= ~(0b00000010);if(PB1_FLAG == true){DOWN_COUNT.PB1++;PB1_FLAG = false;}}
    
    // Check the Input State of PB2
    if(PB2_INPUT_PIN == LOW)
    {
        PB2_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PB2_INPUT_PIN == LOW && (PB2_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PB_INPUT_BUF |= 0b00000100; if(PB2_FLAG == false){UP_COUNT.PB2++; PB2_FLAG = true;}
            PB2_Surg_Flag = false; PB2_Surg_Tick = 0;
        }
    }
    else{PB_INPUT_BUF &= ~(0b00000100);if(PB2_FLAG == true){DOWN_COUNT.PB2++;PB2_FLAG = false;}}
    
    // Check the Input State of PB3
    if(PB3_INPUT_PIN == LOW)
    {
        PB3_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PB3_INPUT_PIN == LOW && (PB3_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PB_INPUT_BUF |= 0b00001000; if(PB3_FLAG == false){UP_COUNT.PB3++; PB3_FLAG = true;}
            PB3_Surg_Flag = false; PB3_Surg_Tick = 0;
        }
    }
    else{PB_INPUT_BUF &= ~(0b00001000);if(PB3_FLAG == true){DOWN_COUNT.PB3++;PB3_FLAG = false;}}
    
    // Check the Input State of PB4
    if(PB4_INPUT_PIN == LOW)
    {
        PB4_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PB4_INPUT_PIN == LOW && (PB4_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PB_INPUT_BUF |= 0b00010000; if(PB4_FLAG == false){UP_COUNT.PB4++; PB4_FLAG = true;}
            PB4_Surg_Flag = false; PB4_Surg_Tick = 0;
        }
    }
    else{PB_INPUT_BUF &= ~(0b00010000);if(PB4_FLAG == true){DOWN_COUNT.PB4++;PB4_FLAG = false;}}
    
    // Check the Input State of PB5
    if(PB5_INPUT_PIN == LOW)
    {
        PB5_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PB5_INPUT_PIN == LOW && (PB5_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PB_INPUT_BUF |= 0b00100000; if(PB5_FLAG == false){UP_COUNT.PB5++; PB5_FLAG = true;}
            PB5_Surg_Flag = false; PB5_Surg_Tick = 0;
        }
    }
    else{PB_INPUT_BUF &= ~(0b00100000);if(PB5_FLAG == true){DOWN_COUNT.PB5++;PB5_FLAG = false;}}
    
    // Check the Input State of PB6
    if(PB6_INPUT_PIN == LOW)
    {   
        PB6_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PB6_INPUT_PIN == LOW && (PB6_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PB_INPUT_BUF |= 0b01000000; if(PB6_FLAG == false){UP_COUNT.PB6++; PB6_FLAG = true;}
            PB6_Surg_Flag = false; PB6_Surg_Tick = 0;
        }
    }
    else{PB_INPUT_BUF &= ~(0b01000000);if(PB6_FLAG == true){DOWN_COUNT.PB6++;PB6_FLAG = false;}}
    
    // Check the Input State of PB7
    if(PB7_INPUT_PIN == LOW)
    {
        PB7_Surg_Flag = true;                       // Flag for wait state count(100ms)
        if(PB7_INPUT_PIN == LOW && (PB7_Surg_Tick >= INPUT_SURG_TIME_DELAY))
        {
            PB_INPUT_BUF |= 0b10000000; if(PB7_FLAG == false){UP_COUNT.PB7++; PB7_FLAG = true;}
            PB7_Surg_Flag = false; PB7_Surg_Tick = 0;
        }
    }
    else{PB_INPUT_BUF &= ~(0b10000000);if(PB7_FLAG == true){DOWN_COUNT.PB7++;PB7_FLAG = false;}}
   
}

/************************************************************************************************
 * Function Name		: Digital_Output_Process
 * Purpose              : Process control the Digital output state
 * Description			: Get the Output states from data buffer
************************************************************************************************/
void Digital_Output_Process()
{
    unsigned char Digital_Out_Buf;
    Digital_Out_Buf = DATA_ARRAY[PD_OUTPUT_BUF_POS];                // Load the Digital output status from USER Data space
    if((Digital_Out_Buf & 0x01)==0x01)                              // PD0th pin is high, Output is high else low
    {
        PD0_OUT_PIN = 0;                                            // Update the Output Status to GPIO
        PD0_FLAG = true;                                            // Update the Status of the Output PIN
    } 
    else 
    {
        PD0_OUT_PIN = 1;                                            // Update the Output Status to GPIO
        PD0_FLAG = false;                                           // Update the Status of the Output PIN    
    }
    if((Digital_Out_Buf & 0x02)==0x02){ PORTD &= ~(1<<1); PD1_FLAG = true;} else {PORTD |= (1<<1); PD1_FLAG = false;}
    if((Digital_Out_Buf & 0x04)==0x04){ PORTD &= ~(1<<2); PD2_FLAG = true;} else {PORTD |= (1<<2); PD2_FLAG = false;}
    if((Digital_Out_Buf & 0x08)==0x08){ PORTD &= ~(1<<3); PD3_FLAG = true;} else {PORTD |= (1<<3); PD3_FLAG = false;}
    if((Digital_Out_Buf & 0x10)==0x10){ PORTD &= ~(1<<4); PD4_FLAG = true;} else {PORTD |= (1<<4); PD4_FLAG = false;}
    if((Digital_Out_Buf & 0x20)==0x20){ PORTD &= ~(1<<5); PD5_FLAG = true;} else {PORTD |= (1<<5); PD5_FLAG = false;}
    if((Digital_Out_Buf & 0x40)==0x40){ PORTD &= ~(1<<6); PD6_FLAG = true;} else {PORTD |= (1<<6); PD6_FLAG = false;}
    if((Digital_Out_Buf & 0x80)==0x80){ PORTD &= ~(1<<7); PD7_FLAG = true;} else {PORTD |= (1<<7); PD7_FLAG = false;}
}
/************************************************************************************************
 * Function Name		: dataload_buffer
 * Purpose              : load the module's input states to user data buffer
 * Description			: update the inputs states
************************************************************************************************/
void dataload_buffer()
{
    int y;
    for(y=0; y<=15; y++)
    {
        DATA_ARRAY[y] = INFO_STRING[y];                         // Product info String
    }
     // LOAD the PA and PB input States
    DATA_ARRAY[PA_INPUT_BUF_POS]    = PA_INPUT_BUF;             // 3.3/5V input state buffer
    DATA_ARRAY[PB_INPUT_BUF_POS]    = PB_INPUT_BUF;             // 24V input state buffer
    
    // LOAD PA0-7 UP COUNT value in data space array
    DATA_ARRAY[PA0_UP_BUF_POS]      = UP_COUNT.PA0;             // Load the 3.3/5V TTL input UPWARD Counts (0)
    DATA_ARRAY[PA1_UP_BUF_POS]      = UP_COUNT.PA1;             // Load the 3.3/5V TTL input UPWARD Counts (1)
    DATA_ARRAY[PA2_UP_BUF_POS]      = UP_COUNT.PA2;             // Load the 3.3/5V TTL input UPWARD Counts (2)
    DATA_ARRAY[PA3_UP_BUF_POS]      = UP_COUNT.PA3;             // Load the 3.3/5V TTL input UPWARD Counts (3)
    DATA_ARRAY[PA4_UP_BUF_POS]      = UP_COUNT.PA4;             // Load the 3.3/5V TTL input UPWARD Counts (4)
    DATA_ARRAY[PA5_UP_BUF_POS]      = UP_COUNT.PA5;             // Load the 3.3/5V TTL input UPWARD Counts (5)
    DATA_ARRAY[PA6_UP_BUF_POS]      = UP_COUNT.PA6;             // Load the 3.3/5V TTL input UPWARD Counts (6)
    DATA_ARRAY[PA7_UP_BUF_POS]      = UP_COUNT.PA7;             // Load the 3.3/5V TTL input UPWARD Counts (7)
    // LOAD PA0-7 DOWN COUNT value in data space array
    DATA_ARRAY[PA0_DOWN_BUF_POS]    = DOWN_COUNT.PA0;           // Load the 3.3/5V TTL input DOWNWARD Counts (0)
    DATA_ARRAY[PA1_DOWN_BUF_POS]    = DOWN_COUNT.PA1;           // Load the 3.3/5V TTL input DOWNWARD Counts (1)
    DATA_ARRAY[PA2_DOWN_BUF_POS]    = DOWN_COUNT.PA2;           // Load the 3.3/5V TTL input DOWNWARD Counts (2)
    DATA_ARRAY[PA3_DOWN_BUF_POS]    = DOWN_COUNT.PA3;           // Load the 3.3/5V TTL input DOWNWARD Counts (3)
    DATA_ARRAY[PA4_DOWN_BUF_POS]    = DOWN_COUNT.PA4;           // Load the 3.3/5V TTL input DOWNWARD Counts (4)
    DATA_ARRAY[PA5_DOWN_BUF_POS]    = DOWN_COUNT.PA5;           // Load the 3.3/5V TTL input DOWNWARD Counts (5)
    DATA_ARRAY[PA6_DOWN_BUF_POS]    = DOWN_COUNT.PA6;           // Load the 3.3/5V TTL input DOWNWARD Counts (6)
    DATA_ARRAY[PA7_DOWN_BUF_POS]    = DOWN_COUNT.PA7;           // Load the 3.3/5V TTL input DOWNWARD Counts (7)
    
    // LOAD PB0-7 UP COUNT value in data space array
    DATA_ARRAY[PB0_UP_BUF_POS]      = UP_COUNT.PB0;             // Load the 24V TTL input UPWARD Counts (0)
    DATA_ARRAY[PB1_UP_BUF_POS]      = UP_COUNT.PB1;             // Load the 24V TTL input UPWARD Counts (1)
    DATA_ARRAY[PB2_UP_BUF_POS]      = UP_COUNT.PB2;             // Load the 24V TTL input UPWARD Counts (2)
    DATA_ARRAY[PB3_UP_BUF_POS]      = UP_COUNT.PB3;             // Load the 24V TTL input UPWARD Counts (3)
    DATA_ARRAY[PB4_UP_BUF_POS]      = UP_COUNT.PB4;             // Load the 24V TTL input UPWARD Counts (4)
    DATA_ARRAY[PB5_UP_BUF_POS]      = UP_COUNT.PB5;             // Load the 24V TTL input UPWARD Counts (5)
    DATA_ARRAY[PB6_UP_BUF_POS]      = UP_COUNT.PB6;             // Load the 24V TTL input UPWARD Counts (6)
    DATA_ARRAY[PB7_UP_BUF_POS]      = UP_COUNT.PB7;             // Load the 24V TTL input UPWARD Counts (7)
    // LOAD PB0-7 DOWN COUNT value in data space array
    DATA_ARRAY[PB0_DOWN_BUF_POS]    = DOWN_COUNT.PB0;           // Load the 24V TTL input DOWNWARD Counts (0)
    DATA_ARRAY[PB1_DOWN_BUF_POS]    = DOWN_COUNT.PB1;           // Load the 24V TTL input DOWNWARD Counts (1)
    DATA_ARRAY[PB2_DOWN_BUF_POS]    = DOWN_COUNT.PB2;           // Load the 24V TTL input DOWNWARD Counts (2)
    DATA_ARRAY[PB3_DOWN_BUF_POS]    = DOWN_COUNT.PB3;           // Load the 24V TTL input DOWNWARD Counts (3)
    DATA_ARRAY[PB4_DOWN_BUF_POS]    = DOWN_COUNT.PB4;           // Load the 24V TTL input DOWNWARD Counts (4)
    DATA_ARRAY[PB5_DOWN_BUF_POS]    = DOWN_COUNT.PB5;           // Load the 24V TTL input DOWNWARD Counts (5)
    DATA_ARRAY[PB6_DOWN_BUF_POS]    = DOWN_COUNT.PB6;           // Load the 24V TTL input DOWNWARD Counts (6)
    DATA_ARRAY[PB7_DOWN_BUF_POS]    = DOWN_COUNT.PB7;           // Load the 24V TTL input DOWNWARD Counts (7)
    
      //ADC input voltage of mV
    DATA_ARRAY[P0_ADC_BUF_POS]      = (unsigned char)(P0_ADC_BUF>>8);           // Load the ADC Result (MSB of 0th Channel)
    DATA_ARRAY[P0_ADC_BUF_POS+1]    = (unsigned char)(P0_ADC_BUF);              // Load the ADC Result (LSB of 0th Channel)
    DATA_ARRAY[P1_ADC_BUF_POS]      = (unsigned char)(P1_ADC_BUF>>8);           // Load the ADC Result (MSB of 1st Channel)
    DATA_ARRAY[P1_ADC_BUF_POS+1]    = (unsigned char)(P1_ADC_BUF);              // Load the ADC Result (LSB of 1st Channel)
    DATA_ARRAY[P2_ADC_BUF_POS]      = (unsigned char)(P2_ADC_BUF>>8);           // Load the ADC Result (MSB of 2nd Channel)
    DATA_ARRAY[P2_ADC_BUF_POS+1]    = (unsigned char)(P2_ADC_BUF);              // Load the ADC Result (LSB of 2nd Channel)
    DATA_ARRAY[P3_ADC_BUF_POS]      = (unsigned char)(P3_ADC_BUF>>8);           // Load the ADC Result (MSB of 3rd Channel)
    DATA_ARRAY[P3_ADC_BUF_POS+1]    = (unsigned char)(P3_ADC_BUF);              // Load the ADC Result (LSB of 3rd Channel)
    DATA_ARRAY[RESERVED] = 0;                                                   // RESERVED    
}

#endif


//void Collect_Digital_data()
//{
// /********* PA0-PA7 5v/3.3V Digital inputs ***************/
//    // Check the Input State of PA0
//    if(PA0_INPUT_PIN == LOW)                       // Check the PA0 input is High 
//    {
//        PA_INPUT_BUF |= 0b00000001;                 // Update the PA_INPUT_BUF 0th value as PA0 pin
//        if(PA0_FLAG == false)                       // Here the reason for flag is need to count how many high pulses will come..
//        {
//            UP_COUNT.PA0++;                         // initial time inly the Count will increment, next increment will happens after LOW to HIGH Pulse
//            PA0_FLAG = true;                        // Update the input pin status
//        }
//    }
//    else
//    {
//        PA_INPUT_BUF &= ~(0b00000001);
//        if(PA0_FLAG == true)                        // Here the reason for flag is need to count how many LOW pulses will come..
//        {                                           
//            DOWN_COUNT.PA0++;                       // initial time inly the Count will increment, next increment will happens after HIGH to LOW Pulse
//            PA0_FLAG = false;                       // Update the Input state
//        }
//    }
//    // Check the Input State of PA1
//    if(PA1_INPUT_PIN == LOW){PA_INPUT_BUF |= 0b00000010; if(PA1_FLAG == false){UP_COUNT.PA1++; PA1_FLAG = true;}}
//    else{PA_INPUT_BUF &= ~(0b00000010);if(PA1_FLAG == true){DOWN_COUNT.PA1++;PA1_FLAG = false;}}
//    
//    // Check the Input State of PA2
//    if(PA2_INPUT_PIN == LOW){PA_INPUT_BUF |= 0b00000100; if(PA2_FLAG == false){UP_COUNT.PA2++; PA2_FLAG = true;}}
//    else{PA_INPUT_BUF &= ~(0b00000100);if(PA2_FLAG == true){DOWN_COUNT.PA2++;PA2_FLAG = false;}}
//    
//    // Check the Input State of PA3
//    if(PA3_INPUT_PIN == LOW){PA_INPUT_BUF |= 0b00001000; if(PA3_FLAG == false){UP_COUNT.PA3++; PA3_FLAG = true;}}
//    else{PA_INPUT_BUF &= ~(0b00001000);if(PA3_FLAG == true){DOWN_COUNT.PA3++;PA3_FLAG = false;}}
//    
//    // Check the Input State of PA4
//    if(PA4_INPUT_PIN == LOW){PA_INPUT_BUF |= 0b00010000; if(PA4_FLAG == false){UP_COUNT.PA4++; PA4_FLAG = true;}}
//    else{PA_INPUT_BUF &= ~(0b00010000);if(PA4_FLAG == true){DOWN_COUNT.PA4++;PA4_FLAG = false;}}
//    
//    // Check the Input State of PA5
//    if(PA5_INPUT_PIN == LOW){PA_INPUT_BUF |= 0b00100000; if(PA5_FLAG == false){UP_COUNT.PA5++; PA5_FLAG = true;}}
//    else{PA_INPUT_BUF &= ~(0b00100000);if(PA5_FLAG == true){DOWN_COUNT.PA5++;PA5_FLAG = false;}}
//    
//    // Check the Input State of PA6
//    if(PA6_INPUT_PIN == LOW){PA_INPUT_BUF |= 0b01000000; if(PA6_FLAG == false){UP_COUNT.PA6++; PA6_FLAG = true;}}
//    else{PA_INPUT_BUF &= ~(0b01000000);if(PA6_FLAG == true){DOWN_COUNT.PA6++;PA6_FLAG = false;}}
//    
//    // Check the Input State of PA7
//    if(PA7_INPUT_PIN == LOW){PA_INPUT_BUF |= 0b10000000; if(PA7_FLAG == false){UP_COUNT.PA7++; PA7_FLAG = true;}}
//    else{PA_INPUT_BUF &= ~(0b10000000);if(PA7_FLAG == true){DOWN_COUNT.PA7++;PA7_FLAG = false;}}
//
///************************** PB0-PB7 24V Digital inputs *******************************/
//    if(PB0_INPUT_PIN == LOW)
//    {
//        PB_INPUT_BUF |= 0b00000001;
//        if(PB0_FLAG == false)
//        {
//            UP_COUNT.PB0++;
//            PB0_FLAG = true;
//        }
//    }
//    else
//    {
//        PB_INPUT_BUF &= ~(0b00000001);
//        if(PB0_FLAG == true)
//        {
//            DOWN_COUNT.PB0++;
//            PB0_FLAG = false;
//        }
//    }
//    // Check the Input State of PB1
//    if(PB1_INPUT_PIN == LOW){PB_INPUT_BUF |= 0b00000010; if(PB1_FLAG == false){UP_COUNT.PB1++; PB1_FLAG = true;}}
//    else{PB_INPUT_BUF &= ~(0b00000010);if(PB1_FLAG == true){DOWN_COUNT.PB1++;PB1_FLAG = false;}}
//    
//    // Check the Input State of PB2
//    if(PB2_INPUT_PIN == LOW){PB_INPUT_BUF |= 0b00000100; if(PB2_FLAG == false){UP_COUNT.PB2++; PB2_FLAG = true;}}
//    else{PB_INPUT_BUF &= ~(0b00000100);if(PB2_FLAG == true){DOWN_COUNT.PB2++;PB2_FLAG = false;}}
//    
//    // Check the Input State of PB3
//    if(PB3_INPUT_PIN == LOW){PB_INPUT_BUF |= 0b00001000; if(PB3_FLAG == false){UP_COUNT.PB3++; PB3_FLAG = true;}}
//    else{PB_INPUT_BUF &= ~(0b00001000);if(PB3_FLAG == true){DOWN_COUNT.PB3++;PB3_FLAG = false;}}
//    
//    // Check the Input State of PB4
//    if(PB4_INPUT_PIN == LOW){PB_INPUT_BUF |= 0b00010000; if(PB4_FLAG == false){UP_COUNT.PB4++; PB4_FLAG = true;}}
//    else{PB_INPUT_BUF &= ~(0b00010000);if(PB4_FLAG == true){DOWN_COUNT.PB4++;PB4_FLAG = false;}}
//    
//    // Check the Input State of PB5
//    if(PB5_INPUT_PIN == LOW){PB_INPUT_BUF |= 0b00100000; if(PB5_FLAG == false){UP_COUNT.PB5++; PB5_FLAG = true;}}
//    else{PB_INPUT_BUF &= ~(0b00100000);if(PB5_FLAG == true){DOWN_COUNT.PB5++;PB5_FLAG = false;}}
//    
//    // Check the Input State of PB6
//    if(PB6_INPUT_PIN == LOW){PB_INPUT_BUF |= 0b01000000; if(PB6_FLAG == false){UP_COUNT.PB6++; PB6_FLAG = true;}}
//    else{PB_INPUT_BUF &= ~(0b01000000);if(PB6_FLAG == true){DOWN_COUNT.PB6++;PB6_FLAG = false;}}
//    
//    // Check the Input State of PB7
//    if(PB7_INPUT_PIN == LOW){PB_INPUT_BUF |= 0b10000000; if(PB7_FLAG == false){UP_COUNT.PB7++; PB7_FLAG = true;}}
//    else{PB_INPUT_BUF &= ~(0b10000000);if(PB7_FLAG == true){DOWN_COUNT.PB7++;PB7_FLAG = false;}}
//   
//}


/*
    if((Digital_Out_Buf & 0x02)==0x02){ PD1_OUT_PIN = 0; PD1_FLAG = true;} else {PD1_OUT_PIN = 1; PD1_FLAG = false;}
    if((Digital_Out_Buf & 0x02)==0x04){ PD2_OUT_PIN = 0; PD2_FLAG = true;} else {PD2_OUT_PIN = 1; PD2_FLAG = false;}
    if((Digital_Out_Buf & 0x02)==0x08){ PD3_OUT_PIN = 0; PD3_FLAG = true;} else {PD3_OUT_PIN = 1; PD3_FLAG = false;}
    if((Digital_Out_Buf & 0x02)==0x10){ PD4_OUT_PIN = 0; PD4_FLAG = true;} else {PD4_OUT_PIN = 1; PD4_FLAG = false;}
    if((Digital_Out_Buf & 0x02)==0x20){ PD5_OUT_PIN = 0; PD5_FLAG = true;} else {PD5_OUT_PIN = 1; PD5_FLAG = false;}
    if((Digital_Out_Buf & 0x02)==0x40){ PD6_OUT_PIN = 0; PD6_FLAG = true;} else {PD6_OUT_PIN = 1; PD6_FLAG = false;}
    if((Digital_Out_Buf & 0x02)==0x80){ PD7_OUT_PIN = 0; PD7_FLAG = true;} else {PD7_OUT_PIN = 1; PD7_FLAG = false;}
*/