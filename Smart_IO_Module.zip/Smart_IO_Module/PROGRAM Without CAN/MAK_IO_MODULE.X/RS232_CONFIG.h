/***************************************************************************************************************
 * FILE NAME        :   RS232_CONFIG.h
 * PURPOSE          :   Module configurations and default settings
 * Data format are  : StartAddr(0x24 $)    Write(0x80)     SlaveID(0xFE)  BuadRate(0x07)   EndAddr(0x23 #)
 *                  : StartAddr(0x24 $)    Read(0x81)            xx             xx         EndAddr(0x23 #)                          
 ****************************************************************************************************************/
#ifndef _RS232_CONFIG_H_
#define _RS232_CONFIG_H_

void Collect_RS232_Query()                                                      // Collect the RS232 configuration request
{
    if(RS232.Buff_full == true)                                                 // If the RS232 Buffer is full
    {          
        RS232.Req_Count++;                                                      // Serial Request commands counts
        if(RS232.Array[0] == RS232_START_ADDR && RS232.Array[4] == RS232_END_ADDR)  // Check the Start address and End address
        {              
            if(RS232.Read_flag == true)                                         // RS232 Read the setting
            {              
                RS232.EE_SLAVE  =  DataEERead(EEPROM_SLAVE_ID_LOCATION);        // Get the Slave id from EEPROM (0x00)
                RS232.EE_BAUD   =  DataEERead(EEPROM_BAUD_RATE_LOCATION);       // Get the Baud rate from EEPROM (0x01)                
                printf("%c%c%c%c%c",RS232_START_ADDR,RS232_READ_FUN_CODE,RS232.EE_SLAVE,RS232.EE_BAUD,RS232_END_ADDR);     // Command Response for read 
                memset(RS232.Array, 0, sizeof(RS232.Array));                    // Clear the Array
                RS232.Req_Response_Count++;                                     // Request Response count is increment 
                RS232.count = 0;                                                // Clear RS232 array count
                RS232.Buff_full = false;                                        // Clear the Buffer Full, for New Entry 
                RS232.Read_flag = false;                                        // Clear the Read flag status for Re-entry
            }
            else if(RS232.Write_flag == true)                                   // Write the baud rate and slave id to flash
            {                      
                //EE WRITE
                DataEEWrite(RS232.Array[2],EEPROM_SLAVE_ID_LOCATION);           // Write Slave ID to EEPROM 
                DataEEWrite(RS232.Array[3],EEPROM_BAUD_RATE_LOCATION);          // Write Baud value to EEPROM   
                RS232.EE_SLAVE = DataEERead(EEPROM_SLAVE_ID_LOCATION);
                RS232.EE_BAUD  = DataEERead(EEPROM_BAUD_RATE_LOCATION);
                MOD_SLAVE_ID = DataEERead(EEPROM_SLAVE_ID_LOCATION);                // Get Slave ID from EEPROM
                MOD_BAUDRATE = Get_Baud(DataEERead(EEPROM_BAUD_RATE_LOCATION));     // Get Baudrate from EEPROM
                printf("%c%c%c%c%c", RS232_START_ADDR,RS232_WRITE_FUN_CODE,RS232.EE_SLAVE,RS232.EE_BAUD,RS232_END_ADDR);
                MOD_SLAVE_ID = RS232.EE_SLAVE;                                  // Get Slave ID from EEPROM
                MOD_BAUDRATE = Get_Baud(RS232.EE_BAUD);                         // Get Baud rate from EEPROM
                memset(RS232.Array, 0, sizeof(RS232.Array));                    // Clear the Array
                RS232.Req_Response_Count++;                                     // Request Response count is increment 
                RS232.count = 0;                                                // Clear RS232 array count
                RS232.Buff_full = false;                                        // Clear the Buffer Full, for New Entry 
                RS232.Write_flag = false;                                       // Clear the Write flag status for Re-entry
            }
            else if(RS232.Req_Status_flag == true)                              // Respond status of request and response counts
            {
                RS232.Req_Response_Count++;                                     // Request Response count is increment 
                printf("%c%c%c%c%c%c",RS232_START_ADDR,RS232_REQ_STATUS_FUN_CODE,RS232.Req_Count,RS232.Req_Response_Count,RS232.Req_Reject_Count,RS232_END_ADDR);            
                memset(RS232.Array, 0, sizeof(RS232.Array));                    // Clear the Array
                RS232.count = 0;                                                // Clear RS232 array count
                RS232.Buff_full = false;                                        // Clear the Buffer Full, for New Entry 
                RS232.Req_Status_flag = false;                                  // Clear the Request Status Flag for Re-entry
            }
       }
        else
        {
            RS232.Req_Reject_Count++;                                           // Serial Request Reject by error(Start and Stop Address)
            memset(RS232.Array, 0, sizeof(RS232.Array));                        // Clear the Array 
            RS232.Write_flag = false;                                           // Clear the Read flag status for Re-entry
            RS232.Read_flag = false;                                            // Clear the Write flag status for Re-entry
            RS232.Req_Status_flag = false;                                      // Clear the Request Status Flag for Re-entry
            RS232.Buff_full = false;                                            // Clear the Buffer Full, for New Entry 
            RS232.Req_Status_flag = false;                                      // Clear the Request Status Flag for Re-entry
        }
    }
}
/************************************************************************************************
 * Function Name		: Get_Baud()
 * Purpose              : Get the baud rate from the defined register
 * Description			: Baud rate varies 2400-691200bps, it returns the baud rate
 *                      BaudArray[] = {2400,2400,4800,9600,19200,38400,57600,115200,28800,
 *                                         76800,62500,125000,250000,230400,345600,691200};
************************************************************************************************/
unsigned long int Get_Baud(unsigned char baud)
{
    return(BaudArray[baud]);                                                    // Return unsigned long int value (Baud rate from Specified baud array)
}

#endif