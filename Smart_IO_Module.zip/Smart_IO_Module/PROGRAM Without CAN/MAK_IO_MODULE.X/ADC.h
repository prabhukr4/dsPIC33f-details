/********************************************************************************************
 *
 *  FILE NAME    :   ADC.h
 *  PURPOSE      :   Analog to Digital Converter Modules related Function definitions
 *                   10bit resolution, 2SAR registers(606)
 ********************************************************************************************/
#ifndef _ADC_H_
#define _ADC_H_
#include "DEFINITIONS.h"
/************************************************************************************************/
//Function Name			: ADC_init();
//Purpose               : Initializations of ADC Pair 0 and Pair 1
//Description			: Auxiliary PLL upto 120MHz, minimum TAD is 35.8ns, 
//                      : PIC33f need 14 TAD for complete one bit 
/************************************************************************************************/
void ADC_init()
{
   	ADCONbits.ADON = 1;                         // turn ADC OFF
    ADPCFG  =   0xffff;							// Configure all pins as digital
    ADPCFGbits.PCFG0 = 0;                       // AN0 is configured as analog input
    ADPCFGbits.PCFG1 = 0;                       // AN1 is configured as analog input
    ADPCFGbits.PCFG2 = 0;                       // AN2 is configured as analog input
    ADPCFGbits.PCFG3 = 0;                       // AN3 is configured as analog input
    ADCONbits.SLOWCLK = 1;                      // ADC is clocked by the auxiliary PLL (ACLK)
    ADCONbits.FORM = 0;                         // Integer output
    ADCONbits.ADCS = 0b110;                     // Conversion Clock Divider.. minimum TAD is 35.8 nS as per electrical characteristics.
    ADCONbits.ADON = 1;                         // turn ADC ON
}
/************************************************************************************************/
//Function Name			: Collect_ADC_data()
//Purpose               : Collect all ADC pair data
//Description			: Collect and Convert the ADC counts as per the reference level
/************************************************************************************************/
void Collect_ADC_data()
{
    Collect_ADC_Pair0();                        // Collect ADC pair 0 data (Channel 0 and 1)         
    Collect_ADC_Pair1();                        // Collect ADC pair 0 data (Channel 2 and 3)
    Convert_ADC();                              // Convert in the form of mV
}

/************************************************************************************************/
//Function Name			: Collect_ADC_Pair0
//Purpose               : Collect channel 0,1(pair0)
//Description			: 100 samples, converted in the form of mV
//Formula               : count/mv = ADC_REFERENCE/1023 = 2500mv/1023= 2.443792766373411
//                      : Result = ADC_COUNT * count/mv = 1023*2.443792766373411 = 2500 mV
//Output                : "adc_buffer x" holds adc counts of pair x and "Px_ADC_BUF" holds conversion Result in mV
/************************************************************************************************/
void Collect_ADC_Pair0()
{
    // ADC Pair 0 (channel 0 and 1)
    int adc_i;                                          // integer variable for temp. purpose
    adc_buffer1 = 0;                                    // Clear the buffer
    adc_buffer2 = 0;                                    // Clear the buffer
    for(adc_i=0; adc_i< ADC_SAMPLE; adc_i++)            // For taking sample
    {
        ADCPC0bits.TRGSRC0 = 0b00001;                   //Individual software trigger is selected
        ADCPC0bits.SWTRG0 = 1;                          //Starts conversion of AN0 and AN1 
       // __delay32(100);                               //conversion time
        while (ADSTATbits.P0RDY == 0)                   //Conversion Data for Pair 0 Ready 
        {
            __delay32(100);                               //conversion time
            break;
        }
        ADSTATbits.P0RDY = 0;
        ADCPC0bits.PEND0 = 0;                           //Conversion is complete
        adc_buffer1 += ADCBUF0;                         //getting values from buffer
        adc_buffer2 += ADCBUF1;                         //getting values from buffer
    }
    // ADC Pair 1 (Channel 1)
    adc_buffer1 = (adc_buffer1/ ADC_SAMPLE);            // Getting Average from the ADC result buffer1 
    adc_buffer2 = (adc_buffer2/ ADC_SAMPLE);            // Getting Average from the ADC result buffer2 
}


 void Collect_ADC_Pair1()
 {
     int adc_i;                                          // integer variable for temp. purpose
     adc_buffer3 = 0;                                    // Clear the buffer
     adc_buffer4 = 0;                                    // Clear the buffer
    for(adc_i=0; adc_i< ADC_SAMPLE; adc_i++)            // For taking sample
    {
        ADCPC0bits.TRGSRC1 = 0b00001;                   //Individual software trigger is selected
        ADCPC0bits.SWTRG1 = 1;                          //Starts conversion of AN3 and AN2 
        //__delay32(100);                               //conversion time
        while (ADSTATbits.P1RDY == 0)                  //Conversion Data for Pair 1 Ready 
        {
            __delay32(100);                               //conversion time
            break;
        }
        ADSTATbits.P1RDY = 0;
        ADCPC0bits.PEND1 = 0;                           //Conversion is complete
        adc_buffer3 += ADCBUF2;                         //getting values from buffer
        adc_buffer4 += ADCBUF3;                         //getting values from buffer
    }
    adc_buffer3 = (adc_buffer3/ ADC_SAMPLE);            // Getting Average from the ADC result buffer3 
    adc_buffer4 = (adc_buffer4/ ADC_SAMPLE);            // Getting Average from the ADC result buffer4   
}
 
void Convert_ADC()
{
    ADC_AVG1 = (adc_buffer1 * ADC_REF / MAX_ADC_COUNT);         //  Convert the Counts into mV (1023 * 2.4437927663734115 = 2.5V)
    ADC_AVG2 = (adc_buffer2 * ADC_REF / MAX_ADC_COUNT);         //  Convert the Counts into mV (1023 * 2.4437927663734115 = 2.5V)
    ADC_AVG3 = (adc_buffer3 * ADC_REF / MAX_ADC_COUNT);         //  Convert the Counts into mV (1023 * 2.4437927663734115 = 2.5V)
    ADC_AVG4 = (adc_buffer4 * ADC_REF / MAX_ADC_COUNT);         //  Convert the Counts into mV (1023 * 2.4437927663734115 = 2.5V)
    
    P3_ADC_BUF = (unsigned int) ADC_AVG1;
    P2_ADC_BUF = (unsigned int) ADC_AVG2;
    P1_ADC_BUF = (unsigned int) ADC_AVG3;
    P0_ADC_BUF = (unsigned int) ADC_AVG4;
//    P0_ADC_BUF = (adc_buffer1 * ADC_REF/MAX_ADC_COUNT);         //  Convert the Counts into mV (1023 * 2.4437927663734115 = 2.5V)
//    P1_ADC_BUF = (adc_buffer2 * ADC_REF/MAX_ADC_COUNT);         //  Convert the Counts into mV (1023 * 2.4437927663734115 = 2.5V)
//    P2_ADC_BUF = (adc_buffer3 * ADC_REF/MAX_ADC_COUNT);         //  Convert the Counts into mV (1023 * 2.4437927663734115 = 2.5V)
//    P3_ADC_BUF = (adc_buffer4 * ADC_REF/MAX_ADC_COUNT);         //  Convert the Counts into mV (1023 * 2.4437927663734115 = 2.5V)    
}
#endif