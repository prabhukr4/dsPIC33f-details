/*******************************************************************************
 *
 *  FILE NAME    :   GLOBEL.h
 * PURPOSE      :   All variables are declared here for MAK IO MODULE
 *                  
 * -----------------------------------------------------------------------------
 * D A T A   T Y P E S                  D A T A   M E M O R Y 
 * -----------------------------------------------------------------------------
 *      Type                        Byte    x   No.Of   =   Total
 * -----------------------------------------------------------------------------
 * Array                            1       x   (4x100) =   400
 * unsigned char                    1       x   78      =    78
 * unsigned int                     2       x   45      =    90
 * unsigned long int                4       x   25      =   100
 * bool                             1       x   37      =    37
 *                              --------------------------------------
 *                                  TOTAL       =   705 bytes
 *                              --------------------------------------
*******************************************************************************/
#ifndef _GLOBAL_H_
#define _GLOBAL_H_

// General 
unsigned char DATA_ARRAY[100];                          // User Data buffer for update module's I/O info
unsigned int TimerTick=0;                               // Timer 0 count variable
unsigned int sec=0;                                     // Seconds count 
unsigned int LEDBlink=0;                                // LED blink status count 
unsigned char Toggle=0;                                 // Toggle variable for LED
// CRC calculation
unsigned int CRC_Value=0;                               // 16bit CRC Output Register
// ADC 
unsigned int P0_ADC_BUF = 0;                            // data space for store the 0th ADC value
unsigned int P1_ADC_BUF = 0;                            // data space for store the 1st ADC value
unsigned int P2_ADC_BUF = 0;                            // data space for store the 2nd ADC value
unsigned int P3_ADC_BUF = 0;                            // data space for store the 3rd ADC value
unsigned long int adc_buffer1=0;                        // data space for store the 0th ADC Counts value
unsigned long int adc_buffer2=0;                        // data space for store the 1st ADC Counts value
unsigned long int adc_buffer3=0;                        // data space for store the 2nd ADC Counts value
unsigned long int adc_buffer4=0;                        // data space for store the 3rd ADC Counts value
unsigned long int ADC_AVG1;                             // Long int space for Average ADC value
unsigned long int ADC_AVG2;                             // Long int space for Average ADC value
unsigned long int ADC_AVG3;                             // Long int space for Average ADC value
unsigned long int ADC_AVG4;                             // Long int space for Average ADC value
// PWM
unsigned long int PWM1_duty=0;                          // data space for Update PWM Duty time
unsigned long int PWM2_duty=0;                          // data space for Update PWM Duty time
unsigned long int PWM3_duty=0;                          // data space for Update PWM Duty time
unsigned long int PWM4_duty=0;                          // data space for Update PWM Duty time
unsigned int PERIOD=0;                                  // Period update for PWM
// UART
unsigned long int MOD_BAUDRATE;                         // MODBUS Baud rate (2400-691200bps)
                           
// Digital Input
unsigned char PA_INPUT_BUF=0;                           // 3.3/5V digital input state buffer
unsigned char PB_INPUT_BUF=0;                           // 24V digital input state buffer
// Digital input and Output States indication flag
bool PA0_FLAG=false;                                    // 3.3/5V digital input State (0)
bool PA1_FLAG=false;                                    // 3.3/5V digital input State (1)
bool PA2_FLAG=false;                                    // 3.3/5V digital input State (2)
bool PA3_FLAG=false;                                    // 3.3/5V digital input State (3)
bool PA4_FLAG=false;                                    // 3.3/5V digital input State (4)
bool PA5_FLAG=false;                                    // 3.3/5V digital input State (5)
bool PA6_FLAG=false;                                    // 3.3/5V digital input State (6)
bool PA7_FLAG=false;                                    // 3.3/5V digital input State (7)     
bool PB0_FLAG=false;                                    // 24V digital input State (0)
bool PB1_FLAG=false;                                    // 24V digital input State (1)
bool PB2_FLAG=false;                                    // 24V digital input State (2)
bool PB3_FLAG=false;                                    // 24V digital input State (3)
bool PB4_FLAG=false;                                    // 24V digital input State (4)
bool PB5_FLAG=false;                                    // 24V digital input State (5)
bool PB6_FLAG=false;                                    // 24V digital input State (6)
bool PB7_FLAG=false;                                    // 24V digital input State (7)
bool PD0_FLAG=false;                                    // Open Collector Digital Output State (0)
bool PD1_FLAG=false;                                    // Open Collector Digital Output State (1)
bool PD2_FLAG=false;                                    // Open Collector Digital Output State (2)
bool PD3_FLAG=false;                                    // Open Collector Digital Output State (3)
bool PD4_FLAG=false;                                    // Open Collector Digital Output State (4)
bool PD5_FLAG=false;                                    // Open Collector Digital Output State (5)
bool PD6_FLAG=false;                                    // Open Collector Digital Output State (6)
bool PD7_FLAG=false;                                    // Open Collector Digital Output State (7)    
// Input Surg Status Flag
bool PA0_Surg_Flag=false;                                    // 3.3/5V digital input Surg State Flag (0)
bool PA1_Surg_Flag=false;                                    // 3.3/5V digital input Surg State Flag (1)
bool PA2_Surg_Flag=false;                                    // 3.3/5V digital input Surg State Flag (2)
bool PA3_Surg_Flag=false;                                    // 3.3/5V digital input Surg State Flag (3)
bool PA4_Surg_Flag=false;                                    // 3.3/5V digital input Surg State Flag (4)
bool PA5_Surg_Flag=false;                                    // 3.3/5V digital input Surg State Flag (5)
bool PA6_Surg_Flag=false;                                    // 3.3/5V digital input Surg State Flag (6)
bool PA7_Surg_Flag=false;                                    // 3.3/5V digital input Surg State Flag (7)     
bool PB0_Surg_Flag=false;                                    // 24V digital input Surg State Flag (0)
bool PB1_Surg_Flag=false;                                    // 24V digital input Surg State Flag (1)
bool PB2_Surg_Flag=false;                                    // 24V digital input Surg State Flag (2)
bool PB3_Surg_Flag=false;                                    // 24V digital input Surg State Flag (3)
bool PB4_Surg_Flag=false;                                    // 24V digital input Surg State Flag (4)
bool PB5_Surg_Flag=false;                                    // 24V digital input Surg State Flag (5)
bool PB6_Surg_Flag=false;                                    // 24V digital input Surg State Flag (6)
bool PB7_Surg_Flag=false;                                    // 24V digital input Surg State Flag (7)

// Digital Input Timer
unsigned char PA0_Surg_Tick=0;                                    // 3.3/5V digital input Surg Clock tick Count (0)
unsigned char PA1_Surg_Tick=0;                                    // 3.3/5V digital input Surg Clock tick Count (1)
unsigned char PA2_Surg_Tick=0;                                    // 3.3/5V digital input Surg Clock tick Count (2)
unsigned char PA3_Surg_Tick=0;                                    // 3.3/5V digital input Surg Clock tick Count (3)
unsigned char PA4_Surg_Tick=0;                                    // 3.3/5V digital input Surg Clock tick Count (4)
unsigned char PA5_Surg_Tick=0;                                    // 3.3/5V digital input Surg Clock tick Count (5)
unsigned char PA6_Surg_Tick=0;                                    // 3.3/5V digital input Surg Clock tick Count (6)
unsigned char PA7_Surg_Tick=0;                                    // 3.3/5V digital input Surg Clock tick Count (7)     
unsigned char PB0_Surg_Tick=0;                                    // 24V digital input Surg Clock tick Count (0)
unsigned char PB1_Surg_Tick=0;                                    // 24V digital input Surg Clock tick Count (1)
unsigned char PB2_Surg_Tick=0;                                    // 24V digital input Surg Clock tick Count (2)
unsigned char PB3_Surg_Tick=0;                                    // 24V digital input Surg Clock tick Count (3)
unsigned char PB4_Surg_Tick=0;                                    // 24V digital input Surg Clock tick Count (4)
unsigned char PB5_Surg_Tick=0;                                    // 24V digital input Surg Clock tick Count (5)
unsigned char PB6_Surg_Tick=0;                                    // 24V digital input Surg Clock tick Count (6)
unsigned char PB7_Surg_Tick=0;                                    // 24V digital input Surg Clock tick Count (7)


//  Digital Input Up and Downward Counts
 struct 
{
    unsigned char PA0;                                  // 3.3/5V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PA1;                                  // 3.3/5V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PA2;                                  // 3.3/5V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PA3;                                  // 3.3/5V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PA4;                                  // 3.3/5V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PA5;                                  // 3.3/5V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PA6;                                  // 3.3/5V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PA7;                                  // 3.3/5V TTL Input No. of Up & DOWN WARD Counts 
    
    unsigned char PB0;                                  // 24V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PB1;                                  // 24V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PB2;                                  // 24V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PB3;                                  // 24V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PB4;                                  // 24V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PB5;                                  // 24V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PB6;                                  // 24V TTL Input No. of Up & DOWN WARD Counts 
    unsigned char PB7;                                  // 24V TTL Input No. of Up & DOWN WARD Counts 
} UP_COUNT,DOWN_COUNT;
// MODBUS and RS232
struct
{
    unsigned char Array[100];                           // Array buffer
    unsigned char Start_Reg_addr;                       // Register Starting Address
    unsigned char No_of_Reg_addr;                       // Number of Register Address
    unsigned char Start_Data_addr;                      // Data byte Start Address
    unsigned char No_of_Byte_addr;                      // Number of Byte Address
    unsigned char Receive_data;                         // Receive data buffer in UART Receiver
    unsigned char EE_SLAVE;                             // EEPROM Slave ID data space
    unsigned char EE_BAUD;                              // EEPROM baud rate data space
    unsigned int count;                                 // Counter 
    unsigned int Data_length;                           // Data length for Input maximum array size
    unsigned int Req_Count;                             // Serial Request commands counts
    unsigned int Req_Reject_Count;                      // Serial Request Reject by error(CRC or Start and Stop Address)
    unsigned int Req_Response_Count;                          // Serial Request Response Counts
    bool Read_flag;                                     // Function code indication flag
    bool Write_flag;                                    // Function code indication flag
    bool Req_Status_flag;                               // Request status flag identification flag
    bool Single_Write_flag;                             // Function code indication flag
    bool Multi_Write_flag;                              // Function code indication flag
    bool Buff_full;                                     // Receive data buffer full indication
    bool SI_FC_Entry;                                   // Enable or Disable the Slave ID and Function code Entry
    
} MODtx, MODrx, RS232;                                  // Structure for MODtx, MODrx, RS232 functions
unsigned char MOD_SLAVE_ID;                             // MODBUS Slave ID
unsigned char temp_length=0;                            // Temp variable
unsigned long int BaudArray[] = {2400,2400,4800,9600,19200,38400,57600,115200,28800,76800,62500,125000,250000,230400,345600,691200};
                                                        // Various Baud rate buffer 
#endif