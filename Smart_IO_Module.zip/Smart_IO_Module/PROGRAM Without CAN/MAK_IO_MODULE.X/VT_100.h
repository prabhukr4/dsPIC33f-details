/********************************************************************************************
 *
 *  FILE NAME    :   VT_100.h
 *  PURPOSE      :   VirtualTerminal_100 is this kind of format for the purpose of Monitoring TERMINAL
 *                  
 ********************************************************************************************/
#ifndef _VT_100_H_
#define _VT_100_H_
#include "DEFINITIONS.h"

void dataload_vt100()
{
#ifdef vt100

    printf("%c[1;15H -----------------------------------------------------------------------",27);  // <ESC>[Rn;CnH<data>   ESC-27 is value    
    printf("%c[2;15H|-------------          MAK SMART I/O MODULE             ---------------|",27); // <ESC>[Rn;CnH<data>   ESC-27 is value    
    printf("%c[3;15H -----------------------------------------------------------------------",27);  // <ESC>[Rn;CnH<data>   ESC-27 is value    
    printf("%c[4;10ANALOG CONVERTION DATA",27);  // <ESC>[Rn;CnH<data>   ESC-27 is value    
    printf("%c[5;10---------------------------------------------------",27);
    printf("%c[6;10     Channel             Count           Result",27);  // <ESC>[Rn;CnH<data>   ESC-27 is value    
    printf("%c[7;10---------------------------------------------------",27);
    printf("%c[8;10H    ADC_P0              %ld             %d mV",27, adc_buffer1, P0_ADC_BUF);  // <ESC>[Rn;CnH<data>   ESC-27 is value    
    printf("%c[9;10H    ADC_P1              %ld             %d mV",27, adc_buffer2, P1_ADC_BUF);  // <ESC>[Rn;CnH<data>   ESC-27 is value
    printf("%c[10;10H   ADC_P2              %ld             %d mV",27, adc_buffer3, P0_ADC_BUF);  // <ESC>[Rn;CnH<data>   ESC-27 is value    
    printf("%c[11;10H   ADC_P3              %ld             %d mV",27, adc_buffer4, P1_ADC_BUF);  // <ESC>[Rn;CnH<data>   ESC-27 is value   
    printf("%c[13;10DIGITAL INPUT STATE for PORTA-3.3/5V Input",27);  // <ESC>[Rn;CnH<data>   ESC-27 is value
    printf("%c[14;10H-----------------------------------------------------------------------",27);    
    printf("%c[15;10H   Digital Pin         Status         No.of UPWARDS      No.of DOWNWARDS",27);  // <ESC>[Rn;CnH<data>   ESC-27 is value    
    printf("%c[16;10H-----------------------------------------------------------------------",27);    
    printf("%c[17;10H   DI_PA.0             %d                %d                  %d ",27,PA0_FLAG,UP_COUNT.PA0, DOWN_COUNT.PA0);
    printf("%c[18;10H   DI_PA.1             %d                %d                  %d ",27,PA1_FLAG,UP_COUNT.PA1, DOWN_COUNT.PA1);
    printf("%c[19;10H   DI_PA.2             %d                %d                  %d ",27,PA2_FLAG,UP_COUNT.PA2, DOWN_COUNT.PA2);
    printf("%c[20;10H   DI_PA.3             %d                %d                  %d ",27,PA3_FLAG,UP_COUNT.PA3, DOWN_COUNT.PA3);
    printf("%c[21;10H   DI_PA.4             %d                %d                  %d ",27,PA4_FLAG,UP_COUNT.PA4, DOWN_COUNT.PA4);
    printf("%c[22;10H   DI_PA.5             %d                %d                  %d ",27,PA5_FLAG,UP_COUNT.PA5, DOWN_COUNT.PA5);
    printf("%c[23;10H   DI_PA.6             %d                %d                  %d ",27,PA6_FLAG,UP_COUNT.PA6, DOWN_COUNT.PA6);
    printf("%c[24;10H   DI_PA.7             %d                %d                  %d ",27,PA7_FLAG,UP_COUNT.PA7, DOWN_COUNT.PA7);    
    printf("%c[26;10DIGITAL INPUT STATE for PORTB-24V Input",27);  // <ESC>[Rn;CnH<data>   ESC-27 is value
    printf("%c[27;10H   DI_PB.0             %d                %d                  %d ",27,PB0_FLAG,UP_COUNT.PB0, DOWN_COUNT.PB0);
    printf("%c[28;10H   DI_PB.1             %d                %d                  %d ",27,PB1_FLAG,UP_COUNT.PB1, DOWN_COUNT.PB1);
    printf("%c[29;10H   DI_PB.2             %d                %d                  %d ",27,PB2_FLAG,UP_COUNT.PB2, DOWN_COUNT.PB2);
    printf("%c[30;10H   DI_PB.3             %d                %d                  %d ",27,PB3_FLAG,UP_COUNT.PB3, DOWN_COUNT.PB3);
    printf("%c[31;10H   DI_PB.4             %d                %d                  %d ",27,PB4_FLAG,UP_COUNT.PB4, DOWN_COUNT.PB4);
    printf("%c[32;10H   DI_PB.5             %d                %d                  %d ",27,PB5_FLAG,UP_COUNT.PB5, DOWN_COUNT.PB5);
    printf("%c[33;10H   DI_PB.6             %d                %d                  %d ",27,PB6_FLAG,UP_COUNT.PB6, DOWN_COUNT.PB6);
    printf("%c[34;10H   DI_PB.7             %d                %d                  %d ",27,PB7_FLAG,UP_COUNT.PB7, DOWN_COUNT.PB7);   
    printf("%c[36;10DIGITAL OUTPUT STATE ",27);  // <ESC>[Rn;CnH<data>   ESC-27 is value
    printf("%c[37;10H-------------------------------",27);    
    printf("%c[38;10H   Digital Pin       Status    ",27);  // <ESC>[Rn;CnH<data>   ESC-27 is value    
    printf("%c[39;10H-------------------------------",27);    
    printf("%c[39;10H   DO_PD0              %d     ",27,PD0_FLAG);
    printf("%c[39;10H   DO_PD1              %d     ",27,PD1_FLAG);
    printf("%c[39;10H   DO_PD2              %d     ",27,PD2_FLAG);
    printf("%c[39;10H   DO_PD3              %d     ",27,PD3_FLAG);
    printf("%c[39;10H   DO_PD4              %d     ",27,PD4_FLAG);
    printf("%c[39;10H   DO_PD5              %d     ",27,PD5_FLAG);
    printf("%c[39;10H   DO_PD6              %d     ",27,PD6_FLAG);
    printf("%c[39;10H   DO_PD7              %d     ",27,PD7_FLAG);  
        
#endif        
}

#endif