/****************************************************************************************************
*****************************************************************************************************
***  PURPOSE      : MAK SMART I/O MODULE (CPU IO EXPANSION)                                        **
***  DEVELOPED BY : PRABHU R                                                                       **
***  STARTED ON   : 12-07-2017                                                                     **
***  VERSION      : V1.1                                                                           **
***  Language     : C Programming                                                                  **
***  Controller   : dsPIC33FJ64GS606(16 Bit)                                                       **
 ****************************************************************************************************
 ***************************************************************************************************/
/*--------------------------------------------------------------------------------------------------
//							Pin Description															
//--------------------------------------------------------------------------------------------------
//	Pin Number		    Pin Details				Pin Description									
//--------------------------------------------------------------------------------------------------
*		1				PE5						Digital input 0
*		2				PE6						Digital input 1
*		3				PE7						Digital input 2
*		4				PG6						Digital input 3                                               	
* 		5				PG7                 	Digital input 4                                               	
*		6				PG8                     Digital input 5                                               	
*		7				MCLR					Reset												
*		8				PG9						Digital input 6
*		9				VSS						Ground												
*		10				VDD						Supply                                              
*		11				PB5						-
*		12				PB4						-
*		13				PB3						Analog input 3
*		14				PB2						Analog input 2
*		15				PB1						Analog input 1
*		16				PB0						Analog input 0
*		17				PB6						Programming Pins PGEC
*		18				PB7						Programming Pins PGED
*		19				AVDD					Analog reference Supply								
*		20				AVSS					Analog reference Ground								
*		21				PB8						Digital input 7
*		22				PB9						DACOUT(not used)
*		23				PB10					-                                                   
*		24				PB11					-                                               	
*		25				VSS						Ground                                          	
*		26				VDD						Supply                                              
*		27				PB12					Digital input 11                                               	
*		28				PB13					Digital input 10                                           		
*		29				PB14					Digital input 9                                                   
*		30				PB15					Digital input 8
*		31				U2RX					RS485 RX 
*		32				U2TX					RS485 TX
*		33				U1TX					RS232 TX
*		34				U1RX					RS232 RX
*		35				PF6             		-
*		36				PG3						I2C SDA
*		37				PG2						I2C SCL
*		38				VDD						Supply												
*		39				OSC1					XTAL1                               				
*		40				OSC2					XTAL2                                           	
*		41				VSS						Ground                                      		
*		42				PD8						-
*		43				PD9						Digital input 15
*		44				PD10                	Digital input 14
*		45				PD11                    Digital input 13
*		46				PD0						Digital input 12                                                   
*		47				PC13					Status LED
*		48				PC14					Digital output 0
*		49				PD1						Digital output 1
*		50				PD2						Digital output 2
*		51				PD3						Digital output 3
*		52				PD4                 	Digital output 4
*		53				PD5                     Digital output 5
*		54				PD6                     Digital output 6
*		55				PD7						Digital output 7
*		56				VCAP					Ground                                              
*		57				VDD						Supply                                              
*		58				PF0						CAN Port RX
*		59				PF1						CAN Port TX
*		60				PE0						PWM 1
*		61				PE1						PWM 1
*		62				PE2						PWM 2
*		63				PE3						PWM 3
*		64				PE4						-
--------------------------------------------------------------------------------------------------*/

#include "HEADERS.h"
/****************************************** EXTERNAL OSCILLATOR INITIALIZATION ****************************************************/    	
// FBS
#pragma config BWRP = WRPROTECT_OFF     // Boot Segment Write Protect (Boot Segment may be written)
#pragma config BSS = NO_FLASH           // Boot Segment Program Flash Code Protection (No Boot program Flash segment)

// FGS
#pragma config GWRP = OFF               // General Code Segment Write Protect (General Segment may be written)
#pragma config GSS = HIGH               // General Segment Code Protection (High Security Code Protection Enabled)

// FOSCSEL
#pragma config FNOSC = PRIPLL           // Oscillator Source Selection (Primary Oscillator (XT, HS, EC) with PLL)
#pragma config IESO = OFF               // Internal External Switch Over Mode (Start up device with user-selected oscillator source)

// FOSC
#pragma config POSCMD = HS              // Primary Oscillator Source (HS Crystal Oscillator Mode)
#pragma config OSCIOFNC = ON            // OSC2 Pin Function (OSC2 is general purpose digital I/O pin)
#pragma config FCKSM = CSDCMD           // Clock Switching Mode bits (Both Clock switching and Fail-safe Clock Monitor are disabled)

// FWDT
#pragma config WDTPOST = PS4096           // Watchdog Timer Postscaler (1:16)
#pragma config WDTPRE = PR32            // WDT Prescaler (1:32)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Watchdog Timer in Non-Window mode)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog timer enabled/disabled by user software)

// FPOR
#pragma config FPWRT = PWR128           // POR Timer Value (128ms)
#pragma config ALTSS1 = OFF             // Enable Alternate SS1 pin bit (SS1 is selected as the I/O pin for SPI1)
#pragma config ALTQIO = OFF             // Enable Alternate QEI1 pin bit (QEA1, QEB1, INDX1 are selected as inputs to QEI1)

// FICD
#pragma config ICS = PGD1               // Comm Channel Select (Communicate on PGC1/EMUC1 and PGD1/EMUD1)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG is disabled)

/******************************************************************************
 *                    M A I N    F U N C T I O N                             *
*******************************************************************************/
int main(void) 
{
    System_init();
    for( ; ; )
    {       
        Collect_data();             // Collect all inputs of MAK SMART IO MODULE
        Process_Control_Output();   // Control the digital out and PWM duty
        dataload_buffer();          // Load the data to data space register array
        LED_Blink();
        RCONbits.SWDTEN = 0;        //to clear watch dog timer
    }
    return 0;
}
