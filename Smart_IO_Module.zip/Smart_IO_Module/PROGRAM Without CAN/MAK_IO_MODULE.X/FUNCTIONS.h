
/********************************************************************************************
 *
 *  FILE NAME    :   FUNCTIONS.h
 *  PURPOSE      :   All Function are declared here for MAK IO MODULE Project
 *                  
 ********************************************************************************************/
#ifndef _FUNCTIONS_H_
#define _FUNCTIONS_H_

void System_init();                                 // Function declaration for System initialization
void Oscillator_init();                             // Function declaration for Oscillator initialization
void Timer2_init();                                 // Function declaration for Timer 2 initialization
void IO_init();                                     // Function declaration for Input and Outputs direction
void Get_SI_BAUD();                                 // Get Slave iD and Baud rate from EEPROM
void LED_Blink();                                   // LED Toggle function using Timer
void LED_Toggle();                                  // LED Toggle
// CRC
unsigned int crc(volatile unsigned char * , unsigned short );   // CRC calculations
// ADC
void ADC_init();                                    // Function declaration for ADC initializations
void Collect_ADC_data();                            // Function declaration for Collect ADC data
void Collect_ADC_Pair0();                           // Function declaration for Get ADC's Pair data
void Collect_ADC_Pair1();                           // Function declaration for Get ADC's PAir 1 data
void Convert_ADC();                                 // Function declaration for Convert the required data format
void PWM_init();                                    // Function declaration for  PWM initializations
void Update_PWM_duty_cycle(void);                   // Update the PWM duty cycle
void Collect_data();                                // Collect all inputs
void Collect_Digital_data();                        // Function declaration for get digital data
void Process_Control_Output();                      // Function declaration for Output control section    
void Digital_Output_Process();                      // Function declaration for Digital pins outputs
void dataload_buffer();                             // store the data to buffer
// MODBUS
void Collect_MOD_Query();                                                   // Function declaration for Collect MODBUS Query 
void MOD_Read_Holding_Register(unsigned int, unsigned int);                 // Function declaration for  Read the Register and Response
void MOD_Write_Multi_Register(unsigned int, unsigned int, unsigned int);    // Function declaration for Write multiple register
void MOD_Response_Write_Multi_Register(unsigned char, unsigned char);       // Function declaration for Respond for Write Multiple register
void MOD_Response_Write_Single_Register(void);
// RS232
void Collect_RS232_Query();                         // Collect the RS232 configuration request
unsigned long int Get_Baud(unsigned char);          // Function declaration for Getting baud rate
// I2C and EEPROM
void i2c_init();                                    // Function declaration for I2C initializations
void i2c_wait();                                    // Function declaration for  i2c wait function (check ACK and Status)
void i2c_write(unsigned char,unsigned char);        // Function declaration for i2c Write function to slave    
unsigned char i2c_read(unsigned char);              // Function declaration for  i2c read function from slave
void i2c_send(unsigned char);                       // Function declaration for sending the data to slave

#endif